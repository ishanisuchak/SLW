import * as Akumina from 'akumina-core';
import * as $ from 'jquery';
import React = require('react');
import { ISLWListItem, SummaryLinksEditComponent } from '../../components/SummaryLinksEditComponent';
import { SummaryLinksRenderManager } from '../../components/SummaryLinksRenderManager';

interface IIndexable {
    [key: string]: any;
}
interface ISummaryLinksWidgetProps {
    id: string;
    displaytemplateurl: string;
    collectionid: string;
    displaycollectionname: boolean | string;
    haspageprops: string;
    isonpage: string;
    widgetframework: string;
    widgetname: string;
    callbackmethod: string;
    uicallbackmethod: string;
}
interface ISummaryLinksWidgetState {
    modelView: any;
    pageLifeCycleComplete: boolean;
    groupList: any;
    allItemsList: any;
    rootNodeGuid: string;
    displayTemplateUrl: string;
    collectionNotSpecified: boolean;
    collectionNotFound: boolean;
    collectionId: string;
    displayCollectionName: boolean;
    isPreviewMode: boolean;
    isDefaultModelBound: boolean;
    defaultModel: any;
    isLoading: boolean;
}

export interface ISummaryLinksProprtyChangeModel {

}
export interface ISummaryLinksWidgetRequest extends IIndexable {
    SenderId: string;
    HasPageProps: string;
    DisplayTemplateUrl: string;
    IsOnPage: string;
    WidgetFramework: string;
    WidgetName: string;
    DisplayCollectionName: boolean;
    CallbackMethod: string;
    UiCallbackMethod: string;
}
export interface ISummaryLinksDataItem {
    CollectionId: string;
    CollectionName: string;
    DisplayCollectionName: boolean;
    Title: string;
    NodeType: string;
    ParentNode: string;
    DisplayOrder: number;
    Summary: string;
    Link: string;
    LinkTarget: string;
    LinkTargetValue: string;
    Id: string;
    IntId: number;
    ImageUrl: string;
    ImageAlternativeText: string;
    Tooltip: string;
    senderid: string;
    Persona?: IPersona[];
    ItemCount?: number;
    /** Hidden note field associated with Persona */
    Persona_0?: string;
}

interface ISLWData {
    modelView: any;
    rootNodeGuid: string;
    groupList: Array<ISummaryLinksDataItem>;
    allItemList: Array<ISummaryLinksDataItem>;
    collectionNotFound: boolean;
    emptyCollection: boolean;
    defaultModel: any
}

export interface IPersona {
    label: string;
    guId: string;
}

export interface IPersonaRequest {
    listName: string;
    itemId: number,
    personaList: string;
    columnName: string;
    isRoot?: boolean;
}

export class SummaryLinksWidget extends React.Component<ISummaryLinksWidgetProps, ISummaryLinksWidgetState>{
    public Version: string = "{{build:version}}";
    private properties: ISummaryLinksWidgetRequest;
    private listName: string;
    private useRoot: boolean;
    public static personaCacheKey = Akumina.Digispace.ConfigurationContext.getCacheKeyLanguageNeutral("slwpersonacache");
    private personaTermsFromCache: any;
    constructor(props: ISummaryLinksWidgetProps) {
        super(props);
        this.listName = "SummaryLinks_AK";
        this.useRoot = false;
        this.properties = {
            SenderId: props.id,
            HasPageProps: props.haspageprops,
            DisplayTemplateUrl: props.displaytemplateurl,
            IsOnPage: props.isonpage,
            WidgetFramework: props.widgetframework,
            WidgetName: props.widgetname,
            CallbackMethod: props.callbackmethod,
            UiCallbackMethod: props.uicallbackmethod,
            DisplayCollectionName: typeof props.displaycollectionname == "string" ? props.displaycollectionname.toLowerCase() == "true" : props.displaycollectionname
        }

        this.state = {
            modelView: { Items: [] },
            pageLifeCycleComplete: false,
            groupList: [],
            allItemsList: [],
            rootNodeGuid: "",
            collectionNotSpecified: false,
            displayTemplateUrl: props.displaytemplateurl,
            collectionNotFound: false,
            collectionId: props.collectionid,
            displayCollectionName: this.properties.DisplayCollectionName,
            isPreviewMode: false,
            isDefaultModelBound: false,
            defaultModel: null,
            isLoading: false,
        }

        this.prepareModelforView = this.prepareModelforView.bind(this);
        this.LoadItemSuccess = this.LoadItemSuccess.bind(this);
        this.GetData = this.GetData.bind(this);
        this.RefreshData = this.RefreshData.bind(this);
        this.OnPropertyChanged = this.OnPropertyChanged.bind(this);
        this.EnterPreviewMode = this.EnterPreviewMode.bind(this);
        this.ExitPreviewMode = this.ExitPreviewMode.bind(this);
        this.CreateRootOfDefaultModel = this.CreateRootOfDefaultModel.bind(this);
        this.getDefaultDataForViewType = this.getDefaultDataForViewType.bind(this);
    }

    ExitPreviewMode() {
        this.setState({ isPreviewMode: false });
    }
    EnterPreviewMode() {
        this.setState({ isPreviewMode: true });
    }

    IsSummaryLinkWidgetInEditMode() { 
        var isWidgetActionAbsent = true;//!$("#" + this.properties.SenderId).parent().hasClass("ak-widget-action-container");       
        return Akumina.Digispace.PageContext.EditMode && isWidgetActionAbsent && !this.state.isPreviewMode;
    }

    render() {
        //Widget is getting reinitiated inside widget actions div, hence this works
        var _cur = this;
        var isSummaryLinkWidgetEditMode = _cur.IsSummaryLinkWidgetInEditMode() && !this.state.isLoading;
        var editClassName = isSummaryLinkWidgetEditMode ? " ak-summary-links-edit" : "";
        var defaultItemClass = this.state.isDefaultModelBound ? " ak-default-item" : "";
        var html: any;

        var ErrorElement;
        if (this.state.collectionNotSpecified) {
            ErrorElement = (<p className="text-center">{Akumina.Digispace.Language.TryGetText('summarylink.error.collectionnotset')}</p>);
        }
        /*if (this.state.html == null) {
            ErrorElement = (<p className="text-center">{Akumina.Digispace.Language.TryGetText('summarylink.renderingwidget')}</p>)
        }*/

        if (ErrorElement !== undefined) {
            html = ErrorElement
        } else {
            html = null;
        }

        return (
            <div className={"ak-summary-links " + editClassName + defaultItemClass}>
                {isSummaryLinkWidgetEditMode ?
                    <SummaryLinksEditComponent CollectionId={this.state.collectionId} RefreshData={this.RefreshData} ViewModel={this.state.modelView}
                        GroupList={this.state.groupList} AllItemList={this.state.allItemsList} RootNodeGuid={this.state.rootNodeGuid} SenderId={this.properties.SenderId}
                        WidgetProperties={this.properties} SelectedView={this.state.displayTemplateUrl} CreateRootOfDefaultModel={this.CreateRootOfDefaultModel}
                        DisplayCollectionName={this.state.displayCollectionName} IsShowStartButton={this.state.isDefaultModelBound && this.state.collectionNotFound}
                        ListName={this.listName} UseRoot={this.useRoot}
                    />
                    : null}
                <React.Fragment>
                    {_cur.state.isLoading ? <div className="ia-widget-loader"></div> : null}
                    {!isSummaryLinkWidgetEditMode && this.state.isDefaultModelBound ? (
                       <div>{Akumina.Digispace.Language.TryGetText('summarylink.nodatafound')} </div>
                    ) : (
                        <div className="ak-summarylinks-container">
                            <SummaryLinksRenderManager displayTemplateUrl={this.state.displayTemplateUrl}
                                viewModel={this.state.modelView} SenderId={this.properties.SenderId}
                                isSummaryLinkWidgetEditMode={isSummaryLinkWidgetEditMode}
                                displayCollectionName={this.state.displayCollectionName}
                            />
                        </div>
                    )}
                    {html}
                </React.Fragment>
            </div>
        );
    }

    componentWillMount() {
        var cur = this;
        if (!Akumina.Digispace.SiteContext.IsLoaderComplete) {
            Akumina.Digispace.AppPart.Eventing.Subscribe('/loader/completed/', function () { cur.AkRender(); }, this.properties.SenderId);

        } else {
            cur.AkRender();
        }
    }

    AkRender() {
        this.setState({ pageLifeCycleComplete: true });
    }

    componentDidMount() {
        var _cur = this;
        this.personaTermsFromCache = Akumina.AddIn.Cache.Get(SummaryLinksWidget.personaCacheKey);
        if (!this.personaTermsFromCache) {
            SummaryLinksWidget.getPersonaTerms();
        }
        Akumina.Digispace.AppPart.Eventing.Subscribe('/summarylist/propertychanged/' + this.properties.SenderId, this.OnPropertyChanged, this.properties.SenderId);
        Akumina.Digispace.AppPart.Eventing.Subscribe('/tray/enterpreviewmode/', this.EnterPreviewMode, this.properties.SenderId);
        Akumina.Digispace.AppPart.Eventing.Subscribe('/tray/exitpreviewmode/', this.ExitPreviewMode, this.properties.SenderId);
        Akumina.Digispace.AppPart.Eventing.Subscribe('/summarylinks/ShowLoader/', function () { _cur.ShowLoader(); }, this.properties.SenderId);
        Akumina.Digispace.AppPart.Eventing.Subscribe('/summarylinks/HideLoader/', function () { _cur.HideLoader(); }, this.properties.SenderId);
        _cur.ShowLoader();
        $.when(this.GetData()).then(function (data, html) {
            if (data == null) {
                //i.e collection not set in widget property
                let viewModel = {
                    collectionNotSpecified: true,
                    collectionNotFound: false,
                }
                viewModel = _cur.fireCallbackMethod(viewModel);
                _cur.setState(viewModel, _cur.BindUI);

            } else if (data.collectionNotFound || data.emptyCollection) {
                let viewModel = {
                    modelView: data.modelView, rootNodeGuid: data.rootNodeGuid,
                    groupList: data.groupList, allItemsList: data.allItemList,
                    collectionNotFound: data.collectionNotFound, collectionNotSpecified: false,
                    isDefaultModelBound: true, defaultModel: data.defaultModel
                }
                viewModel = _cur.fireCallbackMethod(viewModel);
                _cur.setState(viewModel, _cur.BindUI);
            } else {
                let viewModel = {
                    modelView: data.modelView, rootNodeGuid: data.rootNodeGuid,
                    groupList: data.groupList, allItemsList: data.allItemList,
                    collectionNotFound: data.collectionNotFound, collectionNotSpecified: false
                }
                viewModel = _cur.fireCallbackMethod(viewModel);
                _cur.setState(viewModel, _cur.BindUI);
            }
        }, function (error) {
            console.log(error);
        });
    }

    componentWillUnmount() {
        //We should UnSubscribe the events while component unmounts
        var _cur = this;
        Akumina.Digispace.AppPart.Eventing.UnSubscribe('/loader/completed/', function () { _cur.AkRender(); }, this.properties.SenderId);
        Akumina.Digispace.AppPart.Eventing.UnSubscribe('/summarylist/propertychanged/' + this.properties.SenderId, this.OnPropertyChanged, this.properties.SenderId);
        Akumina.Digispace.AppPart.Eventing.UnSubscribe('/tray/enterpreviewmode/', this.EnterPreviewMode, this.properties.SenderId);
        Akumina.Digispace.AppPart.Eventing.UnSubscribe('/tray/exitpreviewmode/', this.ExitPreviewMode, this.properties.SenderId);
        Akumina.Digispace.AppPart.Eventing.UnSubscribe('/summarylinks/ShowLoader/', function () { _cur.ShowLoader(); }, this.properties.SenderId);
        Akumina.Digispace.AppPart.Eventing.UnSubscribe('/summarylinks/HideLoader/', function () { _cur.HideLoader(); }, this.properties.SenderId);
    }

    componentDidUpdate() {
        let displayTemplateUrl = this.state.displayTemplateUrl.toLowerCase();
        switch (true) {
            case (displayTemplateUrl.indexOf("expandinglist.html") > -1):
                $("#" + this.properties.SenderId).off().on("click", ".ia-quicklink-title", function (e) {
                    e.preventDefault();
                    $(this).toggleClass("expanded");
                    $(this).next().slideToggle();
                });
                break;
            case (displayTemplateUrl.indexOf("expandinglistalllevel.html") > -1):
            case (displayTemplateUrl.indexOf("expandinglistnogroups.html") > -1):
                $("#" + this.properties.SenderId).off().on("click", ".ia-faq-header", function (e) {
                    e.preventDefault();
                    $(this).toggleClass("expanded");
                    $(this).next().slideToggle();
                });
                break;
            case (displayTemplateUrl.indexOf("") > -1):
                let senderId = this.properties.SenderId;
                $("#" + this.properties.SenderId).off().on("click", ".ia-default-carousel-sub-item li", function (e) {
                    e.preventDefault();
                    $(this).addClass("active");
                    $(this).siblings().removeClass("active");
                    var getImage = $(this).find(".ia-default-sub-item").css("background-image") || "";
                    var getHtml = $(this).find(".ia-default-image-name").html();
                    $("#" + senderId).find(".ia-default-carousel-image").css("background-image", getImage);
                    $("#" + senderId).find(".ia-default-main-image .ia-default-image-name").html(getHtml);
                });
                setTimeout(() => $("#" + this.properties.SenderId).find(".ia-default-carousel-sub-item li:first-child").trigger('click'), 100);
                break;
        }
    }

    ShowLoader() {
        this.setState({ isLoading: true });
    }

    HideLoader() {
        this.setState({ isLoading: false });
    }

    RefreshData() {
        var _cur = this;
        _cur.ShowLoader();
        this.GetData().then(function (data) {
            if (data == null) {
                let viewModel = {
                    collectionNotSpecified: true,
                    collectionNotFound: false,
                    isDefaultModelBound: false, defaultModel: null
                }
                viewModel = _cur.fireCallbackMethod(viewModel);
                _cur.setState(viewModel, _cur.BindUI);

            } else if (data.collectionNotFound || data.emptyCollection) {
                let viewModel = {
                    modelView: data.modelView, rootNodeGuid: data.rootNodeGuid,
                    groupList: data.groupList, allItemsList: data.allItemList,
                    collectionNotFound: data.collectionNotFound, collectionNotSpecified: false,
                    isDefaultModelBound: true, defaultModel: data.defaultModel
                }
                viewModel = _cur.fireCallbackMethod(viewModel);
                _cur.setState(viewModel, _cur.BindUI);
            } else {
                let viewModel = {
                    modelView: data.modelView, rootNodeGuid: data.rootNodeGuid,
                    groupList: data.groupList, allItemsList: data.allItemList,
                    collectionNotFound: data.collectionNotFound, collectionNotSpecified: false, isDefaultModelBound: false, defaultModel: null
                }
                viewModel = _cur.fireCallbackMethod(viewModel);
                _cur.setState(viewModel, _cur.BindUI);
            }
        }, function (error) {
            console.log(error);
        })
    }

    OnPropertyChanged(model: any) {
        var _cur = this;
        model.properties.map(function (propertyName: string) {
            switch (propertyName.toLowerCase()) {
                case "displaytemplateurl":
                    _cur.setState({
                        displayTemplateUrl: model.model.widgetprops.displaytemplateurl
                    }, () => {
                        if (_cur.state.isDefaultModelBound) {
                            _cur.RefreshData()
                        }
                    });
                    break;
                case "collectionid":
                    _cur.setState({
                        collectionId: model.model.widgetprops.collectionid
                    });
                    break;
                case "displaycollectionname":
                    _cur.setState({
                        displayCollectionName: model.model.widgetprops.displaycollectionname
                    });
                    break;
            }
        });
    }

    GetData(): JQueryDeferred<ISLWData | null> {
        var def: JQueryDeferred<ISLWData | null> = $.Deferred();
        var _cur = this;
        var request: any = {};
        request.listName = this.listName;
        request.selectFields = ["ID", "ItemGuid", "CollectionId", "CollectionName", "NodeName", "NodeType", "ParentNode", "DisplayOrder", "Summary", "Link", "LinkTarget", "Image", "Tooltip", "Persona"].join(",");
        request.isRoot = this.useRoot;
        if (_cur.IsSummaryLinkWidgetInEditMode()) {
            request.skipPersonaFiltering = true;
        }

        if (this.state.collectionId !== "") {
            request.queryFilter = new Akumina.PropertyExpression("CollectionId").EqualTo(this.state.collectionId);
            //request.contextSiteUrl = _cur.QuickLinksRequest.SiteCollectionUrl;
            /* We eill need to support ML
            if (_cur.QuickLinksRequest.FallbackLanguage) {
                request.language = _cur.QuickLinksRequest.FallbackLanguage;
            }*/

            var df = new Akumina.Digispace.Data.DataFactory();
            df.GetList(request).then(function (data: { response: any; }) {
                _cur.HideLoader();
                var response = data.response;
                _cur.LoadItemSuccess(response, def);
            }, function (error: any) {
                if (error.status == 429) {
                    var errorObj = { targetDiv: _cur.props.id, sender: _cur.props.id, properties: _cur.props, status: error.status };
                    new Akumina.Digispace.AppPart.Data().Templates.BindErrorTemplateForWidgets(errorObj);
                }
                    //_cur.setState({ isThrottle: true })
                _cur.HideLoader();
                def.reject(error);
            });
        } else {
            _cur.HideLoader();
            def.resolve(null);
        }
        return def;
    }

    GetPersonaModel(persona: any) {
        var personData: IPersona[] = [];
        if(Akumina.Digispace.SiteContext.IsHeadlessMode && persona) {
            persona.results = persona;
        }
        
        if (persona && persona.results) {
            for (var i = 0; i < persona.results.length; i++) {
                let value = persona.results[i];
                personData.push({ label: value.Label, guId: value.TermGuid });
            }
        }

        return personData;
    }

    LoadItemSuccess(responseData: any, def: JQueryDeferred<ISLWData | null>) {
        var listItems = responseData.listItems;
        var listEnumerator = listItems.getEnumerator();
        var data: any = {}; //new QuickLinksResponse();
        var _cur = this;
        data.Items = [] as Array<ISummaryLinksDataItem>;

        while (listEnumerator.moveNext()) {
            var listItem = listEnumerator.get_current();
            var CollectionId = listItem.get_item("CollectionId");
            var CollectionName = listItem.get_item("CollectionName");
            var Title = listItem.get_item("NodeName");
            var NodeType = listItem.get_item("NodeType");
            var ParentNode = listItem.get_item("ParentNode");
            var DisplayOrder = listItem.get_item("DisplayOrder");
            var Summary = Akumina.Digispace.Utilities.RewriteImageUrlsForHeadless(listItem.get_item("Summary"));
            var Link = listItem.get_item("Link") == null ? "" : listItem.get_item("Link").get_url();
            var LinkTargetValue = listItem.get_item("LinkTarget");
            var LinkTarget = listItem.get_item("LinkTarget") == "Same Window" ? "_self" : "_blank";

            var Image = listItem.get_item("Image");
            var ImageUrl = Image ? Image.get_url() : "";
            var ImageAlternativeText = Image ? (Image.Description ? Image.Description : Image.get_description()) : "";

            var Tooltip = listItem.get_item("Tooltip");
            var ItemGuid = listItem.get_item('ItemGuid');

            var Id = listItem.get_item('ID');

            var itemPersona = _cur.GetPersonaModel(listItem.get_item("Persona"));
            var spaLink = Link
            //commenting this out - we should not be rewriting before storing in Sharepoint.
            //let the front end handle rewriting this at the time of render. -JA
            //var spaLink = Link ? Akumina.Digispace.Utilities.CreatePageLink(Link) : Link;

            var summaryLinkItem: ISummaryLinksDataItem = {
                CollectionId: CollectionId,
                CollectionName: CollectionName != null ? CollectionName.toString() : "",
                DisplayCollectionName: _cur.state.displayCollectionName,
                Title: Title ? Title : "",
                NodeType: NodeType == "Category" ? "Group" : NodeType,//KJ >> !!TEST THIS WELL!! >> TO AVOID VIEW CHANGES
                ParentNode: ParentNode ? ParentNode.toString() : "",
                DisplayOrder: DisplayOrder,
                Summary: Summary ? Summary : "",
                Link: spaLink ? spaLink : "",
                LinkTarget: LinkTarget ? LinkTarget : "",
                LinkTargetValue: LinkTargetValue,
                Id: ItemGuid.toString(),
                IntId: Id,
                ImageUrl: ImageUrl ? ImageUrl : "",
                ImageAlternativeText: ImageAlternativeText ? ImageAlternativeText : "",
                Tooltip: Tooltip ? Tooltip : "",
                senderid: _cur.properties.SenderId,
                Persona: itemPersona
            }
            data.Items.push(summaryLinkItem);
        }

        var collectionNotFound = data.Items.length <= 0;
        //Items will be 0 When root not present(SavedLayoutInstance,CollectionDeletedInstance)
        //Only Root, i.e. 1, when there is no item in list
        var bindDefaultModel = data.Items.length <= 1;
        if (bindDefaultModel) {

            var viewname = this.state.displayTemplateUrl.substring(this.state.displayTemplateUrl.lastIndexOf('/') + 1);
            var defaultItems = this.getDefaultDataForViewType(viewname);
            viewname = defaultItems.defaultViewName;
            var collectionId;
            if (!collectionNotFound) {
                defaultItems.Items = defaultItems.Items.filter((x: any) => x.NodeType !== "Root");
                defaultItems.Items.unshift(data.Items[0]);
                collectionId = data.Items[0].CollectionId;
                //Sanitize Root Item
                data.Items[0].CollectionId = "{{collectionidguid}}";
                data.Items[0].Id = "{{collectionidguid}}";
            }
            if (defaultItems.Items.length > 0) {
                defaultItems = this.ReplaceTokens(defaultItems, viewname, CollectionId);
                data.defaultModel = $.extend({}, defaultItems);
                data.Items = [...defaultItems.Items];
            }
        }

        var sortedItems = this.sortItemsDesc(data.Items);
        for (var i = 0; i < sortedItems.length; i++) {
            sortedItems = _cur.prepareModelforView(sortedItems, i);
        }
        var modelView = this.excludeNotRoot(sortedItems);
        var rootNodeGuid = this.GetRootNodeGuid(data.Items);
        var allItemList = bindDefaultModel ? [] : this.PopulateFlatAllItemList(data.Items);
        var groupList = bindDefaultModel ? [] : this.PopulateGroupList(data.Items, rootNodeGuid);

        var objectForResolve: ISLWData = {
            modelView: modelView[0], rootNodeGuid: rootNodeGuid, groupList: groupList, allItemList: allItemList,
            collectionNotFound: collectionNotFound, defaultModel: data.defaultModel, emptyCollection: bindDefaultModel
        };
        def.resolve(objectForResolve);
    }

    /**
     * @param {any} data 
     * @param {string} collectionid - Collection id to be replaced for collectionguid token
     * @description 
     * This will be used only for default models (Generated by saved layout)
     * @returns {any} - data with Items populated with collectionguid 
     */
    ReplaceTokens(data: any, viewname: string, CollectionId: string | undefined): any {
        var collectionguid = Akumina.Digispace.Utilities.GetGuid();
        var senderid = this.properties.SenderId;
        var itemIdMap: IIndexable = {};
        if (typeof CollectionId !== "undefined") {
            collectionguid = CollectionId;
        }
        itemIdMap["{{collectionidguid}}"] = collectionguid;
        for (var i = 0; i < data.Items.length; ++i) {
            itemIdMap["{{" + i + "}}"] = Akumina.Digispace.Utilities.GetGuid();
        }
        for (var i = 0; i < data.Items.length; ++i) {
            var item = data.Items[i] as ISummaryLinksDataItem;
            item.senderid = senderid;
            item.CollectionId = itemIdMap[item.CollectionId];
            item.ParentNode = itemIdMap[item.ParentNode] || "";
            item.Id = itemIdMap[item.Id];
            item.IntId = -1;
            let viewName = viewname.indexOf('.') > -1 ? viewname.slice(0, viewname.indexOf(".")) : viewname;
            if (item.NodeType == "Root" && typeof CollectionId == "undefined") {
                item.Title = item.CollectionName = Akumina.Digispace.PageContext.PageTitle + " - " + viewName;
            }
        }
        return data;
    }

    CreateRootOfDefaultModel(evt: React.SyntheticEvent) {
        evt.preventDefault();
        var isNonDefaultLanguage = Akumina.Digispace.ConfigurationContext.GetDefaultLanguage().languageId !== Akumina.Digispace.UserContext.LanguageId;
        if (isNonDefaultLanguage) {
            Akumina.Digispace.Utilities.ShowAlertPopup(Akumina.Digispace.Language.TryGetText("summarylink.nondefaultcollection"), null);
            return;
        }
        var _cur = this;
        var addDefs: Array<JQueryDeferred<any>> = [];           //Add items in list
        var updateDefs: Array<JQueryDeferred<any>> = [];        //Update AkId
        if (!this.personaTermsFromCache) {
            this.personaTermsFromCache = Akumina.AddIn.Cache.Get(SummaryLinksWidget.personaCacheKey);
        }
        let personaForAll = this.personaTermsFromCache.filter((term: any) => term.name.toLowerCase() == "all")[0];
        this.state.defaultModel && this.state.defaultModel.Items.filter((x: ISLWListItem) => x.NodeType == "Root").forEach(function (element: ISummaryLinksDataItem) {
            var newItem: ISLWListItem = {
                CollectionId: element.CollectionId,
                CollectionName: element.CollectionName,
                NodeName: element.CollectionName,
                NodeType: element.NodeType,
                Title: element.CollectionName,
                DisplayOrder: 0,
                ItemGuid: element.Id,
                AkLanguageCode: Akumina.Digispace.ConfigurationContext.GetDefaultLanguage().languageCode,
                AkLanguageId: Akumina.Digispace.ConfigurationContext.GetDefaultLanguage().languageId,
                //Persona_0 is the hidden note field for Persona tax field
                //Updating it in this format is undocumented
                //Format: Value1|TermId1;Value2|TermId2
                Persona_0: personaForAll.name + "|" + personaForAll.guid
            } as any;

            var def: JQueryDeferred<any>;
            var queryParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.listName, newItem);
            let dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
            dataFactory.SetContextUrl(_cur.useRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);

            def = dataFactory.AddListItem(_cur.listName, queryParams, _cur.useRoot);
            addDefs.push(def);
        });

        $.when.apply($, addDefs).then(function () {
            for (var i = 0; i < arguments.length; ++i) {
                var languageModel = {
                    AkId: arguments[i].Id
                }
                var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.listName, languageModel);
                var updateDef: JQueryDeferred<any>;
                let dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.useRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);

                updateDef = dataFactory.UpdateListItem(_cur.listName, arguments[i].Id, queryLangParams, _cur.useRoot);
                updateDefs.push(updateDef);
            }
            $.when.apply($, updateDefs).then(function (result: any) {
                var collectionId = _cur.state.defaultModel.Items[0].CollectionId;
                //KJ >> global instance of SLW lost properties when toggling widget edit mode
                var WidgetPropsToUpdate = { collectionid: collectionId, widgetFramework: "react", displaytemplateurl: _cur.state.displayTemplateUrl };
                Akumina.Digispace.AppPart.Eventing.Publish('/pagecomponent/partialupdatewidgetstate/', { WidgetPropsForRender: { name: _cur.props.widgetname, class: "Akumina.AddIn.SummaryLinksWidget" }, WidgetPropsToUpdate: WidgetPropsToUpdate, widgetinstanceid: _cur.properties.SenderId });

                _cur.setState({ isDefaultModelBound: false, defaultModel: null, collectionId: _cur.state.defaultModel.Items[0].CollectionId }, _cur.RefreshData);

            }, function (error: any) {
                (Akumina as any).Digispace.Logger.WriteErrorLog(error);
            });
        }, function (error: any) {
            (Akumina as any).Digispace.Logger.WriteErrorLog(error);
        })
    }

    private GetRootNodeGuid(response: any): string {
        return response.filter((x: any) => x.NodeType == "Root")[0].Id;
    }

    private PopulateGroupList(response: any, RootNodeGuid: string): Array<any> {
        var groupList = response.filter((x: any) => x.NodeType == "Group");
        var MaxRootDisplayOrder = 0;
        response.filter((x: any) => x.ParentNode == RootNodeGuid).forEach(function (child: any) {
            MaxRootDisplayOrder = child.DisplayOrder > MaxRootDisplayOrder ? child.DisplayOrder : MaxRootDisplayOrder;
        });
        groupList = groupList.map(function (groupItem: any) {
            var Children = response.filter((x: any) => groupItem.Id == x.ParentNode);
            var ChildCount = Children.length;
            var MaxDisplayOrder = 0;
            Children.forEach(function (child: any) {
                MaxDisplayOrder = child.DisplayOrder > MaxDisplayOrder ? child.DisplayOrder : MaxDisplayOrder;
            });

            groupItem.ChildCount = ChildCount;
            groupItem.MaxDisplayOrder = MaxDisplayOrder;
            groupItem.MaxRootDisplayOrder = MaxRootDisplayOrder;
            return groupItem;
        });
        return groupList;
    }

    private PopulateFlatAllItemList(response: Array<ISummaryLinksDataItem>): Array<ISummaryLinksDataItem> {
        return response.filter((x: any) => x.NodeType == "Item");
    }

    private excludeNotRoot(items: Array<any>) {

        items = items.filter(function (el) {
            return el.NodeType === 'Root';
        });

        if (items.length > 0) {
            items[0].OriginalTitle = items[0].Title;//for backward compat
            items[0].Title = 'Summary Links';
        }

        return items;
    };

    private getParentItems = function (items: Array<any>, parentGuid: string) {
        var children: Array<any> = jQuery.grep(items, function (item) {
            return item.ParentNode !== null && item.ParentNode === parentGuid;
        });

        for (var i = 0; i < children.length; i++) {

            if (children[i].NodeType === 'Group') {
                children[i].IsFolder = true;
            }
            if (children[i].NodeType === 'Item') {
                children[i].IsItem = true;
            }
        }

        return children;
    };

    private sortItemsDesc(items: any) {
        return items.sort(function (a: any, b: any) {
            return b.IntId - a.IntId
        });
    };

    private prepareModelforView(items: any, index: number) {
        var item = items[index];
        if (item.ParentNode != null) {
            var parentGuid: string = item.ParentNode;
            var parentIndex = this.getElementById(items, parentGuid);
            if (parentIndex >= 0) {
                if (items[parentIndex].Items == undefined) {
                    items[parentIndex].Items = [];
                }
                items[parentIndex].Items = this.sortItemsAsc(this.getParentItems(items, parentGuid));
            }
        }
        return items;
    };

    private sortItemsAsc(items: Array<any>) {
        return items.sort(function (a: any, b: any) {
            return a.DisplayOrder - b.DisplayOrder
        });
    };

    /** Get Item by id */
    private getElementById(items: Array<any>, id: string) {
        var index = items.map(function (el) {
            return el.Id;
        }).indexOf(id);
        return index;

    };

    private getDefaultDataForViewType(viewFileName: string) {
        var mappingArray = [{
            viewTitle: 'default.html',
            viewName: "default",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Group",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{1}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{1}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'linkedlist.html',
            viewName: "linked_list",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 2,
                "Summary": "",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 3,
                "Summary": "",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'linkedlistwiththumbnails.html',
            viewName: "thumbnails",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 2,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 3,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'expandinglist.html',
            viewName: "expanding_list_with_groups",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Group",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{1}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{1}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'expandinglistnogroups.html',
            viewName: "expanding_list_with_no_group",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 2,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 3,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'expandinglistalllevel.html',
            viewName: "faq",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 2,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'featuredbox.html',
            viewName: "feature_box",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'defaultcarousel.html',
            viewName: "default_carousel",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 2,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 3,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'calltoaction.html',
            viewName: "call_to_action",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 2,
                "Summary": "",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 3,
                "Summary": "",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'calltoinformation.html',
            viewName: "call_to_information",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 2,
                "Summary": "",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Lorem ipsum dolor sit amet",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 3,
                "Summary": "",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'videowithinfo.html',
            viewName: "thumbnails",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 2,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 3,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        },
        {
            viewTitle: 'tiledgroupwithlink.html',
            viewName: "tiledgroupwithlink",
            items: [{
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Id": "{{collectionidguid}}",
                "Title": "",
                "DisplayOrder": 0,
                "NodeType": "Root",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 1,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{1}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 2,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{2}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }, {
                "CollectionId": "{{collectionidguid}}",
                "CollectionName": "",
                "Title": "Placeholder title",
                "NodeType": "Item",
                "ParentNode": "{{collectionidguid}}",
                "DisplayOrder": 3,
                "Summary": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi tincidunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean accumsan sed nunc sit amet scelerisque. Maecenas pellentesque magna suscipit ante egestas scelerisque. Vivamus aliquet varius commodo.",
                "Link": "",
                "LinkTarget": "_blank",
                "LinkTargetValue": "New Window",
                "Id": "{{3}}",
                "IntId": -1,
                "ImageUrl": "https://dummyimage.com/250x250/EEEFF1/A3A4A4&text=placeholder%20image",
                "ImageAlternativeText": "",
                "Tooltip": "",
                "senderid": "{{senderguid}}"
            }]
        }
        ];
        var viewMapping = mappingArray.find(function (viewMapping) {
            return viewMapping.viewTitle.toLowerCase() == viewFileName.toLowerCase();
        });
        var viewCase = viewMapping ? viewMapping.viewName : "default";
        var model: any = {};
        model.Items = viewMapping ? viewMapping.items : mappingArray[0].items;
        model.defaultViewName = viewMapping ? viewMapping.viewName : "default";
        return model;
    }

    private fireCallbackMethod(viewModel: any) {
        if (!Akumina.AddIn.Utilities.IsNullOrEmpty(this.properties.CallbackMethod) && typeof (window as IIndexable)[this.properties.CallbackMethod] == "function") {
            return (window as IIndexable)[this.properties.CallbackMethod](viewModel);
        } else {
            return viewModel;
        }
    }

    public static getPersonaTerms = () => {
        var request: any = {};
        request.listName = "SummaryLinks_AK";
        request.isRoot = false;
        var dataFactory = new Akumina.Digispace.Data.DataFactory(true);
        dataFactory.SetContextUrl(Akumina.Digispace.SiteContext.WebAbsoluteUrl);
        dataFactory.LoadTermSetByColumnName(request, "Persona", "All").then(data => {
            let cacheInterval = Akumina.AddIn.Constants.DAY_CACHE_EXPIRATION;
            let termsData = data.terms.children.map((item: any) => { return { name: item.name, title: item.title, guid: item.guid } });
             //must use ForceSet - when in Live Mode "Set" does not proceed with setting cache.
            //am not sure why this is required as we should be using STATE for this in React?? -JA
            //widow as any as this method I dont want public to pass typescript check
            (window as any).Akumina.AddIn.Cache.ForceSet(SummaryLinksWidget.personaCacheKey, termsData, cacheInterval);
        }).catch(err => {
            (Akumina as any).Digispace.Logger.WriteErrorLog(err);
        });
    }

    private BindUI = (control?: any) => {
        control = control ? control : $(`.ak-widget[id='${this.properties.SenderId}']`);
        setTimeout(() => {
            if (!Akumina.AddIn.Utilities.IsNullOrEmpty(this.properties.UiCallbackMethod) && typeof (window as IIndexable)[this.properties.UiCallbackMethod] == "function") {
                (window as IIndexable)[this.properties.UiCallbackMethod](control, this.properties);
            }
        }, 100);
    }; 
}

