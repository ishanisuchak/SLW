import Akumina = require("akumina-core");
import React = require("react");
import { SummaryLinksRecursiveRender } from "./viewrender/SummaryLinksRecursiveRender";
import { SummaryLinksHeaderRender } from "./viewrender/SummaryLinksHeaderRender";
import { ISummaryLinksDataItem } from "../js/widgets/SummaryLinksWidget";
import { WidgetJSXUtilities } from "../../../components/WidgetJSXUtilities";


export interface ISLWViewHtml {
    head: Function;
    recursive: ISLWViewRecursiveHTML;
}
export interface ISLWViewRecursiveHTML {
    root: Function;
    group: Function;
    item: Function;
}

interface ISLWRenderManagerProps {
    displayTemplateUrl: string;
    viewModel: any;
    SenderId: string;
    isSummaryLinkWidgetEditMode: boolean;

    displayCollectionName: boolean;
}
interface ISLWRenderManagerState {
    html: ISLWViewHtml | null;
    viewModel: any;
    displayTemplateUrl: string;
}

export class SummaryLinksRenderManager extends React.Component<ISLWRenderManagerProps, ISLWRenderManagerState>{
    constructor(props: ISLWRenderManagerProps) {
        super(props);
        this.state = {
            html: null,
            viewModel: props.viewModel,
            displayTemplateUrl: props.displayTemplateUrl
        }
        this.GetTemplate();
    }

    componentDidUpdate(prevProps: ISLWRenderManagerProps) {
        if (prevProps.displayTemplateUrl != this.props.displayTemplateUrl) {
            this.setState({
                displayTemplateUrl: this.props.displayTemplateUrl
            }, this.GetTemplate);
        }
        if (this.props.viewModel != prevProps.viewModel) {
            this.setState({
                viewModel: this.props.viewModel
            });
        }
    }

    render() {
        if (this.state.html != null) {
            let viewModel = this.state.viewModel;
            if (this.props.displayTemplateUrl.indexOf('featuredbox.html') > -1) {
                let itemsOnly = viewModel.Items.filter((item: ISummaryLinksDataItem) => item.NodeType == "Item");
                viewModel.Items.forEach((x: ISummaryLinksDataItem) => {
                    x.ItemCount = itemsOnly.length; //View is using this Count to change css class
                });
            }
            return (
                <React.Fragment>
                    <SummaryLinksHeaderRender html={this.state.html.head}
                        displayCollectionName={this.props.displayCollectionName} CollectionName={viewModel.CollectionName}
                    />
                    <SummaryLinksRecursiveRender model={viewModel} html={this.state.html.recursive}
                        isSummaryLinkWidgetEditMode={this.props.isSummaryLinkWidgetEditMode}
                        SenderId={this.props.SenderId} />
                </React.Fragment>
            );
        } else {
            return <div>{Akumina.Digispace.Language.TryGetText('summarylink.componentrendered')} </div>
        }
    }

    private GetTemplate() {
        var _cur = this;
        new Akumina.Digispace.AppPart.Data().Templates.RequestTemplateFromServer(this.state.displayTemplateUrl).then(function (html: string) {
            var [main, , root, , group, , item] = html.trim().split(/\{\/\*(root|group|item)\*\/\}/)
            var htmlToRet: ISLWViewHtml = {
                head: WidgetJSXUtilities.JSXClient(main, {}),
                recursive: {
                    root: WidgetJSXUtilities.JSXClient(root, {}),
                    group: WidgetJSXUtilities.JSXClient(group, {}),
                    item: WidgetJSXUtilities.JSXClient(item, {})
                }
            }
            _cur.setState({ html: htmlToRet });
        });
    }



}