import Akumina = require("akumina-core");
import React = require("react");

interface ISummaryLinksViewPickersProps {
    CloseModal: any;
    UpdateLinkUrl: (linkUrl: string) => void;
}
interface ISummaryLinksViewPickersState {
    Title: string;
    AllSearchedPages: Array<any>;
    AllSearchedPagesCopy: Array<any>;
    AllPagesCount: number;
    AllPagesNextPagingInfo: any;
    selectedPageUrl: string;
    searchText: string;
    pagination: IPagination;
    IsLoading: boolean;
}

interface IPagePrevToken {
    pageNo: Number;
    token: string | null;
}

interface IPagination {
    allPages: boolean,
    pageLimit: Number,
    pageCount: Number,
    currentPage: Number,
    prevPage: Number,
    firstRecord: boolean,
    endRecord: boolean,
}

export class SummaryLinksViewPickers extends React.Component<ISummaryLinksViewPickersProps, ISummaryLinksViewPickersState>{
    private pageItemsPagingObj: any;
    private prevSkipToken: IPagePrevToken[] = [];
    private prevSkipTokenUrl: string = "";
    private isNextPage: boolean = true;
    private isPageSearch: boolean = true;
    constructor(props: ISummaryLinksViewPickersProps) {
        super(props);

        this.state = {
            AllSearchedPages: [],
            Title: '',
            selectedPageUrl: '',
            AllSearchedPagesCopy: [],
            AllPagesCount: 0,
            searchText: "",
            pagination: { allPages: false, pageLimit: 10, pageCount: 0, currentPage: 0, prevPage: 0, firstRecord: false, endRecord: false, } as IPagination,
            IsLoading: false,
            AllPagesNextPagingInfo: null
        };

        this.SetSelectedPage = this.SetSelectedPage.bind(this);
        this.SelectPage = this.SelectPage.bind(this);
        this.pageItemsPagingObj = new Akumina.AddIn.GenericListPaging();
    }

    componentDidMount() {
        var cur = this;
        this.getAllPagesCount().then(() => {
            this.isNextPage = true;
            this.GetExistingPagesData("").then(function (data: any) {
                if (data.length && data[0].pagingInfo) {
                    if (Akumina.Digispace.SiteContext.IsHeadlessMode) {
                        cur.pageItemsPagingObj.nextPagingInfo = data[0].pagingInfo;
                    }
                    else {
                        cur.pageItemsPagingObj.nextPagingInfo = data[0].pagingInfo.get_pagingInfo();
                    }
                } else {
                    cur.pageItemsPagingObj.nextPagingInfo = null;
                }

                //To identify last page
                if (!cur.pageItemsPagingObj.nextPagingInfo) {
                    cur.pageItemsPagingObj.isLastPage = true;
                }
                const { currentPage, prevPage, firstRecord, endRecord } = cur.updatePagingValues();
                cur.setState(prevState => ({
                    AllSearchedPages: data,
                    AllSearchedPagesCopy: data,
                    AllPagesNextPagingInfo: data.length && data[0].pagingInfo,
                    pagination: { ...prevState.pagination, currentPage: currentPage, prevPage: prevPage, firstRecord: firstRecord, endRecord: endRecord }
                }), () => {
                    cur.savePrevSkipTokens();
                });
            });
        });
    }

    GetExistingPagesData(searchText: string) {
        var rowLimit = this.state.pagination.pageLimit;
        var legacyMode = true;
        var spcaller = new Akumina.Digispace.Data.DataFactory(legacyMode);
        spcaller.SetContextUrl(Akumina.Digispace.SiteContext.SiteAbsoluteUrl);
        if (searchText && !Akumina.AddIn.Utilities.IsNullOrEmpty(searchText)) {
            var query = "<View><Query><Where><Contains><FieldRef Name='PageTitle'/><Value Type='Text'>" + searchText + "</Value></Contains></Where><OrderBy><FieldRef Name='Modified' Ascending='FALSE' /></OrderBy></Query><RowLimit>" + rowLimit.toString() + "</RowLimit></View>";
        } else {
            var query = "<View><Query><OrderBy><FieldRef Name='Modified' Ascending='FALSE' /></OrderBy></Query><RowLimit>" + rowLimit.toString() + "</RowLimit></View>";
        }

        var request: any = {};

        request.isPagedResult = true;

        // Pagination code
        if (this.pageItemsPagingObj.nextPagingInfo) {
            this.pageItemsPagingObj.position = spcaller.GetListPosition();
            this.pageItemsPagingObj.position.set_pagingInfo(this.pageItemsPagingObj.nextPagingInfo);
        }
        else {
            this.pageItemsPagingObj.position = null;
        }

        request.PageManager = this.pageItemsPagingObj;

        request.viewXml = query;
        request.listName = "PageUrls_AK";

        this.prevSkipTokenUrl = JSON.parse(JSON.stringify(this.pageItemsPagingObj.nextPagingInfo))
        return new Akumina.Digispace.Data.PageManager().GetPagesFromPageUrlList(request);
    }

    SetSelectedPage(e: React.SyntheticEvent) {
        e.preventDefault();
        var dataPageUrl = (e.currentTarget as HTMLTableRowElement).dataset.page as string;
        if (!Akumina.AddIn.Utilities.IsNullOrEmpty(dataPageUrl)) {
            this.setState({ selectedPageUrl: dataPageUrl });
        }
    }

    SelectPage() {
        this.props.UpdateLinkUrl(this.state.selectedPageUrl);
        this.props.CloseModal();
    }

    ExistingPageSearch = (e?: React.SyntheticEvent) => {
        e && e.preventDefault();
        var cur = this;
        var value = cur.state.searchText;
        var selectedPageUrl: string;
        cur.GetExistingPagesData(value).then(function (data: any) {
            if (data.length && data[0].pagingInfo) {
                if (Akumina.Digispace.SiteContext.IsHeadlessMode) {
                    cur.pageItemsPagingObj.nextPagingInfo = data[0].pagingInfo;
                }
                else {
                    cur.pageItemsPagingObj.nextPagingInfo = data[0].pagingInfo.get_pagingInfo();
                }
            } else {
                cur.pageItemsPagingObj.nextPagingInfo = null;
            }

            //To identify last page
            if (!cur.pageItemsPagingObj.nextPagingInfo) {
                cur.pageItemsPagingObj.isLastPage = true;
            }
            selectedPageUrl = (data.filter(function (page: any) { return page.pageUrl == cur.state.selectedPageUrl }) > 0) ? cur.state.selectedPageUrl : "";
            const { currentPage, prevPage, firstRecord, endRecord } = cur.updatePagingValues();
            cur.setState(prevState => ({
                AllSearchedPages: data,
                selectedPageUrl: selectedPageUrl,
                pagination: { ...prevState.pagination, currentPage: currentPage, prevPage: prevPage, firstRecord: firstRecord, endRecord: endRecord },
                IsLoading: false
            }), () => {
                cur.savePrevSkipTokens();
            });
        });
    }

    HandleSearchTextChange = (e: any) => {
        var cur = this;
        var enterClicked = e.keyCode == 13;
        var searchText = (e.currentTarget as HTMLInputElement).value;
        this.setState(prevState => ({
            searchText: searchText === "" || searchText.length > 2 || enterClicked ? searchText : prevState.searchText
        }), function () {
            cur.pageItemsPagingObj = new Akumina.AddIn.GenericListPaging();
            cur.prevSkipToken = [];
            var value = cur.state.searchText;
            if (value.length > 2 || enterClicked) {
                cur.getListItemCountWithFilters(value).then(function (count: number) {
                    cur.setState(prevState => ({ pagination: { ...prevState.pagination, pageCount: count } }), function () {
                        cur.resetPagination(+cur.state.pagination.pageLimit, function () {
                            cur.ExistingPageSearch(e);
                        });
                    });
                });
            }
            else {
                cur.resetPagination(+cur.state.pagination.pageLimit, () => {
                    const { currentPage, prevPage, firstRecord, endRecord } = cur.updatePagingValues();
                    cur.setState(prevState => ({
                        AllSearchedPages: prevState.AllSearchedPagesCopy,
                        pagination: { ...prevState.pagination, currentPage: currentPage, prevPage: prevPage, firstRecord: firstRecord, endRecord: endRecord }
                    }));
                }, cur.state.AllPagesCount);
            }
        });
    }

    savePrevSkipTokens = () => {
        var _cur = this;
        if (_cur.prevSkipToken.filter(function (item) { return item.pageNo === _cur.state.pagination.currentPage }).length === 0) {
            _cur.prevSkipToken.push({ "pageNo": _cur.state.pagination.currentPage, "token": _cur.state.pagination.currentPage === 1 ? null : _cur.prevSkipTokenUrl });
        }
    }

    updatePagingValues = () => {
        var _cur = this;
        const totalPages = Math.ceil(+this.state.pagination.pageCount / +this.state.pagination.pageLimit)
        let currentPage = 1;
        if (!this.isPageSearch) {
            currentPage = _cur.isNextPage ? +this.state.pagination.currentPage + 1 : +this.state.pagination.currentPage - 1;
        }
        let prevPage = currentPage - 1;
        const firstRecord = currentPage === 1;
        const endRecord = currentPage === totalPages;

        return { currentPage: currentPage, prevPage: prevPage, firstRecord: firstRecord, endRecord: endRecord }
    }

    onNextPage = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
        this.setState({ IsLoading: true });
        this.isNextPage = true;
        this.isPageSearch = false;
        this.ExistingPageSearch(e);
    }

    onPrevPage = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
        this.setState({ IsLoading: true });
        if (this.prevSkipToken.length > 0) {
            this.pageItemsPagingObj.nextPagingInfo = this.prevSkipToken.filter((item) => { return item.pageNo === +this.state.pagination.currentPage - 1 })[0]?.token;
        }
        this.isNextPage = false;
        this.isPageSearch = false;
        this.ExistingPageSearch(e);
    }

    resetPagination = (rowLimit: number, callback: any, pageCount?: number) => {
        var _cur = this;
        _cur.pageItemsPagingObj.nextPagingInfo = pageCount ? this.state.AllPagesNextPagingInfo : null;
        _cur.prevSkipToken = pageCount ? [{ "pageNo": 1, token: null }] : [];
        _cur.setState(prevState => ({
            pagination: {
                ...prevState.pagination,
                currentPage: 0,
                prevPage: 0,
                firstRecord: false,
                allPages: rowLimit === -1 ? true : false,
                endRecord: false,
                pageLimit: rowLimit,
                pageCount: pageCount ? pageCount : prevState.pagination.pageCount
            }
        }), () => {
            _cur.isNextPage = true;
            _cur.isPageSearch = true;
            if (callback && callback != undefined && typeof callback == "function") {
                callback();
            }
        })
    }

    getAllPagesCount = () => {
        var def = $.Deferred();
        var _cur = this;
        let isRoot = Akumina.Digispace.ConfigurationContext.IsSubsitePageDeliveryMode ? false : true;
        //If IsSubsitePageDeliveryMode, use PageDeliveryUrl else use root site url
        let siteUrl = Akumina.Digispace.ConfigurationContext.IsSubsitePageDeliveryMode ? Akumina.Digispace.ConfigurationContext.PageDeliveryUrl : Akumina.Digispace.SiteContext.SiteAbsoluteUrl;
        let spCaller = new Akumina.Digispace.Data.DataFactory(false);
        spCaller.SetContextUrl(siteUrl);
        spCaller.GetListItemCount("PageUrls_AK", isRoot).then(function (itemCount: any) {
            _cur.setState(prevState => ({
                pagination: {
                    ...prevState.pagination, pageCount: itemCount
                },
                AllPagesCount: itemCount
            }), () => {
                def.resolve()
            })
        }, function (error: any) {
            def.reject(error);
        });
        return def;
    }

    getListItemCountWithFilters(searchToken: string) {
        var def = $.Deferred();
        var listName = "PageUrls_AK";
        //If IsSubsitePageDeliveryMode, use PageDeliveryUrl else use root site url
        let siteUrl = Akumina.Digispace.ConfigurationContext.IsSubsitePageDeliveryMode ? Akumina.Digispace.ConfigurationContext.PageDeliveryUrl : Akumina.Digispace.SiteContext.SiteAbsoluteUrl;
        var url = siteUrl + "/_vti_bin/listdata.svc/" + listName + "/$count?$filter=substringof('" + searchToken + "',PageTitle)";

        if (Akumina.Digispace.SiteContext.IsHeadlessMode) {
            url = Akumina.Digispace.ConfigurationContext.ServiceHubURL + "/api/sharepoint/" + listName + "/itemcountwithfilter?siteUrl=" + siteUrl + "&$filter=substringof(%27" + searchToken + "%27,PageTitle)";
        }
        var request = {
            type: "GET",
            url: url,
            //cache: true,
            ...Akumina.Digispace.SiteContext.IsHeadlessMode && {
                headers: {
                    "Accept": "application/json; odata=verbose",
                    "X-Akumina-QueryKey": Akumina.Digispace.ConfigurationContext.InterchangeQueryKey
                },
                xhrFields: {
                    withCredentials: true
                }
            }
        }
        $.ajax(request).then(function (count: number) {
            def.resolve(count)
        }, function (error: any) {
            def.reject(error);
        });

        return def;
    }

    render() {
        var _cur = this;
        return (
            <div id="select-page-modal" className="ak-select-page-modal akv-modal akv-modal-medium">
                <header className="akv-modal-header">
                    <h2>{Akumina.Digispace.Language.TryGetText('summarylink.selectPage')}</h2>
                    <a href="#0" className="ak-modal-close akv-modal-close" onClick={e => (e.preventDefault(), this.props.CloseModal())}>
                        <i className="fa-regular fa-xmark" title={Akumina.Digispace.Language.TryGetText("common.close")} aria-label={Akumina.Digispace.Language.TryGetText("common.close")}></i>
                    </a>
                </header>
                <section className="akv-modal-content">
                    {this.state.IsLoading ? <div className="ia-widget-loader"></div> : null}
                    <div className="akv-form-row sticky-search-row">
                        <div className="akv-value akv-with-icon">
                            <input type="search" className="ak-search" placeholder={Akumina.Digispace.Language.TryGetText('summarylink.searchpages')} onKeyUp={this.HandleSearchTextChange} />
                            <i className="fa-regular fa-magnifying-glass" aria-hidden="true"></i>
                        </div>
                    </div>
                    <table className="akv-table akv-table-comfortable akv-selectable">
                        <thead>
                            <tr className="akv-selected">
                                <th>{Akumina.Digispace.Language.TryGetText('addnewpage.pagename')}</th>
                                <th>{Akumina.Digispace.Language.TryGetText('addnewpage.pageurl')}</th>
                            </tr>
                        </thead>
                        {(this.state.AllSearchedPages.length > 0) ?
                            <tbody>
                                {this.state.AllSearchedPages.map(function (i: any) {
                                    var isSelected = _cur.state.selectedPageUrl == i.pageUrl;
                                    return (
                                        <React.Fragment>
                                            <tr data-page={i.pageUrl} className={isSelected ? " akv-selected" : ""} onClick={(e: any) => _cur.SetSelectedPage(e)}>
                                                <td>{i.pageTitle}</td>
                                                <td>{i.pageUrlRaw}</td>
                                            </tr>
                                        </React.Fragment>
                                    )
                                }.bind(this))
                                }
                            </tbody> :
                            <React.Fragment>
                                <p className="akv-text-center">{Akumina.Digispace.Language.TryGetText("tray.nopagesfound")}</p>
                            </React.Fragment>
                        }
                    </table>
                    <div className="akv-pagination">
                        {+_cur.state.pagination.pageCount > 0 && (
                            <React.Fragment>
                                <span className="akv-pagination-page-number">
                                    <span id="startCount">{this.state.pagination.firstRecord ? 1 : (+this.state.pagination.prevPage * +this.state.pagination.pageLimit) + 1}</span>
                                    <span>&ndash;</span>
                                    {_cur.state.pagination.allPages ? (
                                        <span id="endCount">{this.state.pagination.pageCount} </span>
                                    ) : (
                                        <span id="endCount">{this.state.pagination.endRecord ? this.state.pagination.pageCount : +this.state.pagination.currentPage * +this.state.pagination.pageLimit} </span>
                                    )}
                                    <span>{Akumina.Digispace.Language.TryGetText("permission.of")} </span>
                                    <span id="pageCount">{this.state.pagination.pageCount}</span>
                                </span>
                                <React.Fragment>
                                    {!_cur.state.pagination.allPages && (
                                        <React.Fragment>
                                            <button className="prev-page akv-btn-form akv-btn-pagination" disabled={this.state.pagination.firstRecord} onClick={function (e) { e.preventDefault(); return _cur.onPrevPage(e) }}>
                                                <i className="fa-regular fa-angle-left"></i>
                                            </button>
                                            <button className="next-page akv-btn-form akv-btn-pagination" disabled={this.state.pagination.endRecord} onClick={function (e) { e.preventDefault(); return _cur.onNextPage(e) }}>
                                                <i className="fa-regular fa-angle-right"></i>
                                            </button>
                                        </React.Fragment>
                                    )}
                                </React.Fragment>
                            </React.Fragment>
                        )} </div>
                </section>
                <footer className="akv-modal-footer">
                    <button className="btn-form akv-btn akv-btn-text btn-close-popup" onClick={e => this.props.CloseModal()}>{Akumina.Digispace.Language.TryGetText('common.cancel')}</button>
                    <button className="btn-form akv-btn akv-primary" onClick={this.SelectPage} disabled={this.state.selectedPageUrl === ''}>{Akumina.Digispace.Language.TryGetText('common.select')}</button>
                </footer>
            </div>
        )
    }
}