import Akumina = require("akumina-core");
import React = require("react");
import { IPersona } from "../js/widgets/SummaryLinksWidget";

interface IPersonaProps {
    handlePersonaUpdate: any;
    selectedPersona?: Array<IPersona>;
}

interface IPersonaState {
    persona: Array<IPersonaDetails>,
    searchedPersonas: Array<IPersonaDetails>,
    selectedPersona: Array<string>,
}

interface IPersonaDetails {
    id: number;
    personaName: string;
    description: string;
    isChecked: boolean;
    termId: string;
}

export class Persona extends React.Component<IPersonaProps, IPersonaState> {
    constructor(props: IPersonaProps) {
        super(props);
        this.state = {
            persona: [],
            searchedPersonas: [],
            selectedPersona: this.getSelectedPersona(this.props.selectedPersona),
        };

        this.onPersonaSearch = this.onPersonaSearch.bind(this);
        this.onPersonaSelectionToggle = this.onPersonaSelectionToggle.bind(this);
        this.onPersonaRemove = this.onPersonaRemove.bind(this);
    }

    componentDidMount() {
        var _cur = this;
        Akumina.Digispace.UserContext.GetUserAuthorizedPersona(Akumina.Digispace.UserContext.GraphUserId).then(function (userPersonas: Array<string>) {
            if (userPersonas) {
                let model = _cur.createPersonaModel(userPersonas);
                let persona = _cur.tickExistingPersonas(model);
                _cur.setState({ persona: persona, searchedPersonas: persona });
            }
        }, function (error: any) {
            (Akumina as any).AddIn.Logger.WriteErrorLog(error);
        });
    }

    tickExistingPersonas(persona: Array<IPersonaDetails>) {
        this.state.selectedPersona.map(function (item: string) {
            let index = persona.findIndex(x => x.personaName.toLowerCase() === item.toLowerCase());
            if (index !== -1) {
                persona[index].isChecked = !persona[index].isChecked;
            }
        });

        return persona;
    }

    getSelectedPersona(persona?: Array<IPersona>) {
        if (persona && persona.length > 0) {
            return persona.map(function (item: IPersona) {
                return item.label;
            });
        }

        return [];
    }

    createPersonaModel(persona: any) {
        var personData: IPersonaDetails[] = [];
        persona.map(function (item: any) {
            let value: IPersonaDetails = {
                id: item.id,
                personaName: item.personaName,
                description: item.description,
                isChecked: false,
                termId: item.termId
            }
            personData.push(value);
        });
        return personData;
    }

    onPersonaSearch(e: any) {
        var value = e.currentTarget.value;
        var forceSearch = e.key === 'Enter';
        var cur = this;
        setTimeout(function () {
            if (value && (forceSearch || value.length > 2)) {
                var searchedData = cur.state.persona.filter(function (persona: any) {
                    return persona.personaName.toLowerCase().indexOf(value.toLowerCase()) > -1
                });
                cur.setState({ searchedPersonas: searchedData });
            } else {
                cur.setState({ searchedPersonas: cur.state.persona });
            }
        }, 1000);
    }

    onPersonaSelectionToggle(e: any, index: number) {
        var _cur = this;
        var value = e.currentTarget.value;
        var selectedPersona = [..._cur.state.selectedPersona];
        var persona = [...this.state.searchedPersonas];
        persona[index].isChecked = !persona[index].isChecked;
        if (e.currentTarget.checked) {
            if (selectedPersona.indexOf(value) < 0) {
                selectedPersona.push(value);
            }
        } else {
            selectedPersona = selectedPersona.filter(function (val: string) {
                return val != value;
            });
        }
        this.setState({
            searchedPersonas: persona,
            selectedPersona: selectedPersona,
        });

        if (selectedPersona.indexOf('All') !== -1) {
            selectedPersona.splice(selectedPersona.indexOf('All'), 1);
        }

        //Send array of IPersonaDetails object for selected personas
        var personasWithIds = this.state.persona.filter(item => selectedPersona.indexOf(item.personaName) > -1);
        this.props.handlePersonaUpdate(personasWithIds);
    }

    onPersonaRemove(e: any, value: string) {
        var persona = [...this.state.searchedPersonas];
        var index = persona.findIndex(x => x.personaName.toLowerCase() === value.toLowerCase());
        var selectedPersona = this.state.selectedPersona.filter(function (val: string) {
            return val != value;
        });

        if (index !== -1) {
            persona[index].isChecked = !persona[index].isChecked;
        }

        this.setState({
            searchedPersonas: persona,
            selectedPersona: selectedPersona,
        });
        this.props.handlePersonaUpdate(selectedPersona);
    }

    render() {
        var cur = this;
        return (
            <React.Fragment>
                <div>
                    <div className="akv-form-row">
                        <div className="akv-value akv-with-icon">
                            <input type="text" placeholder={Akumina.Digispace.Language.TryGetText("persona.searchpersona")} className="ak-icon ak-search" onKeyUp={this.onPersonaSearch} />
                            <i className="fa-regular fa-magnifying-glass" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div className="akv-chip-collection">
                        {this.state.selectedPersona.length > 0 && (
                            this.state.selectedPersona.map(function (item: string) {
                                return (
                                    item.toLowerCase() !== "all" && (
                                        <div className="akv-chip" data-closable>
                                            <span>{item}</span>
                                            <button aria-label="Delete Chip" className="akv-chip-action" type="button" onClick={(e) => cur.onPersonaRemove(e, item)}>
                                                <i className="fa-regular fa-xmark" title="Delete chip"></i>
                                            </button>
                                        </div>)
                                )
                            }))}
                    </div>
                    {this.state.searchedPersonas.length > 0 ? (
                        <table className="akv-table akv-table-comfortable">
                            <thead>
                                <tr>
                                    <th style={{ width: "5%" }}></th>
                                    <th align="left" style={{ width: "45%" }}>{Akumina.Digispace.Language.TryGetText("common.title")}</th>
                                    <th align="left" style={{ width: "50%" }}>{Akumina.Digispace.Language.TryGetText("persona.description")}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.state.searchedPersonas.map(function (item: IPersonaDetails, index: number) {
                                    return (
                                        <tr className={item.isChecked ? "akv-selected" : ""}>
                                            <td>
                                                <label className="akv-checkbox-wrapper">
                                                    <input type="checkbox" value={item.personaName} checked={item.isChecked} onChange={(e) => cur.onPersonaSelectionToggle(e, index)} />
                                                    <span className="akv-checkbox"></span>
                                                </label>
                                            </td>
                                            <td>{item.personaName}</td>
                                            <td>{item.description}</td>
                                        </tr>
                                    )
                                }.bind(this))
                                }
                            </tbody>
                        </table>
                    ) : (<div>
                        <p>{Akumina.Digispace.Language.TryGetText("persona.nopersonas")}</p>
                    </div>)}
                </div>
            </React.Fragment>
        )
    }
}
