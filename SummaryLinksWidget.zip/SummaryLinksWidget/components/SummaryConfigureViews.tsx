import * as Akumina from 'akumina-core';
import React = require("react");

interface ISummaryConfigureViewsProps {
    CollectionId: string;
    CloseModal: any;
    SenderId: string;
    AvailableViews: Array<any>;
    SelectedView: string;
    SaveWidgetProperties: any;
    AllViewObjectsArray: Array<any>;
}
interface ISummaryConfigureViewsState {
    Search: string;
    WidgetInstance: any;
    AvailableViews: Array<any>;
    FilteredAvailableViews: Array<any>;
    SelectedView: string;
    saveView: boolean;
}

export class SummaryConfigureViews extends React.Component<ISummaryConfigureViewsProps, ISummaryConfigureViewsState>{
    private inputRef: React.RefObject<HTMLInputElement>;
    constructor(props: ISummaryConfigureViewsProps) {
        super(props);
        this.inputRef = React.createRef();
        var relativeTemplateUrl = this.props.SelectedView.toLowerCase().replace(Akumina.Digispace.SiteContext.SiteAbsoluteUrl.toLowerCase(), "").replace(Akumina.Digispace.ConfigurationContext.ConfigurationSiteUrl.toLowerCase(), "")
        let availableviews = this.props.AllViewObjectsArray.filter(view => this.props.AvailableViews.map(name => name.toLowerCase()).indexOf(view.ViewTemplateUrl.toLowerCase()) > -1);
        this.state = {
            Search: "",
            WidgetInstance: undefined,
            AvailableViews: this.mapViewIcons(availableviews),
            FilteredAvailableViews: this.mapViewIcons(availableviews),
            SelectedView: relativeTemplateUrl,
            saveView: true,
        }
        this.SavePageClicked = this.SavePageClicked.bind(this);
        this.OnViewSelectionClick = this.OnViewSelectionClick.bind(this);
        this.Search = this.Search.bind(this);

    }


    componentDidUpdate(prevProps: ISummaryConfigureViewsProps) {
        if (prevProps.SelectedView != this.props.SelectedView) {
            let availableviews = this.props.AllViewObjectsArray.filter(view => this.props.AvailableViews.map(name => name.toLowerCase()).indexOf(view.ViewTemplateUrl.toLowerCase()) > -1);
            this.setState({
                SelectedView: this.props.SelectedView,
                AvailableViews: this.mapViewIcons(availableviews),
                FilteredAvailableViews: this.mapViewIcons(availableviews)
            });
        }
    }

    Search(evt: React.SyntheticEvent) {
        evt.preventDefault();
        var value = (evt.currentTarget as HTMLInputElement).value.toLowerCase();
        var filteredAvailableViews = this.state.AvailableViews.filter((x) => (x.displayText.toLowerCase().indexOf(value) > -1));
        this.setState({ Search: value, FilteredAvailableViews: filteredAvailableViews });
    }

    OnViewSelectionClick(evt: React.SyntheticEvent) {
        evt.preventDefault();
        var atag = evt.currentTarget as HTMLAnchorElement;
        var url = atag.dataset.url as string;
        this.setState({ SelectedView: url, saveView: url.toLowerCase() == this.props.SelectedView.toLowerCase() });
    }

    SavePageClicked() {
        this.setState({
            saveView: true
        });
        var _cur = this;
        var widgetProps = { displaytemplateurl: this.state.SelectedView };
        Akumina.Digispace.AppPart.Eventing.Publish('/loader/showloading/');
        this.props.SaveWidgetProperties(widgetProps).then(function (model: any) {
            Akumina.Digispace.AppPart.Eventing.Publish('/loader/hideloading/');
            var propertyChangeModel = { properties: ["displaytemplateurl"], model: model };
            Akumina.Digispace.AppPart.Eventing.Publish('/summarylist/propertychanged/' + _cur.props.SenderId, propertyChangeModel);
            _cur.props.CloseModal(false);
        }, function (error: any) {
            _cur.setState({
                saveView: false
            });
            Akumina.Digispace.AppPart.Eventing.Publish('/loader/hideloading/');
        });
    }

    render() {
        var _cur = this;
        return (
            <div id="choose-view-modal" className="ak-choose-view-modal akv-modal akv-modal-large">
                <header className="akv-modal-header">
                    <h2>
                        {Akumina.Digispace.Language.GetText("summarylink.configureviews.heading")}
                    </h2>
                    <a href="#0" className="ak-modal-close akv-modal-close" onClick={e => (e.preventDefault(), this.props.CloseModal())}>
                        <i className="fa-regular fa-xmark" title={Akumina.Digispace.Language.TryGetText("common.close")} aria-label={Akumina.Digispace.Language.TryGetText("common.close")}></i>
                    </a>
                </header>
                <section className="akv-modal-content">
                    <p>{Akumina.Digispace.Language.GetText("summarylink.configureviews.chooseaview")}</p>
                    <div className="akv-form-row sticky-search-row">
                        <div className="akv-value akv-with-icon">
                            <input type="search" className="ak-search" placeholder="Search Views" value={this.state.Search} onChange={(e) => this.Search(e)} />
                            <i className="fa-regular fa-magnifying-glass" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div className="akv-grid akv-grid-7-col">
                        {this.state.FilteredAvailableViews.map((x: any) =>
                            <div className="akv-grid-col">
                                <a href="#!" data-url={x.url} onClick={(e) => _cur.OnViewSelectionClick(e)}
                                    className={"akv-view-wrapper " + (x.url.toLowerCase() == _cur.state.SelectedView.toLowerCase() ? "akv-selected" : "")} >
                                    <div className={"akv-view-wireframe " + x.className}></div>
                                    <div title={x.displayText} className="akv-view-title">{x.displayText}</div>
                                </a>
                            </div>)
                        }
                    </div>
                    <div className="akv-form-row">
                        <div className="akv-help-text">{decodeURIComponent(_cur.state.SelectedView.toLowerCase())}</div>
                    </div>
                </section>
                <footer className="akv-modal-footer">
                    <button className="btn-form akv-btn akv-btn-text" onClick={this.props.CloseModal}>{Akumina.Digispace.Language.GetText("common.cancel")}</button>
                    <button className="btn-form akv-btn akv-primary" onClick={this.SavePageClicked} disabled={this.state.saveView}>{Akumina.Digispace.Language.GetText("common.save")}</button>
                </footer>
            </div>
        )
    }

    private mapViewIcons(AvailableViews: Array<string>) {
        var mappingArray = [
            { viewTitle: 'default.html', classname: "ak-default", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnamedefault') },
            { viewTitle: 'linkedlist.html', classname: "ak-link-list", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnamelinkedlist') },
            { viewTitle: 'linkedlistwiththumbnails.html', classname: "ak-image-link-list", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnamelinkedlistwiththumbnails') },
            { viewTitle: 'expandinglist.html', classname: "ak-expanding-group", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnameexpandinglist') },
            { viewTitle: 'expandinglistnogroups.html', classname: "ak-expanding-list", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnameexpandinglistnogroups') },
            { viewTitle: 'featuredbox.html', classname: "ak-image-on-top", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnamefeaturedbox') },
            { viewTitle: 'expandinglistalllevel.html', classname: "ak-faq", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnameexpandinglistall') },
            { viewTitle: 'defaultcarousel.html', classname: "ak-default-carousel", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnamedefaultcarousel') },
            { viewTitle: 'calltoaction.html', classname: "ak-cta", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnamecalltoaction') },
            { viewTitle: 'calltoinformation.html', classname: "ak-cti", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.viewnamecalltoinfo') },
            { viewTitle: 'tiledgroupwithlink.html', classname: "ak-tiled-group", displayText: Akumina.Digispace.Language.GetText('summarylink.configureviews.tiledgroupwithlink') },
        ];

        return AvailableViews.map((view: any) => {
            var filterMapObject = mappingArray.filter(function (mapObject) { return mapObject.viewTitle == view.ViewTemplateUrl.toLowerCase().split("/").slice(-1).join(); });
            var mapObject;
            if (filterMapObject.length == 0) {
                mapObject = {
                    classname: "ia-slw-" + view.ViewName.replace(/\s+/g, '-'),
                    displayText: view.ViewName
                };
            }
            else
                mapObject = filterMapObject[0];
            return { url: view.ViewTemplateUrl, className: mapObject.classname, displayText: mapObject.displayText }
        });
    }
}