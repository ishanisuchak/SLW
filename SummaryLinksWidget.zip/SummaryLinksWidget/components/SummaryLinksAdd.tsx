import Akumina = require("akumina-core");
import React = require("react");
import { SummaryLinksViewPickers } from "./SummaryLinksViewPickers";
import ImageUploaderComponent, { ISelectedImage } from "../../../components/ImageUploaderComponent";
import { ISLWListItem } from "./SummaryLinksEditComponent";
import { ISummaryLinksDataItem, IPersona, SummaryLinksWidget } from "../js/widgets/SummaryLinksWidget";
import { ILanguageObject } from "./language/SummaryLinksCreateLanguageVersions";
import { ISLWExistingLang } from "./SummaryLinksAddEditGroup";
import { Persona } from "./Persona";

declare var CKEDITOR: any;
declare var window: any;

interface ISummaryLinksAddProps {
    CollectionId: string;
    CloseModal: any;
    GroupList: Array<any>;
    RootNodeGuid: string;
    ItemToEdit?: ISummaryLinksDataItem;
    AllItemList: Array<any>;
    ListName: string;
    UseRoot: boolean;
    SenderId: string;
}
interface ISummaryLinksAddState {
    NodeName: string;
    Title: string;
    Summary: string;
    Link: string;
    LinkTarget: string;
    Tooltip: string;
    Image: ISelectedImage;
    ImageName: string;
    ImageAlternativeText: string;
    ParentNodeGuid: string;
    DisplayOrder: number;

    ErrorTitle: boolean;
    ErrorUrl: boolean;
    RbPasteUrl: boolean;
    RbPageUrl: boolean;
    RbDocUrl: boolean;
    RbImgPasteUrl: boolean;
    RbImgPickUrl: boolean;

    ActiveModal: string;
    IsLinkUrlModal: boolean;

    IsLoading: boolean;
    CollectionExistInLangs: Array<ISLWExistingLang>;
    IsCkEditorLoaded: boolean;

    SelectedPersonas: string;
    SelectedTab: string;

    isCkEditorImagePicker: boolean;
    ckeditorTabName: string

    //handles #external logic
    isExternalLink: boolean;

}
interface IPrivateVars {
    PICKERS: any;
}
export class SummaryLinksAdd extends React.Component<ISummaryLinksAddProps, ISummaryLinksAddState>{
    private pVars: IPrivateVars;
    private personaTermsFromCache: any;
    constructor(props: ISummaryLinksAddProps) {
        super(props);
        window.CKEDITOR_BASEPATH = (Akumina as any).Digispace.ConfigurationContext.FrameworkCDNPrefix + '/fe/common/v2/editor/ck/';
        this.pVars = {
            PICKERS: {
                PAGE: 'pagepicker',
                IMAGE: 'imagepicker',
                DOC: 'documentpicker',
                IMAGEUPLOADER: 'imageuploader'
            }
        };
        this.state = {
            NodeName: this.props.ItemToEdit ? this.props.ItemToEdit.Title : "",
            Title: this.props.ItemToEdit ? this.props.ItemToEdit.Title : "",
            Summary: this.props.ItemToEdit ? Akumina.Digispace.Utilities.RewriteImageUrlsForHeadless(this.props.ItemToEdit.Summary) : "",
            Link: this.props.ItemToEdit ? this.props.ItemToEdit.Link : "",
            LinkTarget: this.props.ItemToEdit ? this.props.ItemToEdit.LinkTargetValue : "New Window",
            Tooltip: this.props.ItemToEdit ? this.props.ItemToEdit.Tooltip : "",
            Image: this.props.ItemToEdit ? { imageUrl: this.FixImageUrl(this.props.ItemToEdit.ImageUrl), imageVersion: String(new Date().getTime()) } : { imageUrl: "", imageVersion: "" },
            ImageName: this.props.ItemToEdit ? this.GetFilenameFromURL(this.props.ItemToEdit.ImageUrl) : "",
            ImageAlternativeText: this.props.ItemToEdit ? this.props.ItemToEdit.ImageAlternativeText : "",
            ParentNodeGuid: this.props.ItemToEdit ? this.props.ItemToEdit.ParentNode : "",
            DisplayOrder: this.props.ItemToEdit ? this.props.ItemToEdit.DisplayOrder : 0,

            ErrorTitle: false,
            ErrorUrl: false,
            RbPasteUrl: true,
            RbPageUrl: false,
            RbDocUrl: false,
            RbImgPasteUrl: false,
            RbImgPickUrl: true,

            ActiveModal: "",
            IsLinkUrlModal: false,
            CollectionExistInLangs: [],
            IsLoading: false,
            IsCkEditorLoaded: false,

            SelectedPersonas: this.props.ItemToEdit ? this.CreatePersonaModel(this.props.ItemToEdit.Persona) : "",
            SelectedTab: "addlinktab",

            isCkEditorImagePicker: false,
            ckeditorTabName: "",
            isExternalLink: false,
        };
        this.ShowModal = this.ShowModal.bind(this);
        this.CloseModal = this.CloseModal.bind(this);
        this.SaveDataToList = this.SaveDataToList.bind(this);
        this.HandleInputChange = this.HandleInputChange.bind(this);
        this.HandleImgRBChange = this.HandleImgRBChange.bind(this);
        this.UpdateUrlSelectedFromModel = this.UpdateUrlSelectedFromModel.bind(this);
        this.UpdateImageUrl = this.UpdateImageUrl.bind(this);
        this.RemoveImg = this.RemoveImg.bind(this);
        this.AutoTranslateText = this.AutoTranslateText.bind(this);
        this.updateSelectedPersona = this.updateSelectedPersona.bind(this);
        this.handleIsExternalLinkChecked = this.handleIsExternalLinkChecked.bind(this);
    }

    CreatePersonaModel(personaData?: IPersona[]) {
        let personaStr = "";
        if (personaData && personaData.length > 0) {
            personaData.forEach((element, index) => {
                personaStr += index == 0 ? element.label + "|" + element.guId : ";" + element.label + "|" + element.guId
            });
        }
        return personaStr;
    }

    componentDidMount() {
        var _cur = this;
        this.GetLanguageVariations();
        SummaryLinksAdd.InitCkeditor().then(async function () {
            _cur.setState({ IsCkEditorLoaded: true });
            CKEDITOR.on('dialogDefinition', _cur.DialogDefinitionCallback);
            await SummaryLinksAdd.tryFetchExternalConfig();
            SummaryLinksAdd.initCkeditorInstance(_cur.props.SenderId);
        });
        this.personaTermsFromCache = Akumina.AddIn.Cache.Get(SummaryLinksWidget.personaCacheKey);
        if (!this.personaTermsFromCache) {
            SummaryLinksWidget.getPersonaTerms();
        }
    }

    componentWillUnmount() {
        CKEDITOR.removeListener('dialogDefinition', this.DialogDefinitionCallback);
    }

    FixImageUrl(imageUrl: string) {
        return imageUrl.replace(/'/g, function (c) {
            return '%' + c.charCodeAt(0).toString(16);
        });
    }

    public static InitCkeditor(): JQueryDeferred<any> {
        var def = $.Deferred();
        (typeof CKEDITOR === 'undefined') ?
            $.ajax({
                type: "GET",
                url: (Akumina as any).Digispace.ConfigurationContext.FrameworkCDNPrefix + '/fe/common/v2/editor/ck/' + 'ckeditor.min.js',
                dataType: "script",
                cache: true
            }).then(function (r) {
                CKEDITOR.disableAutoInline = true;
                def.resolve()
            }) :
            def.resolve();
        return def;
    }

    GetFilenameFromURL(linkUrl: string) {
        linkUrl = linkUrl.replace(/%27/g, "'");
        return linkUrl.substring(linkUrl.lastIndexOf("/") + 1);
    }
    ShowModal(picker: string, isCkEditorImagePicker: boolean = false, tabName: string = "") {
        switch (picker) {
            case this.pVars.PICKERS.PAGE:
                this.setState({
                    ActiveModal: this.pVars.PICKERS.PAGE,
                    IsLinkUrlModal: true,
                });
                break;
            case this.pVars.PICKERS.DOC:
                this.setState({
                    ActiveModal: this.pVars.PICKERS.DOC,
                    IsLinkUrlModal: true,
                });
                break;
            case this.pVars.PICKERS.IMAGE:
                this.setState({
                    ActiveModal: this.pVars.PICKERS.IMAGE,
                    IsLinkUrlModal: false,
                    isCkEditorImagePicker: isCkEditorImagePicker,
                    ckeditorTabName: tabName
                });
                break;
            case this.pVars.PICKERS.IMAGEUPLOADER:
                this.setState({
                    ActiveModal: this.pVars.PICKERS.IMAGEUPLOADER,
                    IsLinkUrlModal: false,
                });
                break;

        }
    }

    CloseModal() {
        this.setState({
            ActiveModal: "",
            isCkEditorImagePicker: false
        });
    }

    HandleInputChange(evt: React.SyntheticEvent) {
        //var value = e.target.value;
        var elem = evt.currentTarget as HTMLInputElement;
        var value = elem.value;
        this.setState({
            RbPasteUrl: value === "1",
            RbPageUrl: value === "2",
            RbDocUrl: value === "3",
            ErrorUrl: false,
        });
    }

    HandleImgRBChange(evt: React.SyntheticEvent) {
        //var value = e.target.value;
        var elem = evt.currentTarget as HTMLInputElement;
        var value = elem.value;
        this.setState({
            RbImgPasteUrl: value === "1",
            RbImgPickUrl: value === "2"
        });
    }

    SaveDataToList() {
        var _cur = this;
        var model = this.GetSaveModelFromState();
        var def: JQueryDeferred<any>;
        let isAutoTranslateEnabled = Akumina.Digispace.SiteContext.LicensingInformation && Akumina.Digispace.SiteContext.LicensingInformation.AutoTranslateEnabled
        if (this.ValidateGroupItems()) {
            this.setState({
                IsLoading: true
            });
            if (this.props.ItemToEdit) {
                var queryParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(this.props.ListName, model);
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                let updateDefs: Array<JQueryDeferred<any>> = [];
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                def = dataFactory.UpdateListItem(this.props.ListName, this.props.ItemToEdit.IntId, queryParams, _cur.props.UseRoot);
                updateDefs.push(def);

                $.when.apply($, updateDefs).then(function (result: any) {
                    _cur.props.CloseModal(true);
                }, function (error: any) {
                    (Akumina as any).AddIn.Logger.WriteErrorLog(error);
                    _cur.setState({ IsLoading: false });
                });
            } else {
                model.ItemGuid = Akumina.Digispace.Utilities.GetGuid();

                var translateDefs: Array<JQueryDeferred<any>> = [];     //For translating text
                var addDefs: Array<JQueryDeferred<any>> = [];           //Add items in list
                var translateData: Array<any> = [];

                var interchange = new Akumina.Digispace.Data.Interchange();
                var ExistingLanguageForCollection = Akumina.Digispace.ConfigurationContext.ActiveLanguages.filter(function (languageObject: ILanguageObject) {
                    return _cur.state.CollectionExistInLangs.findIndex(function (ExistingLang) {
                        return languageObject.LanguageId == ExistingLang.LangId;
                    }) !== -1;
                });
                ExistingLanguageForCollection.forEach(function (languageObject: ILanguageObject) {
                    var def: JQueryDeferred<any>;
                    var Item = { ...model };
                    Item.AkLanguageId = languageObject.languageId;
                    Item.AkLanguageCode = languageObject.Code;
                    //@ts-ignore
                    let isNonDefaultLang = Akumina.Digispace.ConfigurationContext.DefaultLanguage.languageId !== languageObject.LanguageId;
                    let title = isNonDefaultLang ? (languageObject.Code + " " + Item.Title) : Item.Title;
                    Item.Title = title;
                    Item.NodeName = title;

                    var queryParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, Item);
                    var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                    dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);

                    def = dataFactory.AddListItem(_cur.props.ListName, queryParams, _cur.props.UseRoot);
                    addDefs.push(def);
                });
                //Create list item for each language version
                $.when.apply($, addDefs).then(function () {
                    let defaultLanguageItem = Array.from(arguments).filter(x => x.AkLanguageId == Akumina.Digispace.UserContext.LanguageId)[0];
                    translateData.push({
                        id: defaultLanguageItem.Id,
                        text: defaultLanguageItem.NodeName,
                        langCode: defaultLanguageItem.AkLanguageCode,
                        AkLanguageId: defaultLanguageItem.AkLanguageId,
                        isNonDefaultLang: false
                    });
                    for (var i = 0; i < arguments.length; ++i) {
                        //@ts-ignore
                        if (Akumina.Digispace.ConfigurationContext.DefaultLanguage.languageId !== arguments[i].AkLanguageId) {
                            if (isAutoTranslateEnabled) {
                                //@ts-ignore AutoTranslateText is new method in 5.5
                                def = interchange.AutoTranslateText(model.NodeName, arguments[i].AkLanguageCode);
                                translateDefs.push(def);
                            }
                            translateData.push({
                                id: arguments[i].Id,
                                text: model.NodeName,
                                langCode: arguments[i].AkLanguageCode,
                                AkLanguageId: arguments[i].AkLanguageId,
                                isNonDefaultLang: true
                            });
                        }
                    }
                    if (isAutoTranslateEnabled) {
                        $.when.apply($, translateDefs).then(function () {
                            //Update list item with Translated text, AkId and Persona
                            _cur.UpdateListItems(translateData, arguments);
                        }, function (error: any) {
                            //Update list item with AkId and Persona even if translation fails
                            _cur.UpdateListItems(translateData);
                            (Akumina as any).Digispace.Logger.WriteErrorLog(error);
                            _cur.props.CloseModal(true);
                        });
                    }
                    else {
                        //Update list item with AkId and Persona
                        _cur.UpdateListItems(translateData);
                    }
                });
            }
        }
    }

    UpdateListItems = (translateData: Array<any>, args?: any) => {
        var _cur = this;
        var updateDefs: Array<JQueryDeferred<any>> = []; //Update AkId
        let defaultLanguageItem = Array.from(translateData).filter(x => x.AkLanguageId == Akumina.Digispace.UserContext.LanguageId)[0];
        var languageModel = {
            AkId: defaultLanguageItem.id
        }
        var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, languageModel);
        var updateDef: JQueryDeferred<any>;
        var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
        dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
        updateDef = dataFactory.UpdateListItem(_cur.props.ListName, defaultLanguageItem.id, queryLangParams, _cur.props.UseRoot);
        updateDefs.push(updateDef);

        if (args) {
            for (var i = 0; i < args.length; ++i) {
                var translatedText = args[i].Data;
                translatedText = translatedText == translateData[i + 1].text ? (translateData[i + 1].langCode + " " + translatedText) : translatedText;

                let model = {
                    Title: translatedText,
                    NodeName: translatedText,
                    AkId: defaultLanguageItem.id
                }

                var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, model);
                var updateDef: JQueryDeferred<any>;
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                updateDef = dataFactory.UpdateListItem(_cur.props.ListName, translateData[i + 1].id, queryLangParams, _cur.props.UseRoot);
                updateDefs.push(updateDef);
            }
        }
        else {
            for (var i = 1; i < translateData.length; ++i) {
                let model = {
                    AkId: defaultLanguageItem.id
                }

                var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, model);
                var updateDef: JQueryDeferred<any>;
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                updateDef = dataFactory.UpdateListItem(_cur.props.ListName, translateData[i].id, queryLangParams, _cur.props.UseRoot);
                updateDefs.push(updateDef);
            }
        }

        $.when.apply($, updateDefs).then(function (result: any) {
            _cur.props.CloseModal(true);
        }, function (error: any) {
            (Akumina as any).Digispace.Logger.WriteErrorLog(error);
            _cur.props.CloseModal(true);
        });
    }

    ValidateGroupItems() {
        var _cur = this;
        var itemExists = []; //this.props.AllItemList.filter(function (item) { return item.ParentNode === _cur.state.ParentNodeId && item.NodeName.toLowerCase() === _cur.state.NodeName.toLowerCase() })
        var isValidUrl = this.ValidateUrl(this.state.Link); //this.ValidateUrl(this.state.ImageURL) &&
        if (!Akumina.AddIn.Utilities.IsNullOrEmpty(this.state.NodeName) && isValidUrl && itemExists.length === 0) {
            return true
        }
        else {
            this.setState({ ErrorTitle: Akumina.AddIn.Utilities.IsNullOrEmpty(this.state.NodeName), ErrorUrl: !isValidUrl, SelectedTab: "addlinktab" });
            return false
        }
    }

    ValidateUrl(url: string) {
        var noSpclChars = /(http(s)?:\/\/.)(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&=]*)/g;
        var mailto = /^mailto:([^?]+)(?:\?(.+))?$/;
        var hasValidLength = false;
        var maxUrlLength = 255;

        if (url == null || url.length == 0) {
            hasValidLength = true;
        } else if (noSpclChars.test(url) && url.length > 0 && (maxUrlLength - url.length) >= 0) {
            hasValidLength = true;
        } else if (mailto.test(url) && url.length > 0 && (maxUrlLength - url.length) >= 0) {
            hasValidLength = true;
        }

        return hasValidLength;
    }


    //the purpose of this method is to add or remove #external which will prevent the url re-writing logic to happen on the render side
    //usecase, I purposely want the link to go to sharepoint and not stay in headless -JA
    externalHash = "#external";
    handleIsExternalLinkChecked(event: any) {
        var newLink = this.state.Link;
        if (event.target.checked) {
            if (!this.IsLinkExternal(this.state.Link)) {
                //dont put #external if it already contains a #, do nothing then. shrug -JA
                if (this.state.Link.indexOf("#") == -1) {
                    newLink = this.state.Link + this.externalHash;
                }
            };
        } else {
            newLink = this.state.Link.replace(this.externalHash, "");
        }

        this.setState({ isExternalLink: event.target.checked, Link: newLink })
    }

    IsLinkExternal(value: string): boolean {
        return value.toLowerCase().indexOf(this.externalHash) !== -1;
    }

    UpdateValueToState(evt: React.SyntheticEvent) {
        var _cur = this;
        var elem = evt.currentTarget as HTMLInputElement;
        var value = elem.value;
        var field = elem.dataset.field;
        switch (field) {
            case "Title":
                this.setState({ Title: value, NodeName: value, ErrorTitle: value.trim() == "" });
                break;
            case "Summary":
                this.setState({ Summary: value });
                break;
            case "Link":
                this.setState({ Link: value, ErrorUrl: !this.ValidateUrl(value) });
                break;
            case "LinkTarget":
                this.setState({ LinkTarget: value });
                break;
            case "Tooltip":
                this.setState({ Tooltip: value });
                break;
            case "ImageURL":
                this.setState({ Image: { imageUrl: _cur.FixImageUrl(value), imageVersion: "" }, ImageName: this.GetFilenameFromURL(value) });
                break;
            case "ImageAlternativeText":
                this.setState({ ImageAlternativeText: value });
                break;
            case "Group":
                var selectedGroup = this.props.GroupList.filter((x: any) => x.Id == value);
                var maxDisplayOrder = selectedGroup.length == 0 ? 0 : selectedGroup[0].MaxDisplayOrder + 1;
                this.setState({ ParentNodeGuid: value, DisplayOrder: maxDisplayOrder });
                break;
        }
    }

    UpdateUrlSelectedFromModel(linkUrl: string) {
        this.setState({
            Link: linkUrl,
        })
    }

    UpdateImageUrl(linkUrl: ISelectedImage) {
        linkUrl.imageUrl = this.FixImageUrl(linkUrl.imageUrl);
        this.setState({
            Image: linkUrl,
            ImageName: this.GetFilenameFromURL(linkUrl.imageUrl)
        });
    }

    RemoveImg() {
        this.setState({
            Image: { imageUrl: "", imageVersion: "" },
            ImageName: ""
        });
    }

    GetSaveModelFromState() {
        var GetImageUrl = function (imgUrl: string) {
            //In headless mode, when an existing link is edited, the image url will contain headless endpoint 'api/sharepoint/spfile'
            //eg: 'https://ak-main-qa.onakumina.com/api/sharepoint/spfile?siteurl=https://akuminadev02.sharepoint.com/sites/ak-main-qapune-211007&relativeurl=/sites/ak-main-qapune-211007/images_ak/freedom-trail.jpg'
            //Need to process this url to save as correct list path eg 'https://akuminadev02.sharepoint.com/sites/ak-main-qapune-211007/images_ak/freedom-trail.jpg'
            if (imgUrl && imgUrl.includes('api/sharepoint/spfile')) {
                let domain = Akumina.Digispace.SiteContext.SiteAbsoluteUrl.replace(Akumina.Digispace.SiteContext.SiteServerRelativeUrl, "");
                let splitImageUrl = imgUrl.substring(imgUrl.indexOf('?') + 1).toLowerCase().split('&');
                let relativeUrlPart = splitImageUrl.find((x: string) => x.includes('relativeurl')) || "";
                return domain + relativeUrlPart.substring(relativeUrlPart.indexOf("=") + 1);
            }
            else {
                return imgUrl;
            }
        }
        var MaxRootDisplayOrder = this.props.GroupList.length == 0 ? 1 : this.props.GroupList[0].MaxRootDisplayOrder + 1;
        MaxRootDisplayOrder += this.props.AllItemList.filter(x => x.ParentNode == this.props.RootNodeGuid).length;
        if (!this.personaTermsFromCache) {
            this.personaTermsFromCache = Akumina.AddIn.Cache.Get(SummaryLinksWidget.personaCacheKey);
        }
        let personaForAll = this.personaTermsFromCache.filter((term: any) => term.name.toLowerCase() == "all")[0];
        let selectedPersonas = this.state.SelectedPersonas != "" ? this.state.SelectedPersonas : personaForAll.name + "|" + personaForAll.guid;
        var SaveModel: ISLWListItem = {
            Title: this.state.Title,
            NodeName: this.state.NodeName,
            Summary: this.GetDescription(),
            NodeType: "Item",
            Link: { Url: this.state.Link, Description: "" },
            LinkTarget: this.state.LinkTarget,
            Image: { Url: GetImageUrl(this.state.Image.imageUrl || ""), Description: this.state.ImageAlternativeText },
            ParentNode: this.state.ParentNodeGuid == "" ? this.props.RootNodeGuid : this.state.ParentNodeGuid,
            DisplayOrder: this.state.DisplayOrder == 0 ? MaxRootDisplayOrder : this.state.DisplayOrder,
            Tooltip: this.state.Tooltip,
            CollectionId: this.props.CollectionId,
            //Persona_0 is the hidden note field for Persona tax field
            //Updating it in this format is undocumented
            //Format: Value1|TermId1;Value2|TermId2
            Persona_0: selectedPersonas
        }
        return SaveModel;
    }

    GetDescription() {
        if (typeof CKEDITOR !== 'undefined' && this.state.IsCkEditorLoaded) {
            return CKEDITOR.instances["description-" + this.props.SenderId].getData();
        } else {
            return this.state.Summary;
        }
    }

    AutoTranslateText(fieldType: string) {
        var _cur = this;
        var value = "";
        var AkLanguageCode = Akumina.Digispace.ConfigurationContext.ActiveLanguages.filter(x => x.LanguageId == Akumina.Digispace.UserContext.LanguageId)[0].Code;
        var interchange = new (Akumina as any).Digispace.Data.Interchange();

        switch (fieldType) {
            case "Title":
                value = this.state.NodeName;
                interchange.AutoTranslateText(value, AkLanguageCode).then(function (response: any) {
                    if (response) {
                        _cur.setState({
                            NodeName: response.Data
                        });
                    }
                }, function (error: any) {
                    (Akumina as any).AddIn.Logger.WriteErrorLog(error);
                });
                break;
            case "Description":
                value = _cur.GetDescription();
                interchange.AutoTranslateText(value, AkLanguageCode).then(function (response: any) {
                    if (response) {
                        CKEDITOR.instances["description-" + _cur.props.SenderId].setData(response.Data);
                    }
                }, function (error: any) {
                    (Akumina as any).AddIn.Logger.WriteErrorLog(error);
                });
                break;
            case "Tooltip":
                value = this.state.Tooltip;
                interchange.AutoTranslateText(value, AkLanguageCode).then(function (response: any) {
                    if (response) {
                        _cur.setState({
                            Tooltip: response.Data
                        });
                    }
                }, function (error: any) {
                    (Akumina as any).AddIn.Logger.WriteErrorLog(error);
                });
                break;
            case "imageText":
                value = this.state.ImageAlternativeText;
                interchange.AutoTranslateText(value, AkLanguageCode).then(function (response: any) {
                    if (response) {
                        _cur.setState({
                            ImageAlternativeText: response.Data
                        });
                    }
                }, function (error: any) {
                    (Akumina as any).AddIn.Logger.WriteErrorLog(error);
                });
                break;
        }
    }

    DialogDefinitionCallback = (ev: any) => {
        var dialogName = ev.data.name;
        var dialogDefinition = ev.data.definition;
        if (dialogName === 'image' && ev.editor.name === ("description-" + this.props.SenderId) && !dialogDefinition.getContents('info').elements.some(function (e: any) { return e.id === 'akImages' })) {

            var infoTab = dialogDefinition.getContents('info');
            var linkTab = dialogDefinition.getContents('Link');
            // Get the "Browse Server" button from the info and Link tabs
            var browseButtonArray = [infoTab.get('browse'), linkTab.get('browse')];

            // Override the "onClick" function
            browseButtonArray.forEach(browseButton => {
                // Override the "onClick" function
                browseButton.onClick = () => {
                    let tabName = browseButton.filebrowser.target.split(":")[0];
                    this.ShowModal(this.pVars.PICKERS.IMAGE, true, tabName);
                }
            });
        }
    }

    public static tryFetchExternalConfig = async () => {
        let ckEditorManager = Akumina.Digispace.CkEditorManager;
        if (ckEditorManager && ckEditorManager.GetCkEditor4ExternalConfig && typeof ckEditorManager.GetCkEditor4ExternalConfig === "function") {
            await ckEditorManager.GetCkEditor4ExternalConfig();
        }
    }

    public static initCkeditorInstance(senderId: string) {
        var ckCustomConfigPath = (Akumina as any).Digispace.ConfigurationContext.FrameworkCDNPrefix + '/fe/common/v2/editor/ck/' + 'custom_config.js';
        //this created new instance of ckeditor
        CKEDITOR.replace("description-" + senderId, SummaryLinksAdd.getCkEditorCustomConfiguration(ckCustomConfigPath));

        if (Akumina.Digispace.SiteContext.IsModernPage) {
            CKEDITOR.instances["description-" + senderId].on('instanceReady', function (evt: any) {
                var ele = document.getElementById(evt.editor.id + '_top');
                if (ele != null) {
                    (document as any).getElementById(evt.editor.id + '_top').style.display = "block";
                }
            });
        }
    }

    public static getCkEditorCustomConfiguration(ckCustomConfigPath: string) {
        return {
            customConfig: ckCustomConfigPath,
            removePlugins: "insertcontent,savecontent,savecontentas,sourcearea",
            toolbarGroups: [
                { name: 'editing', groups: ['spellchecker'] },
                { name: 'clipboard', groups: ['undo', 'clipboard'] },
                { name: 'links', groups: ['links', 'image'] },
                { name: 'insert', groups: ['insert'] },
                { name: 'tools', groups: ['tools', 'strike'] },
                { name: 'basicstyles', groups: ['basicstyles', 'cleanup'] },
                { name: 'paragraph', groups: ['list', 'blocks', 'align', 'bidi', 'paragraph'] },
                { name: 'styles', groups: ['styles'] },
                { name: 'akexternal', groups: ['akexternal'] },
                { name: 'document', groups: ['mode'] }
            ],
            height: 250,
            //Needed to show the Browse Server button
            filebrowserImageBrowseUrl: "/dummyurl"
        }
    }

    handleTabChange(selectedTab: string) {
        var _cur = this;
        _cur.setState({
            SelectedTab: selectedTab,
        });
    }

    updateSelectedPersona(persona: Array<any>) {
        var _cur = this;
        //Create a string of format: Value1|TermId1;Value2|TermId2 for selected personas
        //To be used to add/update persona field
        var personaStr = "";
        persona.forEach((element, index) => {
            personaStr += index == 0 ? element.personaName + "|" + element.termId : ";" + element.personaName + "|" + element.termId
        });
        _cur.setState({
            SelectedPersonas: personaStr,
        });
    }

    render() {
        var isNonDefaultLanguage = (Akumina.Digispace.ConfigurationContext.DefaultLanguage as any).languageId !== Akumina.Digispace.UserContext.LanguageId;
        var viewPickerModal = null;
        var pickerToShow = this.state.RbPageUrl ? this.pVars.PICKERS.PAGE : (this.state.RbDocUrl ? this.pVars.PICKERS.DOC : "");
        switch (this.state.ActiveModal) {
            case this.pVars.PICKERS.PAGE:
                viewPickerModal = <SummaryLinksViewPickers CloseModal={this.CloseModal} UpdateLinkUrl={this.UpdateUrlSelectedFromModel} />
                break;
            case this.pVars.PICKERS.IMAGE:
                let props;
                //If the image uploader modal was opened through the ckeditor
                //Update the selected image in ck editor
                if (this.state.isCkEditorImagePicker) {
                    const dialog = CKEDITOR.dialog.getCurrent();
                    props = {
                        CloseModal: this.CloseModal,
                        UpdateLinkUrl: (imageObj: any) => {
                            let imageUrl = imageObj.imageUrl;
                            if (Akumina.Digispace.SiteContext.IsHeadlessMode) {
                                let contextSiteUrl = Akumina.Digispace.ConfigurationContext.TenantUrl + Akumina.Digispace.SiteContext.WebServerRelativeUrl;
                                imageUrl = Akumina.Digispace.ConfigurationContext.ServiceHubURL
                                    + "/api/sharepoint/spfile?siteurl=" + contextSiteUrl
                                    + "&relativeUrl=" + imageUrl.replace(Akumina.Digispace.ConfigurationContext.TenantUrl, "");
                            }
                            dialog.setValueOf(this.state.ckeditorTabName, 'txtUrl', imageUrl);
                        },
                        SelectedImageUrl: dialog.getValueOf(this.state.ckeditorTabName, 'txtUrl'),
                        RelativePathToImageLibrary: Akumina.Digispace.SiteContext.WebServerRelativeUrl,
                        ImageLibraryName: "Images_AK",
                        IsRoot: false
                    };
                }
                //If the image uploader modal was opened from the pick image button
                //Update the selected image in state.Image
                else {
                    props = {
                        CloseModal: this.CloseModal,
                        UpdateLinkUrl: this.UpdateImageUrl,
                        SelectedImageUrl: this.state.Image.imageUrl,
                        RelativePathToImageLibrary: Akumina.Digispace.SiteContext.WebServerRelativeUrl,
                        ImageLibraryName: "Images_AK",
                        IsRoot: false
                    }
                }
                viewPickerModal = <ImageUploaderComponent CloseModal={props.CloseModal} UpdateLinkUrl={props.UpdateLinkUrl} SelectedImageUrl={props.SelectedImageUrl} RelativePathToImageLibrary={props.RelativePathToImageLibrary} ImageLibraryName={props.ImageLibraryName} IsRoot={props.IsRoot} />;
                break;
        }
        let showAutoTranslateButton = Akumina.Digispace.SiteContext.LicensingInformation && Akumina.Digispace.SiteContext.LicensingInformation.AutoTranslateEnabled;

        var imageUrl = this.state.Image.imageUrl;
        if (imageUrl) {
            imageUrl = (imageUrl.toLowerCase().indexOf("sharepoint/spfile?") == -1 && imageUrl.toLowerCase().indexOf(Akumina.Digispace.ConfigurationContext.FrameworkCDNPrefix) == -1) ? Akumina.Digispace.ConfigurationContext.ServiceHubURL
                + "/api/sharepoint/spfile?siteurl=" + Akumina.Digispace.SiteContext.SiteAbsoluteUrl
                + "&relativeUrl=" + imageUrl.replace(Akumina.Digispace.SiteContext.SiteAbsoluteUrl.toLowerCase(), Akumina.Digispace.SiteContext.SiteServerRelativeUrl.toLowerCase()) : imageUrl;
        } else {
            imageUrl = "";
        }

        let linkImage = this.state.Image.imageUrl ? { backgroundImage: 'url(\'' + imageUrl + (imageUrl.includes('api/sharepoint/spfile') ? '&t=' : '?t=') + this.state.Image.imageVersion + '\')' } : {};

        // External Link Additions //
        var isExternalLink = this.state.isExternalLink;
        if (this.IsLinkExternal(this.state.Link)) {
            isExternalLink = true;
        } else if (this.state.Link == "") {
            isExternalLink = false;
        }
        //doing this so majority of customers in english dont need to update lang token -JA
        var isExternalLinkLabel = "Is External?";
        var isExternalLinkTranslatedLabel = Akumina.Digispace.Language.TryGetText('summarylink.isexternallink');
        if (isExternalLinkTranslatedLabel.indexOf('summarylink.isexternallink') == -1) {
            isExternalLinkLabel = isExternalLinkTranslatedLabel;
        };
        // External Link Additions //

        return (
            <React.Fragment>
                <div id="new-link-modal" className="ak-new-link-modal akv-modal akv-modal-medium">
                    <header className="ak-modal-header akv-modal-header">
                        <h2>{this.props.ItemToEdit ? Akumina.Digispace.Language.TryGetText('summarylink.edit.label_editlink') : Akumina.Digispace.Language.TryGetText('summarylink.edit.label_addlink')}</h2>
                        <a href="#0" className="akv-modal-close" onClick={e => (e.preventDefault(), this.props.CloseModal())}>
                            <i className="fa-regular fa-xmark" title={Akumina.Digispace.Language.TryGetText("common.close")} aria-label={Akumina.Digispace.Language.TryGetText("common.close")}></i>
                        </a>
                    </header>
                    <section className="ak-modal-content akv-padding-0 ak-modal-with-tabs akv-modal-content akv-modal-with-tabs">
                        {this.state.IsLoading ? <div className="ia-widget-loader"></div> : null}
                        <ul className="ak-tabs akv-tabs akv-padding-t-12">
                            <li className={(this.state.SelectedTab === "addlinktab" ? "akv-active" : "")} onClick={(e) => this.handleTabChange("addlinktab")}><a>{Akumina.Digispace.Language.TryGetText("addpagetab.details")}</a></li>
                            <li className={(this.state.SelectedTab === "personatab" ? "akv-active" : "")} onClick={(e) => this.handleTabChange("personatab")}><a>{Akumina.Digispace.Language.TryGetText("addpagetab.personas")}</a></li>
                        </ul>
                        <section className="akv-tab-content akv-padding-x-24" style={{ display: "block" }}>
                            <div className={(this.state.SelectedTab === "addlinktab" ? "akv-active" : "mfp-hide")}>
                                <div className={"akv-form-row akv-has-position-action " + (this.state.ErrorTitle ? "akv-has-error" : "")}>
                                    <label>{Akumina.Digispace.Language.TryGetText('common.title')}</label>
                                    <div className={"akv-value " + (isNonDefaultLanguage ? "ak-icon-value" : "")}>
                                        <input data-field="Title" onChange={e => this.UpdateValueToState(e)} value={this.state.NodeName} type="text" maxLength={255} />
                                        {isNonDefaultLanguage && showAutoTranslateButton &&
                                            <div className="ak-icon-btn akv-positioned-action">
                                                <a href="javascript:void(0)" className="akv-btn akv-btn-icon" onClick={() => this.AutoTranslateText("Title")}>
                                                    <i className="fa-regular fa-globe"></i>
                                                </a>
                                            </div>
                                        }
                                    </div>
                                    {this.state.ErrorTitle ? <div className="akv-error-message">{Akumina.Digispace.Language.TryGetText('summarylink.error.titleerror')}</div> : null}
                                </div>
                                <div className="akv-form-row akv-has-position-action">
                                    <label>{Akumina.Digispace.Language.TryGetText("common.description")}</label>
                                    <div className={"akv-value " + (isNonDefaultLanguage ? "ak-icon-value akv-icon-textarea ak-icon-ckeditor" : "")}>
                                        <textarea id={"description-" + this.props.SenderId} data-field="Summary" onKeyUp={e => this.UpdateValueToState(e)} value={this.state.IsCkEditorLoaded ? this.state.Summary : ""} maxLength={2048} ></textarea>
                                        {isNonDefaultLanguage && showAutoTranslateButton &&
                                            <div className="ak-icon-btn akv-positioned-action">
                                                <a href="javascript:void(0)" className="akv-btn akv-btn-icon" onClick={() => this.AutoTranslateText("Description")}>
                                                    <i className="fa-regular fa-globe"></i>
                                                </a>
                                            </div>
                                        }
                                    </div>
                                </div>
                                <div className={"akv-form-row akv-form-list" + (this.state.ErrorUrl ? "akv-has-error" : "")}>
                                    <label>{Akumina.Digispace.Language.TryGetText('summarylink.linkurl')}</label>
                                    <div className="akv-value akv-value-multiple">
                                        <div className="akv-radio-wrapper">
                                            <label>
                                                <input type="radio" name="linktype" onClick={e => this.HandleInputChange(e)} checked={this.state.RbPasteUrl} value="1" />
                                                <span className="akv-radio"></span>
                                                <span className="akv-radio-label">{Akumina.Digispace.Language.TryGetText('summarylink.pasteurl')}</span>
                                            </label>
                                        </div>
                                        <div className="akv-radio-wrapper">
                                            <label>
                                                <input type="radio" onClick={e => this.HandleInputChange(e)} name="linktype" checked={this.state.RbPageUrl} value="2" />
                                                <span className="akv-radio"></span>
                                                <span className="akv-radio-label">{Akumina.Digispace.Language.TryGetText('summarylink.selectPage')}</span>
                                            </label>
                                        </div>
                                        {/* { <div className="ak-radio-wrapper">
                                            <label>
                                                <input type="radio" onClick={e => this.HandleInputChange(e)} name="linktype" checked={this.state.RbDocUrl} value="3" disabled={isNonDefaultLanguage} />
                                                <span className="ak-radio"></span>
                                                <span className="ak-radio-label">{Akumina.Digispace.Language.TryGetText('summarylink.selectdocument')}</span>
                                            </label>
                                        </div>} */}
                                    </div>
                                </div>
                                <div className={"ak-picker-group akv-form-row" + (this.state.ErrorUrl ? " akv-has-error" : "")}>
                                    <div className="akv-value akv-input-group akv-no-gap">
                                        <input data-field="Link" onChange={e => this.UpdateValueToState(e)} maxLength={255} value={this.state.Link} type="text" className="listname" disabled={!this.state.RbPasteUrl} />
                                        {this.state.RbPageUrl || this.state.RbDocUrl ?
                                            <>
                                                <input onClick={e => this.ShowModal(pickerToShow)} type="button" className="akv-btn akv-btn-icon" value="..." />

                                            </>
                                            : null
                                        }
                                    </div>
                                    {this.state.ErrorUrl ? <div className="akv-error-message">{Akumina.Digispace.Language.TryGetText('summarylink.error.urlerror')}</div> : null}
                                </div>
                                <div className="akv-form-row">
                                    <div className="akv-value">
                                        <label className="akv-checkbox-wrapper">
                                            <input type="checkbox" name="isExternalLinkCheckBox" onChange={this.handleIsExternalLinkChecked} checked={isExternalLink} />
                                            <span className="akv-checkbox"></span>
                                            <span>{isExternalLinkLabel}</span>
                                        </label>
                                    </div>
                                </div>
                                <div className="akv-form-row">
                                    <label>{Akumina.Digispace.Language.TryGetText('summarylink.linktarget')}</label>
                                    <div className="akv-value">
                                        <select data-field="LinkTarget" onChange={e => this.UpdateValueToState(e)} value={this.state.LinkTarget}>
                                            <option value="New Window">{Akumina.Digispace.Language.TryGetText('summarylink.newwindow')}</option>
                                            <option value="Same Window">{Akumina.Digispace.Language.TryGetText('summarylink.samewindow')}</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="akv-form-row akv-has-position-action">
                                    <label>{Akumina.Digispace.Language.TryGetText('summarylink.tooltip')}</label>
                                    <div className={"akv-value " + (isNonDefaultLanguage ? "ak-icon-value" : "")}>
                                        <input data-field="Tooltip" onChange={e => this.UpdateValueToState(e)} value={this.state.Tooltip} type="text" maxLength={255} />
                                        {isNonDefaultLanguage && showAutoTranslateButton &&
                                            <div className="ak-icon-btn  akv-positioned-action">
                                                <a href="javascript:void(0)" className="akv-btn akv-btn-icon" onClick={() => this.AutoTranslateText("Tooltip")}>
                                                    <i className="fa-regular fa-globe"></i>
                                                </a>
                                            </div>
                                        }
                                    </div>
                                </div>
                                <div className="akv-form-row akv-form-list">
                                    <label>{Akumina.Digispace.Language.TryGetText('summarylink.imageurl')}</label>
                                    <div className="akv-value ak-img-preview-container">
                                        <div className="ak-img-preview-wrapper">
                                            {/* image hash is being appended to the image url because if we overwrite an existing image with another image of the same name, then it used to not refresh the same on UI as URL would would not change(added a cachebreaker at the end of the url) */}
                                            <div className="ak-img-preview" style={linkImage}></div>
                                            <div style={{ display: this.state.Image.imageUrl ? "" : "none" }}>
                                                <a className="ak-remove-preview" onClick={this.RemoveImg}>
                                                    <i className="fa fa-times-circle"></i>
                                                    {Akumina.Digispace.Language.TryGetText('imageuploader.removeimage')}
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="akv-value akv-value-multiple akv-img-selector">
                                        <div className="akv-radio-wrapper">
                                            <label>
                                                <input type="radio" name="imagelinktype" onClick={e => this.HandleImgRBChange(e)} checked={this.state.RbImgPasteUrl} value="1" disabled={isNonDefaultLanguage} />
                                                <span className="akv-radio"></span>
                                                <span className="akv-radio-label">{Akumina.Digispace.Language.TryGetText('summarylink.pasteurl')}</span>
                                            </label>
                                        </div>
                                        <div className="akv-radio-wrapper">
                                            <label>
                                                <input type="radio" name="imagelinktype" onClick={e => this.HandleImgRBChange(e)} checked={this.state.RbImgPickUrl} value="2" disabled={isNonDefaultLanguage} />
                                                <span className="akv-radio"></span>
                                                <span className="akv-radio-label">{Akumina.Digispace.Language.TryGetText('summarylink.imageurl')}</span>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div className="ak-picker-group akv-form-row">
                                    <div className="akv-value akv-input-group akv-no-gap">
                                        <input type="text" className="listname" disabled={this.state.RbImgPickUrl || isNonDefaultLanguage} value={this.state.RbImgPickUrl ? this.state.ImageName : this.state.Image.imageUrl}
                                            onChange={e => this.UpdateValueToState(e)} maxLength={255} data-field="ImageURL" />
                                        {this.state.RbImgPickUrl ?
                                            <input type="button" onClick={e => this.ShowModal(this.pVars.PICKERS.IMAGE)} className="akv-btn akv-btn-icon" value="..." /> : null}
                                    </div>
                                </div>
                                <div className="akv-form-row akv-has-position-action">
                                    <label>{Akumina.Digispace.Language.TryGetText('summarylink.imagealternativetext')}</label>
                                    <div className={"akv-value " + (isNonDefaultLanguage ? "ak-icon-value" : "")}>
                                        <input data-field="ImageAlternativeText" onChange={e => this.UpdateValueToState(e)} value={this.state.ImageAlternativeText} type="text" maxLength={255} />
                                        {isNonDefaultLanguage && showAutoTranslateButton &&
                                            <div className="ak-icon-btn akv-positioned-action">
                                                <a href="javascript:void(0)" className="akv-btn akv-btn-icon" onClick={() => this.AutoTranslateText("imageText")}>
                                                    <i className="fa-regular fa-globe"></i>
                                                </a>
                                            </div>
                                        }
                                    </div>
                                </div>
                                <div className="akv-form-row">
                                    <label>
                                        {Akumina.Digispace.Language.TryGetText('summarylink.group')}
                                        {" (" + Akumina.Digispace.Language.TryGetText('summarylink.addgroupmessage')}
                                        {<i className="fa-regular fa-bars-staggered"></i>} {" )"}
                                    </label>
                                    <div className="akv-value">
                                        <select data-field="Group" onChange={e => this.UpdateValueToState(e)} value={this.state.ParentNodeGuid} disabled={isNonDefaultLanguage}>
                                            <option value={this.props.RootNodeGuid}></option>
                                            {this.props.GroupList.map(x => <option key={x.ID} value={x.Id} >
                                                {x.Title}
                                            </option>)}
                                        </select>
                                    </div>
                                </div>
                                <div className="akv-form-row">
                                    <div className="akv-help-text">{Akumina.Digispace.Language.TryGetText('summarylink.multilingualwarning')}</div>
                                </div>
                            </div>
                            <div className={(this.state.SelectedTab === "personatab" ? "akv-active" : "mfp-hide")}>
                                <Persona handlePersonaUpdate={this.updateSelectedPersona} selectedPersona={this.props.ItemToEdit ? this.props.ItemToEdit.Persona : []} />
                            </div>
                        </section>
                    </section>
                    <footer className="ak-modal-footer akv-modal-footer">
                        <button className="btn-form btn-close-popup akv-btn akv-btn-text" onClick={e => this.props.CloseModal()}> {Akumina.Digispace.Language.TryGetText('common.cancel')}</button>
                        <button className="btn-form akv-btn akv-primary" onClick={this.SaveDataToList} disabled={this.state.IsLoading}>{Akumina.Digispace.Language.TryGetText('common.save')}</button>
                    </footer>
                </div>
                {viewPickerModal == null ? null :
                    <React.Fragment>
                        <div className="akv-modal-overlay akv-level-1"></div>
                        {viewPickerModal}
                    </React.Fragment>
                }
            </React.Fragment>
        )
    }

    private GetLanguageVariations() {
        if (Akumina.Digispace.ConfigurationContext.IsMultiLingualEnabled && Akumina.Digispace.ConfigurationContext.AreMultipleLanguagesVisible) {
            var _cur = this;
            var request: any = {};
            request.listName = _cur.props.ListName;
            request.selectFields = ["AkLanguageCode", "AkLanguageId"].join(",");
            request.isRoot = _cur.props.UseRoot;
            request.languageCheckRequired = false;
            request.queryFilter = new Akumina.PropertyExpression("CollectionId").EqualTo(this.props.CollectionId);

            this.setState({
                IsLoading: true
            });
            var df = new Akumina.Digispace.Data.DataFactory();
            df.GetList(request).then(function (data: { response: any; }) {
                var items = data.response.listItems;
                var existingLanguages = items.map((item: any) => { return { LangId: item.AkLanguageId, LangCode: item.AkLanguageCode } })
                _cur.setState({
                    IsLoading: false, CollectionExistInLangs: existingLanguages
                });

            });
        } else {
            var existingLanguages = Akumina.Digispace.ConfigurationContext.ActiveLanguages.map(function (item: any) {
                return { LangId: item.languageId, LangCode: item.languageCode }
            });
            this.setState({
                IsLoading: false, CollectionExistInLangs: existingLanguages
            });
        }
    }
}