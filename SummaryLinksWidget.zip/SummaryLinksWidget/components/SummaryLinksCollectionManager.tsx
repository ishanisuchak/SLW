import Akumina = require("akumina-core");
import IGetListRequest from "akumina-core/interfaces/IGetListRequest";
import React = require("react");
import { SummaryLinksAddEditCollection } from "./language/SummaryLinksAddEditCollection";
import { SummaryLinksCreateLangVersions } from "./language/SummaryLinksCreateLanguageVersions";
import { IMessageType, MessageComponent } from "./MessageComponent";

interface ISLWCollectionManagerProps {
	CollectionId: string;
	CloseModal: any;
	SaveWidgetProperties: any;
	SenderId: string;
	DisplayCollectionName: boolean;
	ListName: string;
	UseRoot: boolean;
}

interface ISLWCollectionManagerState {
	ActiveModal: SLWCollectionManagerActiveModals;
	FilteredCollections: Array<ISLWCollection>;
	Collections: Array<ISLWCollection>;
	IsCollectionLoaded: boolean;
	SelectedCollectionId: string;
	DisplayCollectionName: boolean;
	SearchText: string;

	ShowMessage: boolean;
	Message: string;
	MessageType: IMessageType;
	IsProcessing: boolean;
}

enum SLWCollectionManagerActiveModals {
	NONE,
	ADD,
	EDIT,
	TRANSLATE
}

export interface ISLWCollection {
	IntId: number;
	Id: string;
	Name: string;
	Description: string;
}

export class SummaryLinksCollectionManager extends React.Component<ISLWCollectionManagerProps, ISLWCollectionManagerState>{
	constructor(props: ISLWCollectionManagerProps) {
		super(props);
		this.state = {
			ActiveModal: SLWCollectionManagerActiveModals.NONE,
			FilteredCollections: [],
			Collections: [],
			IsCollectionLoaded: false,
			SelectedCollectionId: this.props.CollectionId,
			DisplayCollectionName: this.props.DisplayCollectionName,
			SearchText: "",

			ShowMessage: false,
			Message: "",
			MessageType: IMessageType.Success,
			IsProcessing: false
		}
		this.OpenAddModal = this.OpenAddModal.bind(this);
		this.OpenEditModal = this.OpenEditModal.bind(this);
		this.OpenTranslateModal = this.OpenTranslateModal.bind(this);
		this.CloseCollectionSubModal = this.CloseCollectionSubModal.bind(this);
		this.OnCollectionRowClick = this.OnCollectionRowClick.bind(this);
		this.SaveCollection = this.SaveCollection.bind(this);
		this.OnSearchTextChange = this.OnSearchTextChange.bind(this);
		this.ShowMessage = this.ShowMessage.bind(this);
		this.HideMessage = this.HideMessage.bind(this);
		this.OnToggleDisplayCollectionName = this.OnToggleDisplayCollectionName.bind(this);
		this.DeleteConfirmation = this.DeleteConfirmation.bind(this);
		this.DeleteCollection = this.DeleteCollection.bind(this);
		this.RefreshData = this.RefreshData.bind(this);

	}

	componentDidMount() {
		this.RefreshData();
	}

	RefreshData() {
		var _cur = this;
		this.setState({ IsCollectionLoaded: false });
		this.GetData().then(function (Collections: Array<any>) {
			_cur.setState({ Collections: Collections, FilteredCollections: Collections, IsCollectionLoaded: true, IsProcessing: false });
		}, function (error: any) {
			_cur.setState({ FilteredCollections: [], Collections: [], IsCollectionLoaded: true, IsProcessing: false });
		});
	}

	OpenAddModal() {
		this.setState({ ActiveModal: SLWCollectionManagerActiveModals.ADD });
	}

	OpenEditModal(evt: React.SyntheticEvent) {
		evt.preventDefault();
		evt.stopPropagation(); // To Prevent selection of collection while editing it.
		var row = evt.currentTarget as any as HTMLAnchorElement;
		var collectionId = row.dataset.collectionid as string;
		this.setState({ ActiveModal: SLWCollectionManagerActiveModals.EDIT, SelectedCollectionId: collectionId });
	}

	OpenTranslateModal(evt: React.SyntheticEvent) {
		evt.preventDefault();
		evt.stopPropagation(); // To Prevent selection of collection while translating it.
		var row = evt.currentTarget as any as HTMLAnchorElement;
		var collectionId = row.dataset.collectionid as string;
		this.setState({ ActiveModal: SLWCollectionManagerActiveModals.TRANSLATE, SelectedCollectionId: collectionId });
	}

	CloseCollectionSubModal(RefreshData: boolean, actionResult: any) {
		var _cur = this;
		if (actionResult && actionResult.addedCollections) {
			this.setState({ ActiveModal: SLWCollectionManagerActiveModals.NONE, SelectedCollectionId: actionResult.addedCollections.ItemGuid });
		} else {
			this.setState({ ActiveModal: SLWCollectionManagerActiveModals.NONE });
		}
		if (RefreshData) {
			this.RefreshData();
		}
	}

	OnToggleDisplayCollectionName(evt: React.SyntheticEvent) {
		var checkboxNewValue = !this.state.DisplayCollectionName;
		this.setState({ DisplayCollectionName: checkboxNewValue });
	}

	OnSearchTextChange(evt: React.SyntheticEvent) {
		evt.preventDefault();
		var input = evt.currentTarget as any as HTMLInputElement;
		var SearchText = input.value;
		var FilteredCollections = this.state.Collections;
		if (SearchText && SearchText.length > 2 || (evt as any).keyCode == 13) {
			FilteredCollections = this.state.Collections.filter(function (Collection: ISLWCollection) {
				return Collection.Name.toLowerCase().indexOf(SearchText.toLowerCase()) != -1;
			});
		}
		this.setState({ SearchText: SearchText, FilteredCollections: FilteredCollections });
	}

	OnCollectionRowClick(evt: React.SyntheticEvent) {
		var row = evt.currentTarget as any as HTMLTableRowElement;
		var collectionId = row.dataset.collectionid as string;
		this.setState({ SelectedCollectionId: collectionId });
	}

	SaveCollection() {
		this.SetCollection(this.state.SelectedCollectionId);
	}

	ShowMessage(Message: string, MessageType: IMessageType) {
		this.setState({ ShowMessage: true, Message: Message, MessageType: MessageType });
		setTimeout(this.HideMessage, 8000);
	}

	HideMessage() {
		this.setState({ ShowMessage: false, Message: "" });
	}

	DeleteConfirmation(evt: React.SyntheticEvent) {
		evt.preventDefault();
		evt.stopPropagation(); // To Prevent selection of collection while deleting it.
		var collectionId = (evt.currentTarget as HTMLAnchorElement).dataset.collectionid as string;
		var callback = () => this.DeleteCollection(collectionId);
		//@ts-ignore // New Method added in Utililties
		Akumina.Digispace.Utilities.ShowConfirmPopup(Akumina.Digispace.Language.TryGetText("summarylink.settings.deletecollection"), null, callback);
	}

	DeleteCollection(collectionId: string) {
		var _cur = this;
		var listName = this.props.ListName;
		var df = new Akumina.Digispace.Data.DataFactory();
		var request: IGetListRequest = {} as any;
		request.selectFields = "ID";
		request.listName = listName;
		//@ts-ignore // Type defination of this Interface currently do not have languageCheckRequired updated
		request.languageCheckRequired = false;
		request.queryFilter = new Akumina.PropertyExpression("CollectionId").EqualTo(collectionId);
		request.isRoot = _cur.props.UseRoot;
		this.setState({ IsProcessing: true });
		df.GetList(request).then(function (data) {
			var listItems = data.response.listItems;
			var listEnumerator = listItems.getEnumerator();
			var deleteDefs: Array<JQueryDeferred<any>> = [];

			while (listEnumerator.moveNext()) {
				var listItem = listEnumerator.get_current();
				var IntId = listItem.get_item("ID");
				var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
				dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
				var def = dataFactory.DeleteListItem(listName, IntId, _cur.props.UseRoot);
				deleteDefs.push(def);
			}
			$.when.apply($, deleteDefs).then(function () {
				_cur.setState({ IsProcessing: false });
				_cur.ShowMessage(Akumina.Digispace.Language.TryGetText("summarylink.settings.collectioncontentdelete"), IMessageType.Success);
				_cur.RefreshData();
			}, function (error) {
				_cur.ShowMessage(Akumina.Digispace.Language.TryGetText("summarylink.error.deleteitem"), IMessageType.Error);
			});
		}, function (error) {
			_cur.ShowMessage(Akumina.Digispace.Language.TryGetText("summarylink.error.collectionerror"), IMessageType.Error);
		});
	}

	render() {
		var _cur = this;
		var isNonDefaultLanguage = (Akumina.Digispace.ConfigurationContext.DefaultLanguage as any).languageId !== Akumina.Digispace.UserContext.LanguageId
		return (
			<React.Fragment>
				<div id="ak-collection-modal" className="akv-modal akv-modal-large">
					<header className="akv-modal-header">
						<h2>{Akumina.Digispace.Language.TryGetText("summarylink.settings.collections")}</h2>
						<a href="#0" className="akv-modal-close" onClick={e => (e.preventDefault(), this.props.CloseModal())}>
							<i className="fa-regular fa-xmark" title={Akumina.Digispace.Language.TryGetText("common.close")} aria-label={Akumina.Digispace.Language.TryGetText("common.close")}></i>
						</a>
					</header>
					<section className="akv-modal-content">
						{this.state.IsProcessing ? <div className="ia-widget-loader"></div> : null}
						<div className="akv-grid akv-grid-2-col akv-grid-action-container">
							<div className="akv-grid-col">
								<button className="akv-btn-form akv-primary" onClick={this.OpenAddModal} disabled={isNonDefaultLanguage} >{Akumina.Digispace.Language.TryGetText("summarylink.settings.addnew")}</button>
							</div>
							<div className="akv-grid-col">
								<div className="akv-form-row">
									<div className="akv-value akv-with-icon">
										<input type="search" placeholder={Akumina.Digispace.Language.TryGetText("summarylink.settings.search")} onKeyUp={e => this.OnSearchTextChange(e)} />
										<i className="fa-regular fa-magnifying-glass"></i>
									</div>
								</div>
							</div>
						</div>
						<>
							<MessageComponent ShowComponent={this.state.ShowMessage} Message={this.state.Message} MessageType={this.state.MessageType} />
						</>
						<div>
							<div className="akv-table-container">
								<table className="akv-table akv-selectable akv-table-comfortable">
									<thead>
										<tr>
											<th style={{ width: "25%"}}>{Akumina.Digispace.Language.TryGetText("summarylink.settings.title")}</th>
											<th style={{ width: "60%" }}>{Akumina.Digispace.Language.TryGetText("common.description")}</th>
											<th style={{ width: "124px" }}></th>
										</tr>
									</thead>
									<tbody>
										{this.state.IsCollectionLoaded ? this.state.FilteredCollections.map(function (Collection: ISLWCollection) {
											//Regex to remove HTML tags and &nbsp; from string
											let regex = /(<([^>]+)>)|&nbsp;/ig;
											//Remove all HTML tags from the description to avoid HTML breaking after substring
											//Show only upto 256 chars of description in the collections table
											let description = Collection.Description ? Collection.Description.toString().replace(regex, "") : Collection.Description;
											return <tr className={Collection.Id == _cur.state.SelectedCollectionId ? "akv-selected" : ""}
												data-collectionid={Collection.Id} onClick={_cur.OnCollectionRowClick}>

												<td>{Collection.Name}</td>
												<td title={description}>{description && description.length > 256 ? description.substring(0, 256) + "..." : description}</td>
												<td align="right">
													<span className="akv-collection-action">
														{isNonDefaultLanguage ? null :
															<a href="#!" data-collectionid={Collection.Id} onClick={_cur.OpenTranslateModal} className="akv-btn akv-btn-text">
																<i className="fa-regular fa-globe"></i>
															</a>
														}
														<a href="#!" data-collectionid={Collection.Id} onClick={_cur.OpenEditModal} className="akv-btn akv-btn-text">
															<i className="fa-regular fa-pencil"></i>
														</a>
														{isNonDefaultLanguage ? null :
															<a href="#!" data-collectionid={Collection.Id} onClick={_cur.DeleteConfirmation} className="akv-btn akv-btn-text">
																<i className="fa-regular fa-trash-can"></i>
															</a>
														}
													</span>
												</td>

											</tr>
										}) :
											<tr >
												<td>{Akumina.Digispace.Language.TryGetText("common.loading")}</td>
												<td align="right"></td>
											</tr>}
									</tbody>
								</table>
							</div>
							<div className="akv-form-row">
								<label className="akv-checkbox-wrapper">
									<input type="checkbox" checked={this.state.DisplayCollectionName} onClick={this.OnToggleDisplayCollectionName} />
									<span className="akv-checkbox"></span>
									<span className="akv-checkbox-label">{Akumina.Digispace.Language.TryGetText("summarylink.settings.label_displaycollection")}</span>
								</label>
							</div>
						</div>
					</section>
					<footer className="akv-modal-footer">
						<button className="akv-btn akv-btn-text btn-close-popup" onClick={e => this.props.CloseModal()}>{Akumina.Digispace.Language.TryGetText('common.cancel')}</button>
						<button className="akv-btn akv-primary" onClick={this.SaveCollection} disabled={this.state.SelectedCollectionId == ""}>{Akumina.Digispace.Language.TryGetText('common.select')}</button>
					</footer>
				</div>
				{this.state.ActiveModal == SLWCollectionManagerActiveModals.ADD ?
					<SummaryLinksAddEditCollection Collections={this.state.Collections} ListName={this.props.ListName} UseRoot={this.props.UseRoot}
						CloseModal={this.CloseCollectionSubModal} ShowMessage={this.ShowMessage} SenderId={this.props.SenderId} />
					: null}
				{this.state.ActiveModal == SLWCollectionManagerActiveModals.EDIT ?
					<SummaryLinksAddEditCollection Collections={this.state.Collections} CollectionId={this.state.SelectedCollectionId}
						CloseModal={this.CloseCollectionSubModal} ShowMessage={this.ShowMessage} ListName={this.props.ListName} UseRoot={this.props.UseRoot} SenderId={this.props.SenderId} />
					: null}
				{this.state.ActiveModal == SLWCollectionManagerActiveModals.TRANSLATE ?
					<SummaryLinksCreateLangVersions CloseModal={this.CloseCollectionSubModal} SenderId={this.props.SenderId}
						CollectionID={this.state.SelectedCollectionId} ShowMessage={this.ShowMessage} ListName={this.props.ListName} UseRoot={this.props.UseRoot} DisplayCollectionName={this.state.DisplayCollectionName} />
					: null}
			</React.Fragment>
		);
	}


	LoadItemSuccess(responseData: any, def: JQueryDeferred<any>) {
		var listItems = responseData.listItems;
		var listEnumerator = listItems.getEnumerator();
		var data: Array<any> = [];

		while (listEnumerator.moveNext()) {
			var listItem = listEnumerator.get_current();
			var IntId = listItem.get_item("ID");
			var CollectionId = listItem.get_item("CollectionId");
			var CollectionName = listItem.get_item("CollectionName");
			var CollectionDescription = Akumina.Digispace.Utilities.RewriteImageUrlsForHeadless(listItem.get_item("Summary"));
			var Collection: ISLWCollection = {
				IntId: IntId,
				Id: CollectionId,
				Name: CollectionName != null ? CollectionName.toString() : "",
				Description: CollectionDescription
			}
			data.push(Collection);
		}

		def.resolve(data);
	}

	GetData() {
		var def = $.Deferred();
		var _cur = this;
		var request: any = {};
		request.listName = this.props.ListName;
		request.selectFields = ["ID", "CollectionId", "CollectionName", "Summary"].join(",");
		request.queryFilter = (new Akumina.PropertyExpression("NodeType").EqualTo("Root"));
		request.orderBy = [{ FieldName: "CollectionName", Direction: (Akumina as any).SortDirection.Ascending }];;
		request.isRoot = _cur.props.UseRoot;

		var df = new Akumina.Digispace.Data.DataFactory();
		df.GetList(request).then(function (data) {
			var response = data.response;
			_cur.LoadItemSuccess(response, def);
		}, function (error) {
			def.reject(error);
		});
		return def;
	}

	SetCollection(collectionId: string) {
		var _cur = this;
		var widgetProps = { collectionid: collectionId, displaycollectionname: this.state.DisplayCollectionName };
		Akumina.Digispace.AppPart.Eventing.Publish('/loader/showloading/');
		this.props.SaveWidgetProperties(widgetProps).then(function (model: any) {
			Akumina.Digispace.AppPart.Eventing.Publish('/loader/hideloading/');
			var propertyChangeModel = { properties: ["collectionid", "displaycollectionname"], model: model };
			Akumina.Digispace.AppPart.Eventing.Publish('/summarylist/propertychanged/' + _cur.props.SenderId, propertyChangeModel);
			_cur.props.CloseModal(true);
		}, function (error: any) {
			Akumina.Digispace.AppPart.Eventing.Publish('/loader/hideloading/');
		});
	}
}