import React = require("react");
import ReactDOM = require("react-dom");
import { SummaryLinksAdd } from "./SummaryLinksAdd";
import { SummaryLinksAddEditGroup } from "./SummaryLinksAddEditGroup";
import { SummaryLinksReorder } from "./SummaryLinksReorder";
import { SummaryConfigureViews } from "./SummaryConfigureViews";
import { ISummaryLinksWidgetRequest, ISummaryLinksDataItem } from "../js/widgets/SummaryLinksWidget";
import IGetListRequest from "akumina-core/interfaces/IGetListRequest";
import { SummaryLinksCollectionManager } from "./SummaryLinksCollectionManager";
import GlobalPopUpElementHelper from "../../../helpers/GlobalPopUpElementHelper";
import Akumina = require("akumina-core");


export interface ISLWListItem {
    Title: string;
    NodeName: string;
    NodeType: string;   //Root, Category, Item
    ParentNode: string; //Guid
    DisplayOrder: number;
    CollectionId: string;

    //Required for Adding Item Type Node
    Summary?: string;
    Link?: SPHyperLink;
    LinkTarget?: string;
    Image?: SPHyperLink;
    Tooltip?: string;

    /**
     * Guid string for add new Node
     */
    ItemGuid?: string;
    /** Adding Language Versions Cols */
    CollectionName?: string;
    AkId?: number;
    AkLanguageCode?: string;
    AkLanguageId?: number;
    /** Hidden note field associated with Persona */
    Persona_0?: string;
}

export interface SPHyperLink {
    Description: string,
    Url: string
}

interface ISummaryLinksEditComponentProps {
    CollectionId: string;
    RefreshData: any;
    GroupList: Array<any>;
    AllItemList: Array<ISummaryLinksDataItem>;
    RootNodeGuid: string;
    ViewModel: Array<any>;
    SenderId: string;
    WidgetProperties: ISummaryLinksWidgetRequest;   //This represent default properties of instance recieved with widget init.
    SelectedView: string;
    DisplayCollectionName: boolean;

    //Props For Default collection can be refactored
    IsShowStartButton: boolean;
    CreateRootOfDefaultModel: any;
    ListName: string;
    UseRoot: boolean;
}
interface ISummaryLinksEditComponentState {
    ActiveModal: string;
    ItemToEdit: any;
    AvailableViews: Array<any>;
    SelectedView: string;
    WidgetInstance: any;
    AllViewObjectsArray: Array<any>;
}

export class SummaryLinksEditComponent extends React.Component<ISummaryLinksEditComponentProps, ISummaryLinksEditComponentState>{
    private ModalNames: any;
    private PortalElementHelper: GlobalPopUpElementHelper;
    constructor(props: ISummaryLinksEditComponentProps) {
        super(props);
        this.ModalNames = {
            ADD: 'summarylink_add',
            COLLECTION: 'summarylink_collection',
            ADDGROUP: 'summarylink_add_group',
            EDITGROUP: 'summarylink_edit_group',
            REORDER: 'summarylink_reorder',
            EDITLINK: 'summarylink_edit',
            CONFIGUREVIEWS: 'summarylink_configureview'
        }
        this.state = {
            ActiveModal: "",
            ItemToEdit: undefined,
            AvailableViews: [],
            SelectedView: this.props.SelectedView,
            WidgetInstance: undefined,
            AllViewObjectsArray: []
        }
        this.PortalElementHelper = new GlobalPopUpElementHelper({ parentElement: document.body });
        this.ActivateModal = this.ActivateModal.bind(this);
        this.CloseModal = this.CloseModal.bind(this);
        this.DeleteEventRaised = this.DeleteEventRaised.bind(this);
        this.EditEventRaised = this.EditEventRaised.bind(this);
        this.SaveWidgetProperties = this.SaveWidgetProperties.bind(this);
    }

    componentDidMount() {
        var _cur = this;
        var getWidgetPropsDefs: Array<JQueryDeferred<any>> = [];
        var wm = new Akumina.Digispace.Data.WidgetManager();
        var getWidgetViewsDef = wm.GetWidgetViews("SummaryLinksWidget");
        var wF = new Akumina.Digispace.Data.WidgetFactory();
        var getWidgetInstancesDef = (wF as any).GetInstances([this.props.SenderId], []);
        getWidgetPropsDefs.push(getWidgetViewsDef, getWidgetInstancesDef);
        $.when.apply($, getWidgetPropsDefs).then(function () {
            let widgetInstances = arguments[1];
            let instance = widgetInstances.filter((instance: any) => instance.widgetId == _cur.props.SenderId);
            if (instance.length != 0) {
                let instanceViews = JSON.parse(instance[0].widgetOptions).availableviews;
                //arguments[0] ? arguments[0].filter((view: any) => instanceViews.indexOf(view.ViewTemplateUrl)) : [];
                let definitionViewsObj = arguments[0] ? arguments[0] : [];
                let definitionViews: Array<string> = [];
                definitionViewsObj.forEach(function (i: any) {
                    definitionViews.push(i.ViewTemplateUrl);
                });

                _cur.setState({
                    AvailableViews: definitionViews,//showDefinitionViews here not the 'instanceViews' (no such thing as instance views) -JA
                    SelectedView: _cur.props.WidgetProperties.DisplayTemplateUrl,
                    WidgetInstance: instance[0],
                    AllViewObjectsArray: arguments[0]
                });
            } else {
                _cur.setState({
                    AvailableViews: arguments[0] ? arguments[0].map((view: any) => view.ViewTemplateUrl) : [],
                    WidgetInstance: undefined,
                    AllViewObjectsArray: arguments[0] ? arguments[0] : []
                });
            }
        });
        Akumina.Digispace.AppPart.Eventing.Subscribe('/summarylist/delete/' + this.props.SenderId, this.DeleteEventRaised);
        Akumina.Digispace.AppPart.Eventing.Subscribe('/summarylist/edit/' + this.props.SenderId, this.EditEventRaised);
    }

    componentWillUnmount() {
        Akumina.Digispace.AppPart.Eventing.UnSubscribe('/summarylist/delete/' + this.props.SenderId, this.DeleteEventRaised);
        Akumina.Digispace.AppPart.Eventing.UnSubscribe('/summarylist/edit/' + this.props.SenderId, this.EditEventRaised);
    }

    render() {
        Akumina.Digispace.AppPart.Eventing.Publish('/widgetactions/overridesettings/' + this.props.SenderId, this.OverrideWidgetSettings());
        return null;
    }

    OverrideWidgetSettings() {
        var ActiveModal = null;
        //@ts-ignore Default Language
        var isNonDefaultLanguage = Akumina.Digispace.ConfigurationContext.DefaultLanguage.languageId !== Akumina.Digispace.UserContext.LanguageId
        switch (this.state.ActiveModal) {
            case this.ModalNames.ADD:
                ActiveModal = <SummaryLinksAdd CollectionId={this.props.CollectionId} CloseModal={this.CloseModal} ListName={this.props.ListName} UseRoot={this.props.UseRoot}
                    GroupList={this.props.GroupList} RootNodeGuid={this.props.RootNodeGuid} AllItemList={this.props.AllItemList} SenderId={this.props.SenderId} />
                break;
            case this.ModalNames.EDITLINK:
                ActiveModal = <SummaryLinksAdd CollectionId={this.props.CollectionId} CloseModal={this.CloseModal} ListName={this.props.ListName} UseRoot={this.props.UseRoot}
                    GroupList={this.props.GroupList} RootNodeGuid={this.props.RootNodeGuid} ItemToEdit={this.state.ItemToEdit} AllItemList={this.props.AllItemList} SenderId={this.props.SenderId} />
                break;
            case this.ModalNames.ADDGROUP:
                ActiveModal = <SummaryLinksAddEditGroup CollectionId={this.props.CollectionId} GroupItem="" CloseModal={this.CloseModal}
                    GroupList={this.props.GroupList} RootNodeGuid={this.props.RootNodeGuid} ListName={this.props.ListName} UseRoot={this.props.UseRoot} />
                break;
            case this.ModalNames.EDITGROUP:
                ActiveModal = <SummaryLinksAddEditGroup CollectionId={this.props.CollectionId} GroupItem={this.state.ItemToEdit} CloseModal={this.CloseModal}
                    GroupList={this.props.GroupList} RootNodeGuid={this.props.RootNodeGuid} ListName={this.props.ListName} UseRoot={this.props.UseRoot} />
                break;
            case this.ModalNames.REORDER:
                ActiveModal = <SummaryLinksReorder CollectionId={this.props.CollectionId} CloseModal={this.CloseModal} ListName={this.props.ListName} UseRoot={this.props.UseRoot}
                    GroupList={this.props.GroupList} RootNodeGuid={this.props.RootNodeGuid} AllItemList={this.props.AllItemList} DisplayCollectionName={this.props.DisplayCollectionName} />
                break;
            case this.ModalNames.COLLECTION:
                ActiveModal = <SummaryLinksCollectionManager CollectionId={this.props.CollectionId} CloseModal={this.CloseModal}
                    SenderId={this.props.SenderId} SaveWidgetProperties={this.SaveWidgetProperties} ListName={this.props.ListName}
                    UseRoot={this.props.UseRoot} DisplayCollectionName={this.props.DisplayCollectionName} />
                break;
            case this.ModalNames.CONFIGUREVIEWS:
                ActiveModal = <SummaryConfigureViews CollectionId={this.props.CollectionId} CloseModal={this.CloseModal}
                    SenderId={this.props.SenderId} SaveWidgetProperties={this.SaveWidgetProperties}
                    AvailableViews={this.state.AvailableViews} SelectedView={this.state.SelectedView} AllViewObjectsArray={this.state.AllViewObjectsArray} />
                break;
        }
        return <React.Fragment>
            {/* <ul className="ak-summaryActions"> */}
            <li><a title={Akumina.Digispace.Language.TryGetText("summarylink.edit.label_collection")} onClick={(e) => this.ActivateModal(this.ModalNames.COLLECTION)}>
                <i className="fa-regular fa-gear"></i></a>
            </li>
            {this.props.IsShowStartButton ?
                <li><a title={Akumina.Digispace.Language.TryGetText("summarylink.edit.label_startedit")} onClick={(e) => this.props.CreateRootOfDefaultModel(e)}>
                    <i className="fa-regular fa-circle-check"></i></a>
                </li>
                :
                (this.props.CollectionId == "" || isNonDefaultLanguage ? null
                    :
                    <React.Fragment>
                        <li><a title={Akumina.Digispace.Language.TryGetText("summarylink.edit.label_addlink")} onClick={(e) => this.ActivateModal(this.ModalNames.ADD)}><i className="fa-regular fa-link"></i></a></li>
                        <li><a title={Akumina.Digispace.Language.TryGetText("summarylink.edit.label_addgroup")} onClick={(e) => this.ActivateModal(this.ModalNames.ADDGROUP)}><i className="fa-regular fa-bars-staggered"></i></a></li>
                        <li><a title={Akumina.Digispace.Language.TryGetText("summarylink.edit.label_reorder")} onClick={(e) => this.ActivateModal(this.ModalNames.REORDER)}><i className="fa-regular fa-arrow-up-arrow-down"></i></a></li>
                        <li><a title={Akumina.Digispace.Language.TryGetText("summarylink.edit.label_configureviews")} onClick={(e) => this.ActivateModal(this.ModalNames.CONFIGUREVIEWS)}><i className="fa-regular fa-columns-3"></i></a></li>
                    </React.Fragment>)
            }
            {/* </ul> */}
            {ActiveModal == null ? null :
                ReactDOM.createPortal(
                    <React.Fragment>
                        <div className="akv-modal-overlay akv-full-screen"></div>
                        {ActiveModal}
                    </React.Fragment>,
                    this.PortalElementHelper.GetContainerElement()
                )
            }
        </React.Fragment>
    }

    EditEventRaised(id: any) {
        var itemToEdit: ISummaryLinksDataItem = this.props.AllItemList.filter(x => x.Id == id)[0];
        if (itemToEdit) {
            this.setState({ ItemToEdit: itemToEdit, ActiveModal: this.ModalNames.EDITLINK })
        } else {
            var groupToEdit = this.props.GroupList.filter(x => x.Id == id)[0];
            if (groupToEdit) {
                this.setState({ ItemToEdit: groupToEdit, ActiveModal: this.ModalNames.EDITGROUP })
            }
        }
    }

    DeleteEventRaised(id: any) {
        var _cur = this;

        var ClickedItem = this.props.GroupList.filter(x => x.Id == id)[0];
        var ChildCount = 0;
        if (ClickedItem) {
            ChildCount = ClickedItem.ChildCount;
        }

        var idToDelete;
        var itemToDelete: ISummaryLinksDataItem = this.props.AllItemList.filter(x => x.Id == id)[0];
        if (itemToDelete) {
            idToDelete = itemToDelete.IntId;
        } else {
            var groupToDelete = this.props.GroupList.filter(x => x.Id == id)[0];
            if (groupToDelete) {
                idToDelete = groupToDelete.IntId;
            }
        }

        if (ChildCount == 0) {
            var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
            dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
            dataFactory.DeleteListItem(this.props.ListName, idToDelete, _cur.props.UseRoot).then(function (result: any) {
                setTimeout(_cur.props.RefreshData, 1000);
            }, function (error: any) {
                Akumina.Digispace.AppPart.Eventing.Publish('/summarylinks/HideLoader/');
                Akumina.Digispace.Utilities.ShowAlertPopup(Akumina.Digispace.Language.TryGetText("summarylink.error.itemdelete"), null);
            })
        } else {
            Akumina.Digispace.AppPart.Eventing.Publish('/summarylinks/HideLoader/');
            Akumina.Digispace.Utilities.ShowAlertPopup(Akumina.Digispace.Language.TryGetText("summarylink.error.groupnotempty"), null);
        }
    }

    ActivateModal(ActiveButton: string) {
        if (ActiveButton == this.ModalNames.ADD) {
            var senderid = this.props.SenderId;
            Akumina.Digispace.AppPart.Eventing.Publish('/summarylist/add/' + senderid);
        }
        this.setState({ ActiveModal: ActiveButton });
    }

    CloseModal(RefreshData: boolean | undefined) {
        this.setState({ ActiveModal: "" });
        if (RefreshData) {
            var _cur = this;
            setTimeout(_cur.props.RefreshData, 1000);
        }
    }

    SaveWidgetProperties(widgetProps: any): JQuery.Deferred<any> {
        if (widgetProps.displaytemplateurl) {
            this.setState({ SelectedView: widgetProps.displaytemplateurl });
        }
        if (this.props.WidgetProperties.HasPageProps) {
            return this.SavePageSpecificInstance(widgetProps);
        } else {
            return this.SaveGlobalInstance(widgetProps);
        }
    }

    private SaveGlobalInstance(widgetProps: any): JQuery.Deferred<any> {
        var _cur = this;
        var newTemplateUrl = this.state.SelectedView;
        var widgetInstanceIdCheck = (new Akumina.PropertyExpression("WidgetInstanceId").EqualTo(this.props.SenderId));
        var request: IGetListRequest = {} as IGetListRequest;

        request.listName = 'WidgetProperties_AK';
        request.isRoot = true;
        request.rowLimit = 1;
        request.queryFilter = widgetInstanceIdCheck;
        request.selectFields = ["ID", "WidgetProperties", "WidgetOptions"].join(",");
        request.contextSiteUrl = (Akumina.Digispace.Data.DataFactory as any).GetSiteCollectionUrl('widgetproperties_ak', request.isRoot);

        return this.UpdateWidgetProperties(request, widgetProps);
    }

    private SavePageSpecificInstance(widgetProps: any): JQuery.Deferred<any> {

        // var widgetInstanceIdCheck = (new Akumina.PropertyExpression("WidgetInstanceId").EqualTo(this.props.SenderId));
        // var pageIdCheck = widgetInstanceIdCheck.And(new Akumina.PropertyExpression("PageId").EqualTo(Akumina.Digispace.PageContext.PageId));
        // var pageVersionIdCheck = pageIdCheck.And(new Akumina.PropertyExpression("PageVersionId").EqualTo(Akumina.Digispace.PageContext.PageVersionId));
        // var request: IGetListRequest = {} as IGetListRequest;

        // request.listName = 'PageWidgets_AK';
        // request.isRoot = (Akumina.Digispace.ConfigurationContext as any).IsSubsitePageDeliveryMode ? false : true;
        // request.rowLimit = 1;
        // request.queryFilter = pageVersionIdCheck;
        // request.selectFields = ["ID", "WidgetProperties", "WidgetOptions"].join(",");
        // request.contextSiteUrl = (Akumina.Digispace.Data.DataFactory as any).GetSiteCollectionUrl('pagewidgets_ak', request.isRoot);
        // return this.UpdateWidgetProperties(request, widgetProps);

        var _cur = this;
        var WidgetPropsToUpdate: any = widgetProps;
        //var currentWidgetProps = _cur.state.WidgetInstance ? JSON.parse(_cur.state.WidgetInstance.widgetprops) : {};
        //var propertiesToSave: any = Object.assign({}, currentWidgetProps, WidgetPropsToUpdate);
        WidgetPropsToUpdate.widgetFramework = "react";
        WidgetPropsToUpdate.displaytemplateurl =  WidgetPropsToUpdate.displaytemplateurl ? WidgetPropsToUpdate.displaytemplateurl : _cur.state.SelectedView;
        var model: any = {
            widgetinstanceid: _cur.props.SenderId,
            widgetprops: null,
            widgetname: _cur.props.WidgetProperties.WidgetName,
            icon: "",
            widgetdescription: "",
            widgetclass: "Akumina.AddIn.SummaryLinksWidget", widgetjs: ""
        };
        model.widgetprops = WidgetPropsToUpdate;

        // var cacheManager = new Akumina.Digispace.Data.CacheManager();
        // (cacheManager as any).clearContentCache();
        // (cacheManager as any).clearTemplatesCache();
        Akumina.Digispace.AppPart.Eventing.Publish('/pagecomponent/partialupdatewidgetstate/', {
            WidgetPropsForRender: { name: _cur.props.WidgetProperties.WidgetName, class: "Akumina.AddIn.SummaryLinksWidget" }, WidgetPropsToUpdate: WidgetPropsToUpdate, widgetinstanceid: _cur.props.SenderId, haspageprops: true
        });
        var def = $.Deferred();
        def.resolve(model);
        return def;
    }

    private UpdateWidgetProperties(request: any, WidgetPropsToUpdate: any): JQuery.Deferred<any> {
        var def = $.Deferred();
        var _cur = this;
        var legacyMode = true;
        var spcaller = new Akumina.Digispace.Data.DataFactory(legacyMode);
        var listName = request.listName;
        spcaller.GetList(request).then(function (data: any) {
            var currentWidgetProps = _cur.state.WidgetInstance ? JSON.parse(_cur.state.WidgetInstance.widgetprops) : {};
            var propertiesToSave: any = Object.assign({}, currentWidgetProps, WidgetPropsToUpdate);
            var widgetProps = JSON.stringify(propertiesToSave);
            var listEnum = data.response.listItems.getEnumerator();
            var context = data.response.context;
            WidgetPropsToUpdate.widgetFramework = "react";
            WidgetPropsToUpdate.displaytemplateurl = _cur.state.SelectedView;
            var instanceFound = data.response.listItems.get_count() > 0;

            //KJ >> global instance of SLW lost properties when toggling widget edit mode
            if (!instanceFound) {
                //If Instance is not found --- InmemoryInstance
                var model: any = {
                    widgetinstanceid: _cur.props.SenderId,
                    widgetprops: null,
                    widgetname: _cur.props.WidgetProperties.WidgetName,
                    icon: "",
                    widgetdescription: "",
                    widgetclass: "Akumina.AddIn.SummaryLinksWidget", widgetjs: ""
                };
                model.widgetprops = WidgetPropsToUpdate;

                Akumina.Digispace.AppPart.Eventing.Publish('/pagecomponent/partialupdatewidgetstate/', {
                    WidgetPropsForRender: { name: _cur.props.WidgetProperties.WidgetName, class: "Akumina.AddIn.SummaryLinksWidget" }, WidgetPropsToUpdate: WidgetPropsToUpdate, widgetinstanceid: _cur.props.SenderId
                });
                def.resolve(model);
            } else {
                while (listEnum.moveNext()) {
                    var currentItem = listEnum.get_current();
                    if (Akumina.Digispace.SiteContext.IsHeadlessMode) {
                        var queryParams = Akumina.Digispace.Utilities.CreateListItemModelForHeadless(listName, {
                            "WidgetProperties": widgetProps
                        });
                        spcaller.UpdateListItem(listName, currentItem.ID, queryParams).then(function (result: any) {
                            _cur.onUpdateComplete(def, WidgetPropsToUpdate);
                        }, function (error: any) {
                            def.reject(error);
                        });
                    }
                    else {
                        currentItem.set_item("WidgetProperties", widgetProps);
                        currentItem.update();
                        context.load(currentItem);
                        context.executeQueryAsync(() => _cur.onUpdateComplete(def, WidgetPropsToUpdate), function (error: any) {
                            def.reject(error);
                        });
                    }
                }
            }
        }, function (error: any) {
            def.reject(error);
        });
        return def;
    }
    private onUpdateComplete(def: JQuery.Deferred<any>, WidgetPropsToUpdate: any) {
        var _cur = this;
        if (_cur.props.WidgetProperties.HasPageProps) {
            var cacheManager = new Akumina.Digispace.Data.CacheManager();
            (cacheManager as any).clearContentCache();
            (cacheManager as any).clearTemplatesCache();
            Akumina.Digispace.AppPart.Eventing.Publish('/pagecomponent/partialupdatewidgetstate/', {
                WidgetPropsForRender: { name: _cur.props.WidgetProperties.WidgetName, class: "Akumina.AddIn.SummaryLinksWidget" }, WidgetPropsToUpdate: WidgetPropsToUpdate, widgetinstanceid: _cur.props.SenderId
            });
            var model: any = {
                widgetinstanceid: _cur.props.SenderId,
                widgetprops: null,
                widgetname: _cur.props.WidgetProperties.WidgetName,
                icon: "",
                widgetdescription: "",
                widgetclass: "Akumina.AddIn.SummaryLinksWidget", widgetjs: ""
            };
            model.widgetprops = WidgetPropsToUpdate;
            def.resolve(model);
            return;
        }
        else {
            //@ts-ignore
            new Akumina.Digispace.Data.Interchange().UpdateWidgetInstanceCache(_cur.props.SenderId, _cur.state.WidgetInstance.siteId).then(function () {
                var cacheManager = new Akumina.Digispace.Data.CacheManager();
                (cacheManager as any).clearContentCache();
                (cacheManager as any).clearTemplatesCache();
                var model: any = {
                    widgetinstanceid: _cur.props.SenderId,
                    widgetprops: null,
                    widgetname: _cur.props.WidgetProperties.WidgetName,
                    icon: "",
                    widgetdescription: "",
                    widgetclass: "Akumina.AddIn.SummaryLinksWidget", widgetjs: ""
                };
                model.widgetprops = WidgetPropsToUpdate;
                def.resolve(model);
                return;
            }, function (errormsg: any) {
                Akumina.AddIn.Logger.WriteErrorLog("Error Updating Widget Properties. " + errormsg);
                def.reject(errormsg);
                return;
            });
        }
    }
}