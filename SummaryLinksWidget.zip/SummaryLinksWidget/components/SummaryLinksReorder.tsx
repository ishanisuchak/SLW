import Akumina = require("akumina-core");
import React = require("react");
import { ISummaryLinksDataItem } from "../js/widgets/SummaryLinksWidget";

interface ISummaryLinksReorderProps {
    CollectionId: string;
    CloseModal: any;
    GroupList: Array<any>;
    AllItemList: Array<any>;
    RootNodeGuid: string;
    ListName: string;
    UseRoot: boolean;
    DisplayCollectionName: boolean;
}
interface ISummaryLinksReorderState {
    RootLevelNodes: Array<any>;
    AllItemList: Array<any>;
    SaveReorder: boolean;
    AllLangData: Array<ISummaryLinksDataItem>;
}

export class SummaryLinksReorder extends React.Component<ISummaryLinksReorderProps, ISummaryLinksReorderState>{
    constructor(props: ISummaryLinksReorderProps) {
        super(props);
        var rootLevelItems = this.props.AllItemList.filter((Item: any) => Item.ParentNode == this.props.RootNodeGuid).concat(this.props.GroupList);
        var sortedRootLevelNodes = rootLevelItems.sort((x: any, y: any) => x.DisplayOrder - y.DisplayOrder).map(function (item: any, index: number) {
            item.DisplayOrder = index + 1;
            return item;
        });
        var sortedAllListItems = this.props.AllItemList.sort((x: any, y: any) => (
            (sortedRootLevelNodes.filter((g: any) => g.Id == x.ParentNode)[0]?.DisplayOrder || 0)
            - (sortedRootLevelNodes.filter((g: any) => g.Id == x.ParentNode)[0]?.DisplayOrder || 0)
            || x.DisplayOrder - y.DisplayOrder
        ));
        this.state = {
            RootLevelNodes: sortedRootLevelNodes,
            AllItemList: sortedAllListItems,
            SaveReorder: false,
            AllLangData: []
        }
        this.RenderGroup = this.RenderGroup.bind(this);
        this.RenderItem = this.RenderItem.bind(this);
        this.moveGroup = this.moveGroup.bind(this);
        this.UpdateOrder = this.UpdateOrder.bind(this);
        this.GetAllLanguageVar = this.GetAllLanguageVar.bind(this);
    }

    componentDidMount() {
        console.log("Reorder component Mounted");
        this.GetAllLanguageVar().then((allItemsList) => {
            this.setState({ AllLangData: allItemsList });
        });
    }

    UpdateOrder() {
        this.setState({
            SaveReorder: true
        });
        var listName = this.props.ListName;
        var _cur = this;
        var langDefs: Array<JQueryDeferred<any>> = [];
        var groupDefs = this.state.RootLevelNodes.map(function (x: any) {
            var queryParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(listName, { DisplayOrder: x.DisplayOrder });
            var otherLangVersions = _cur.state.AllLangData.filter((item) => item.Id == x.Id && item.IntId != x.IntId);
            if (otherLangVersions.length > 0) {
                otherLangVersions.map((langItem) => {
                    let dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                    dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);

                    var langDef = dataFactory.UpdateListItem(listName, langItem.IntId, queryParams, _cur.props.UseRoot);
                    langDefs.push(langDef);
                });
            }
            var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
            dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);

            return dataFactory.UpdateListItem(listName, x.IntId, queryParams, _cur.props.UseRoot);
        });

        var itemDefs = this.state.AllItemList.map(function (item: any) {
            var queryParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(listName, { DisplayOrder: item.DisplayOrder, ParentNode: item.ParentNode });
            var otherLangVersions = _cur.state.AllLangData.filter((langItem) => item.Id == langItem.Id && item.IntId != langItem.IntId);
            if (otherLangVersions.length > 0) {
                otherLangVersions.map((langItem) => {
                    let dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                    dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);

                    var langDef = dataFactory.UpdateListItem(listName, langItem.IntId, queryParams, _cur.props.UseRoot);
                    langDefs.push(langDef);
                });
            }
            let dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
            dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);

            return dataFactory.UpdateListItem(listName, item.IntId, queryParams, _cur.props.UseRoot);
        });

        $.when.apply($, [groupDefs, itemDefs, langDefs]).then(function () {
            _cur.props.CloseModal(true);
        }, function (error: any) {
            (Akumina as any).AddIn.Logger.WriteErrorLog(error);
            _cur.setState({
                SaveReorder: false
            });
        });
    }

    RenderGroup(Group: any) {
        return (
            <li data-id={Group.Id} data-isgroup={Group.ParentNode == this.props.RootNodeGuid}>
                <div className="akv-main-group">
                    <div className="akv-group-title">
                        <p>{Group.Title} </p>
                        {/*- {Group.Id} - {Group.DisplayOrder}*/}
                    </div>
                    <div className="akv-group-actions">
                        <a href="javascript:void(0)" onClick={e => this.moveUp(e)}>
                            <i className="fa-regular fa-arrow-up"></i>
                        </a>
                        <a href="javascript:void(0)" onClick={e => this.moveDown(e)}>
                            <i className="fa-regular fa-arrow-down"></i>
                        </a>
                    </div>
                </div>
                <ul>
                    {this.state.AllItemList.filter((x: any) => x.ParentNode == Group.Id).sort((x: any, y: any) => x.DisplayOrder - y.DisplayOrder).map((x: any) => (this.RenderItem(x)))}
                </ul>
            </li>
        );
    }

    RenderItem(Item: any) {
        return (
            <li data-id={Item.Id} data-isgroup={Item.ParentNode == this.props.RootNodeGuid}>
                <div className="akv-sub-group">
                    <div className="akv-sub-group-title">
                        <p>{Item.Title} {/*- {Item.Id} - {Item.DisplayOrder}*/}</p>
                    </div>
                    <div className="akv-sub-group-actions">
                        <a href="javascript:void(0)" onClick={e => this.moveUp(e)}>
                            <i className="fa-regular fa-arrow-up"></i>
                        </a>
                        <a href="javascript:void(0)" onClick={e => this.moveDown(e)}>
                            <i className="fa-regular fa-arrow-down"></i>
                        </a>
                    </div>
                </div>
            </li>
        );
    }

    moveUp(evt: React.SyntheticEvent) {
        var clicked = $(evt.currentTarget).closest("li")[0] as HTMLLIElement;
        var clickedItemId = clicked.dataset.id as string;
        var isGroup = clicked.dataset.isgroup == "true" ? true : false;

        if (isGroup) {
            this.moveGroup(clickedItemId, true);
        } else {
            this.moveItem(clickedItemId, true);
        }
    }

    moveDown(evt: React.SyntheticEvent) {
        var clicked = $(evt.currentTarget).closest("li")[0] as HTMLLIElement;
        var clickedItemId = clicked.dataset.id as string;
        var isGroup = clicked.dataset.isgroup == "true" ? true : false;

        if (isGroup) {
            this.moveGroup(clickedItemId, false);
        } else {
            this.moveItem(clickedItemId, false);
        }
    }

    render() {
        var _cur = this;
        return (
            <div id="reorder-links-modal" className="akv-modal ak-reorder-links-modal akv-modal-medium">
                <header className="akv-modal-header">
                    <h2>{Akumina.Digispace.Language.TryGetText('summarylink.reorderlinks')}</h2>
                    <a href="#0" className="ak-modal-close akv-modal-close" onClick={e => (e.preventDefault(), this.props.CloseModal())}>
                        <i className="fa-regular fa-xmark" title={Akumina.Digispace.Language.TryGetText("common.close")} aria-label={Akumina.Digispace.Language.TryGetText("common.close")}></i>
                    </a>
                </header>
                {this.state.RootLevelNodes.length > 0 || this.state.AllItemList.filter((Item: any) => Item.ParentNode).length > 0 ?
                    <React.Fragment>
                        <section className="akv-modal-content">
                            <p>
                                {Akumina.Digispace.Language.TryGetText('summarylink.reordersequence')}
                            </p>
                            <div className="akv-groups">
                                <ul>
                                    {this.state.RootLevelNodes.length > 0 ? this.state.RootLevelNodes.map(function (Group: any) {
                                        return Group.NodeType.toLowerCase() == "group" ? _cur.RenderGroup(Group) : _cur.RenderItem(Group);
                                    }) : this.state.AllItemList.filter((Item: any) => Item.ParentNode).map(function (Item: any) {
                                        return _cur.RenderItem(Item);
                                    })
                                    }
                                </ul>
                            </div>
                        </section>
                        <footer className="akv-modal-footer">
                            <button className="btn-form btn-close-popup akv-btn akv-btn-text" onClick={e => this.props.CloseModal()}>{Akumina.Digispace.Language.TryGetText('common.cancel')}</button>
                            <button className="btn-form akv-btn akv-primary" onClick={this.UpdateOrder} disabled={this.state.SaveReorder}>{Akumina.Digispace.Language.TryGetText('common.save')}</button>
                        </footer>
                    </React.Fragment>
                    :
                    <React.Fragment>
                        <section className="akv-modal-content">
                            <p>
                                {Akumina.Digispace.Language.TryGetText('summarylink.error.noitemstoreorder')}
                            </p>
                        </section>
                        <footer className="akv-modal-footer">
                            <button className="btn-form akv-btn akv-primary btn-close-popup" onClick={e => this.props.CloseModal()}> {Akumina.Digispace.Language.TryGetText('common.ok')}</button>
                        </footer>
                    </React.Fragment>}
            </div>
        )
    }

    private GetAllLanguageVar() {
        var def = $.Deferred();
        var request: any = {};
        request.listName = this.props.ListName;
        request.selectFields = ["ID", "ItemGuid", "CollectionId", "CollectionName", "NodeName", "NodeType", "ParentNode", "DisplayOrder", "Summary", "Link", "LinkTarget", "Image", "Tooltip"].join(",");
        request.isRoot = this.props.UseRoot;
        request.languageCheckRequired = false;
        request.queryFilter = new Akumina.PropertyExpression("CollectionId").EqualTo(this.props.CollectionId);


        var df = new Akumina.Digispace.Data.DataFactory();
        df.GetList(request).then((data: { response: any; }) => {
            var response = data.response;
            var listItems = response.listItems;
            var listEnumerator = listItems.getEnumerator();
            var Items = [] as Array<ISummaryLinksDataItem>;

            while (listEnumerator.moveNext()) {
                var listItem = listEnumerator.get_current();
                var CollectionId = listItem.get_item("CollectionId");
                var CollectionName = listItem.get_item("CollectionName");
                var Title = listItem.get_item("NodeName");
                var NodeType = listItem.get_item("NodeType");
                var ParentNode = listItem.get_item("ParentNode");
                var DisplayOrder = listItem.get_item("DisplayOrder");
                var Summary = listItem.get_item("Summary");
                var Link = listItem.get_item("Link") == null ? "" : listItem.get_item("Link").get_url();
                var LinkTargetValue = listItem.get_item("LinkTarget");
                var LinkTarget = listItem.get_item("LinkTarget") == "Same Window" ? "_self" : "_blank";

                var Image = listItem.get_item("ImageUrl");
                var ImageUrl = Image ? Image.get_url() : "";
                var ImageAlternativeText = Image ? Image.get_description() : "";

                var Tooltip = listItem.get_item("Tooltip");
                var ItemGuid = listItem.get_item('ItemGuid');

                var Id = listItem.get_item('ID');
                var spaLink = Link ? Akumina.Digispace.Utilities.CreatePageLink(Link) : Link;

                var summaryLinkItem: ISummaryLinksDataItem = {
                    CollectionId: CollectionId,
                    CollectionName: CollectionName != null ? CollectionName.toString() : "",
                    DisplayCollectionName: this.props.DisplayCollectionName,
                    Title: Title ? Title : "",
                    NodeType: NodeType == "Category" ? "Group" : NodeType,
                    ParentNode: ParentNode ? ParentNode.toString() : "",
                    DisplayOrder: DisplayOrder,
                    Summary: Summary ? Summary : "",
                    Link: spaLink ? spaLink : "",
                    LinkTarget: LinkTarget ? LinkTarget : "",
                    LinkTargetValue: LinkTargetValue,
                    Id: ItemGuid.toString(),
                    IntId: Id,
                    ImageUrl: ImageUrl ? ImageUrl : "",
                    ImageAlternativeText: ImageAlternativeText ? ImageAlternativeText : "",
                    Tooltip: Tooltip ? Tooltip : "",
                    senderid: ""
                }
                Items.push(summaryLinkItem);
            }

            def.resolve(Items);

        }, function (error: any) {
            def.reject(error);
        });

        return def;
    }

    private moveGroup(clickedItemId: string, isUp: boolean) {
        var moveFactor = isUp ? -1 : 1;

        var newGroupList = [...this.state.RootLevelNodes];
        var clickedItem = newGroupList.filter((x: any) => x.Id == clickedItemId)[0];
        var clickedItemIndex = newGroupList.findIndex((x: any) => x.Id == clickedItemId);
        var upperElemIndex = clickedItemIndex + moveFactor;
        if (newGroupList[upperElemIndex] == undefined) {
            return false;
        }

        var newDisplayOrder = newGroupList[upperElemIndex].DisplayOrder;
        var oldDisplayOrder = clickedItem.DisplayOrder;

        newGroupList[clickedItemIndex].DisplayOrder = newDisplayOrder;
        newGroupList[upperElemIndex].DisplayOrder = oldDisplayOrder;
        newGroupList = newGroupList.sort((x: any, y: any) => x.DisplayOrder - y.DisplayOrder);
        this.setState({ RootLevelNodes: newGroupList });
    }

    private moveItem(clickedItemId: string, isUp: boolean) {
        var moveFactor = isUp ? -1 : 1;

        var newAllItemList = [...this.state.AllItemList];
        var clickedItem = newAllItemList.filter((x: any) => x.Id == clickedItemId)[0];
        var clickedItemIndex = newAllItemList.findIndex((x: any) => x.Id == clickedItemId);
        var nextElemIndex = this.getNextItemIndexFromSameGroup(clickedItemId, clickedItem.ParentNode, moveFactor);

        if (nextElemIndex == undefined) { // No next Item, Change Group
            // if Up -> New order will be 
            var NextGroup = this.getNextGroup(clickedItem.ParentNode, moveFactor);
            if (NextGroup == undefined) {
                // No next group do nothing.
            } else {
                if (isUp) {
                    var oldParentNode = clickedItem.ParentNode;
                    var maxDisplayOrder = 0;
                    var displayOrder = 1;
                    this.state.AllItemList.filter((item: any) => item.ParentNode == NextGroup.Id).forEach(function (item: any) {
                        maxDisplayOrder = item.DisplayOrder > maxDisplayOrder ? item.DisplayOrder : maxDisplayOrder;
                    });
                    newAllItemList[clickedItemIndex].ParentNode = NextGroup.Id;
                    newAllItemList[clickedItemIndex].DisplayOrder = maxDisplayOrder + 1;
                    //Reorder previous Group Items
                    for (var i = 0; i < newAllItemList.length; i++) {
                        if (newAllItemList[i].ParentNode == oldParentNode) {
                            newAllItemList[i].DisplayOrder = displayOrder;
                            displayOrder++;
                        }
                    }
                } else {
                    var displayOrder = 2;
                    //Move all childs under next group to display order from 2 (1st will be occupy by comming element)
                    for (var i = 0; i < newAllItemList.length; i++) {
                        if (newAllItemList[i].ParentNode == NextGroup.Id) {
                            newAllItemList[i].DisplayOrder = displayOrder;
                            displayOrder++;
                        }
                    }
                    newAllItemList[clickedItemIndex].ParentNode = NextGroup.Id;
                    newAllItemList[clickedItemIndex].DisplayOrder = 1;
                }
                this.setState({ AllItemList: newAllItemList });
            }
        } else {

            var newDisplayOrder = newAllItemList[nextElemIndex].DisplayOrder;
            var oldDisplayOrder = clickedItem.DisplayOrder;

            newAllItemList[clickedItemIndex].DisplayOrder = newDisplayOrder;
            newAllItemList[nextElemIndex].DisplayOrder = oldDisplayOrder;
            newAllItemList = newAllItemList.sort((x: any, y: any) => x.DisplayOrder - y.DisplayOrder);
            this.setState({ AllItemList: newAllItemList });

        }
    }

    private getNextGroup(groupId: number, moveFactor: number) {
        var nextGroupIndex = this.state.RootLevelNodes.findIndex((item: any) => item.Id == groupId);
        do {
            nextGroupIndex += moveFactor;
        } while (this.state.RootLevelNodes[nextGroupIndex] !== undefined && this.state.RootLevelNodes[nextGroupIndex].NodeType.toLowerCase() !== "group")
        return this.state.RootLevelNodes[nextGroupIndex]
    }

    private getNextItemIndexFromSameGroup(clickedId: string, groupId: number, moveFactor: number) {

        var itemsInGroup = this.state.AllItemList.filter((item: any) => item.ParentNode == groupId);

        //sort by display order ascending
        var newitemsInGroup = [...itemsInGroup];
        newitemsInGroup = newitemsInGroup.sort(function (a: any, b: any) { return a.DisplayOrder - b.DisplayOrder });

        var indexOfClicked = newitemsInGroup.findIndex((item: any) => item.Id == clickedId);

        var isRootItemIndex = indexOfClicked == -1; //If item is present in root level
        if (isRootItemIndex) {
            newitemsInGroup = this.state.RootLevelNodes;
            indexOfClicked = newitemsInGroup.findIndex((item: any) => item.Id == clickedId);
        }
        var nextIndex = indexOfClicked + moveFactor;
        var nextItem = newitemsInGroup[nextIndex]
        if (nextItem) {
            return this.state.AllItemList.findIndex((item: any) => item.Id == nextItem.Id);
        } else {
            return undefined;
        }
    }
}