import Akumina = require("akumina-core");
import React = require("react");
import { ISLWViewRecursiveHTML } from "../SummaryLinksRenderManager";
import { EditComponent } from "./EditComponent";

interface ISummaryLinksRecursiveRenderProps {
    html: ISLWViewRecursiveHTML;
    model: any;
    SenderId: string;
    isSummaryLinkWidgetEditMode: boolean;
}
interface ISummaryLinksRecursiveRenderState {
    html: ISLWViewRecursiveHTML;
    model: any;
}

export class SummaryLinksRecursiveRender extends React.Component<ISummaryLinksRecursiveRenderProps, ISummaryLinksRecursiveRenderState>{
    constructor(props: ISummaryLinksRecursiveRenderProps) {
        super(props);
        this.state = {
            html: this.props.html,
            model: this.props.model
        }
    }

    componentDidUpdate(prevProps: ISummaryLinksRecursiveRenderProps) {
        if (this.props.html != prevProps.html || this.props.model != prevProps.model) {
            this.setState({
                html: this.props.html,
                model: this.props.model
            });
        }
    }

    render() {
        var _cur = this;
        var html = null;
        if (this.state.html != null) {
            var editComponent = _cur.props.isSummaryLinkWidgetEditMode ? <EditComponent Id={this.state.model.Id} SenderId={this.state.model.senderid} /> : null;

            var Children = this.state.model.Items ? this.state.model.Items.map(function (Item: any) {
                return <SummaryLinksRecursiveRender html={_cur.state.html} model={Item} SenderId={_cur.props.SenderId}
                    isSummaryLinkWidgetEditMode={_cur.props.isSummaryLinkWidgetEditMode}
                />
            }) : null;
            var dataForComponent = {
                ...this.props, ...this.state, Children: Children,
                SummaryLinksRecursiveRender: SummaryLinksRecursiveRender,
                editComponent: editComponent
            };
            if (this.state.model.NodeType == "Root") {
                html = this.state.html.root(dataForComponent)
            }
            if (this.state.model.NodeType == "Group") {
                html = this.state.html.group(dataForComponent)
            }
            if (this.state.model.NodeType == "Item") {
                html = this.state.html.item(dataForComponent)
            }

            return (
                <React.Fragment>
                    {html}
                </React.Fragment>
            );
        } else {
            return <div>{Akumina.Digispace.Language.TryGetText('summarylink.componentrendered')} </div>
        }
    }
}