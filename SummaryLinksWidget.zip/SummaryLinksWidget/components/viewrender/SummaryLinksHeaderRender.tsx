import Akumina = require("akumina-core");
import React = require("react");

interface ISummaryLinksHeaderRenderProps {
    html: Function;
    displayCollectionName: boolean;
    CollectionName: string;
}
interface ISummaryLinksHeaderRenderState {
    html: Function;
}

export class SummaryLinksHeaderRender extends React.Component<ISummaryLinksHeaderRenderProps, ISummaryLinksHeaderRenderState>{
    constructor(props: ISummaryLinksHeaderRenderProps) {
        super(props);
        this.state = {
            html: this.props.html
        }
    }

    componentDidUpdate(prevProps: ISummaryLinksHeaderRenderProps) {
        if (this.props.html != prevProps.html) {
            this.setState({
                html: this.props.html
            });
        }
    }

    render() {
        var _cur = this;
        var html = null;
        if (this.state.html != null && this.props.displayCollectionName) {
            html = this.state.html({
                CollectionName: _cur.props.CollectionName
            });
        }
        return (
            <React.Fragment>
                {html}
            </React.Fragment>
        );
    }
}