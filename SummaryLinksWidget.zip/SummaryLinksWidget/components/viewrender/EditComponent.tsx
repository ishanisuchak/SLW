
import React = require("react");
import Akumina = require("akumina-core");


interface IEditComponentProps {
    Id: string
    SenderId: string
}


export class EditComponent extends React.Component<IEditComponentProps> {

    render() {
        return (<div className="ak-slw-actions">
            <span data-id={this.props.Id} data-senderid={this.props.SenderId} onClick={this.DeleteClicked}><i className=" fa fa-trash" aria-hidden="true"></i></span>
            <span data-id={this.props.Id} data-senderid={this.props.SenderId} onClick={this.EditClicked}><i className="fa fa-edit" aria-hidden="true"></i></span>
        </div>)
    }

    //stateless click
    DeleteClicked(evt: React.SyntheticEvent) {
        var inputElem = evt.currentTarget as HTMLSpanElement;
        var id = inputElem.dataset.id;
        var senderid = inputElem.dataset.senderid;
        Akumina.Digispace.AppPart.Eventing.Publish('/summarylist/delete/' + senderid, id);
    }

    EditClicked(evt: React.SyntheticEvent) {
        var inputElem = evt.currentTarget as HTMLSpanElement;
        var id = inputElem.dataset.id;
        var senderid = inputElem.dataset.senderid;
        Akumina.Digispace.AppPart.Eventing.Publish('/summarylist/edit/' + senderid, id);
    }

}





/*





private AddEditDeleteButtons(html: string) {
       

    var editModeButtons = `{isSummaryLinkWidgetEditMode ?
    <div className="ak-slw-actions">
        <span data-id={model.Id} data-senderid={model.senderid} onClick={DeleteClicked}><i className=" fa fa-trash" aria-hidden="true"></i></span>
        <span data-id={model.Id} data-senderid={model.senderid} onClick={EditClicked}><i className="fa fa-edit" aria-hidden="true"></i></span>
    </div>
    : null}`;

    //ForGroup
    var index = html.search(/className.*ak-slw-group/);
    if (index > -1) {
        index = html.indexOf(">", index) + 1; //After end of the element open tag so our html is inside element
        html = [html.slice(0, index), editModeButtons, html.slice(index)].join("");
    }
    //ForItem
    index = html.search(/className.*ak-slw-item/);
    if (index > -1) {
        index = html.indexOf(">", index) + 1;
        html = [html.slice(0, index), editModeButtons, html.slice(index)].join("");
    }
    return html;
}


*/