import * as React from "react";
import * as Akumina from 'akumina-core';

interface IMessageComponentProps {
    ShowComponent: boolean;
    Message: string;
    MessageType: IMessageType;
}

interface IMessageComponentState {
    visible: boolean
}

export enum IMessageType {
    Success = "success",
    Error = "error",
    Fatal = "error fatal",
    Warning = "warning"
}

export class MessageComponent extends React.Component<IMessageComponentProps, IMessageComponentState> {

    constructor(props: IMessageComponentProps) {
        super(props);
        this.state = {
            visible: true
        }
        this.getHeader = this.getHeader.bind(this);
        this.hideComponent = this.hideComponent.bind(this);
    }

    componentWillReceiveProps(props: IMessageComponentProps) {
        this.setState({ visible: props.ShowComponent });
    }

    render() {
        var header = this.getHeader();
        if (this.props.ShowComponent && this.state.visible) {
            return (
                <div className={"akv-static-messages akv-modal-" + (this.props.MessageType ? this.props.MessageType.toLowerCase() : "")}>
                    <h3>{header}</h3>
                    <p>{this.props.Message}</p>
                    {/*<a className="ak-close-msg" href="#!" onClick={this.hideComponent}><i className="fa fa-times" aria-hidden="true"></i></a>*/}
                </div>
            )
        } else {
            return null;
        }
    }

    getHeader() {
        if (this.props.MessageType) {
            switch (this.props.MessageType) {
                case IMessageType.Success:
                    return Akumina.Digispace.Language.TryGetText("messagecomponent.messagesuccess");
                case IMessageType.Error:
                    return Akumina.Digispace.Language.TryGetText("messagecomponent.messageerror");
                case IMessageType.Fatal:
                    return Akumina.Digispace.Language.TryGetText("messagecomponent.messagefatalerror");
                case IMessageType.Warning:
                    return Akumina.Digispace.Language.TryGetText("messagecomponent.messagewarning");
                default:
                    return "";
            }
        }
    }

    hideComponent(e: any) {
        e.preventDefault();
        this.setState({
            visible: false
        });
    }
}



