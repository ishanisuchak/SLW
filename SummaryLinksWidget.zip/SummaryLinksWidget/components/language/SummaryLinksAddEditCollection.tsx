import Akumina = require("akumina-core");
import React = require("react");
import ImageUploaderComponent from "../../../../components/ImageUploaderComponent";
import { SummaryLinksWidget } from "../../js/widgets/SummaryLinksWidget";
import { IMessageType } from "../MessageComponent";
import { SummaryLinksAdd } from "../SummaryLinksAdd";
import { ISLWCollection } from "../SummaryLinksCollectionManager";
import { ISLWListItem } from "../SummaryLinksEditComponent";
import { ILanguageObject } from "./SummaryLinksCreateLanguageVersions";

declare var CKEDITOR: any;

interface ISLWAddCollectionProps {
    CollectionId?: string;
    Collections: Array<ISLWCollection>;
    CloseModal: any;
    ShowMessage: (Message: string, MessageType: IMessageType) => void;
    ListName: string;
    UseRoot: boolean;
    SenderId: string;
}

interface ISLWAddCollectionState {
    CollectionName: string;
    CollectionDescription: string;
    EditingCollectionObj: ISLWCollection | undefined;
    DuplicateCollectionName: boolean;
    InvalidCollectionName: boolean;
    IsButtonDisable: boolean;
    IsLoading: boolean;
    IsCkEditorLoaded: boolean;
    ShowImageUploaderComponent: boolean;
    ckeditorTabName: string;
}

export class SummaryLinksAddEditCollection extends React.Component<ISLWAddCollectionProps, ISLWAddCollectionState>{
    private personaTermsFromCache: any;
    constructor(props: ISLWAddCollectionProps) {
        super(props);
        var SelectedCollection = props.CollectionId ? props.Collections.filter(function (Collection: ISLWCollection) {
            return Collection.Id == props.CollectionId;
        })[0] : undefined;

        this.state = {
            CollectionName: SelectedCollection ? SelectedCollection.Name.toString() : "",
            CollectionDescription: SelectedCollection ? SelectedCollection.Description : "",
            EditingCollectionObj: SelectedCollection,
            DuplicateCollectionName: false,
            InvalidCollectionName: false,
            IsButtonDisable: false,
            IsLoading: false,
            IsCkEditorLoaded: false,
            ShowImageUploaderComponent: false,
            ckeditorTabName: ""
        }
        this.onCollectionNameChange = this.onCollectionNameChange.bind(this);
        this.onCollectionDescriptionChange = this.onCollectionDescriptionChange.bind(this);
        this.AddCollection = this.AddCollection.bind(this);
        this.UpdateCollection = this.UpdateCollection.bind(this);
    }

    componentDidMount() {
        this.personaTermsFromCache = Akumina.AddIn.Cache.Get(SummaryLinksWidget.personaCacheKey);
        if (!this.personaTermsFromCache) {
            SummaryLinksWidget.getPersonaTerms();
        }
        SummaryLinksAdd.InitCkeditor().then(async () => {
            this.setState({ IsCkEditorLoaded: true });
            CKEDITOR.on('dialogDefinition', this.DialogDefinitionCallback);
            await SummaryLinksAdd.tryFetchExternalConfig();
            SummaryLinksAdd.initCkeditorInstance(this.props.SenderId);
        });
    }

    componentWillUnmount() {
        CKEDITOR.removeListener('dialogDefinition', this.DialogDefinitionCallback);
    }

    DialogDefinitionCallback = (ev: any) => {
        var dialogName = ev.data.name;
        var dialogDefinition = ev.data.definition;
        if (dialogName === 'image' && ev.editor.name === ("description-" + this.props.SenderId) && !dialogDefinition.getContents('info').elements.some(function (e: any) { return e.id === 'akImages' })) {
            var infoTab = dialogDefinition.getContents('info');
            var linkTab = dialogDefinition.getContents('Link');
            // Get the "Browse Server" button from the info and Link tabs
            var browseButtonArray = [infoTab.get('browse'), linkTab.get('browse')];

            // Override the "onClick" function
            browseButtonArray.forEach(browseButton => {
                // Override the "onClick" function
                browseButton.onClick = () => {
                    let tabName = browseButton.filebrowser.target.split(":")[0];
                    this.setState({
                        ShowImageUploaderComponent: true,
                        ckeditorTabName: tabName
                    });
                }
            });
        }
    }

    GetDescription() {
        if (typeof CKEDITOR !== 'undefined' && this.state.IsCkEditorLoaded) {
            return Akumina.Digispace.Utilities.RewriteImageUrlsForHeadless(CKEDITOR.instances["description-" + this.props.SenderId].getData());
        } else {
            return Akumina.Digispace.Utilities.RewriteImageUrlsForHeadless(this.state.CollectionDescription);
        }
    }

    onCollectionNameChange(evt: React.SyntheticEvent) {
        var elem = evt.currentTarget as HTMLInputElement;
        var value = elem.value;
        this.setState({ CollectionName: value, InvalidCollectionName: false, DuplicateCollectionName: false });
    }

    onCollectionDescriptionChange(evt: React.SyntheticEvent) {
        var elem = evt.currentTarget as HTMLTextAreaElement;
        var value = elem.value;
        this.setState({ CollectionDescription: value });
    }

    render() {
        return (
            <React.Fragment>
                <div className="akv-modal-overlay akv-level-1"></div>
                <div id="ak-add-collection-modal" className="akv-modal akv-modal-medium">
                    <header className="akv-modal-header">
                        <h2>{Akumina.Digispace.Language.TryGetText("summarylink.settings.addnew")}</h2>
                        <a href="#0" className="akv-modal-close" onClick={e => (e.preventDefault(), this.props.CloseModal())}>
                            <i className="fa-regular fa-xmark" title={Akumina.Digispace.Language.TryGetText("common.close")} aria-label={Akumina.Digispace.Language.TryGetText("common.close")}></i>
                        </a>
                    </header>
                    <section className="akv-modal-content">
                        {this.state.IsLoading ? <div className="ia-widget-loader"></div> : null}
                        <div className={"akv-form-row" + (this.state.DuplicateCollectionName || this.state.InvalidCollectionName ? " ak-has-error" : "")}>
                            <label>{Akumina.Digispace.Language.TryGetText("summarylink.settings.title")}</label>
                            <div className="akv-value">
                                <input type="text" onChange={this.onCollectionNameChange} value={this.state.CollectionName} />
                            </div>
                            {this.state.DuplicateCollectionName ? <div className="akv-error-message">
                                {Akumina.Digispace.Language.GetText('summarylink.error.collectionnameduplicate')}
                            </div> : null}
                            {this.state.InvalidCollectionName ? <div className="akv-error-message">
                                {Akumina.Digispace.Language.GetText('summarylink.error.collectionnameemptypopup')}
                            </div> : null}
                        </div>
                        <div className="akv-form-row">
                            <label>{Akumina.Digispace.Language.TryGetText("common.description")}</label>
                            <div className="akv-value">
                                <textarea id={"description-" + this.props.SenderId} data-field="Summary" onChange={this.onCollectionDescriptionChange} value={this.state.IsCkEditorLoaded ? this.state.CollectionDescription : ""} maxLength={2048} ></textarea>
                            </div>
                        </div>
                    </section>
                    <footer className="akv-modal-footer">
                        <button className="akv-btn akv-btn-text btn-close-popup" onClick={e => this.props.CloseModal()}> {Akumina.Digispace.Language.TryGetText('common.cancel')}</button>
                        {this.props.CollectionId ?
                            <button className="akv-btn akv-primary" onClick={this.UpdateCollection}
                                disabled={this.state.IsButtonDisable || this.state.InvalidCollectionName || this.state.DuplicateCollectionName}>
                                {Akumina.Digispace.Language.TryGetText('common.update')}
                            </button>
                            :
                            <button className="akv-btn akv-primary" onClick={this.AddCollection}
                                disabled={this.state.IsButtonDisable || this.state.InvalidCollectionName || this.state.DuplicateCollectionName}>
                                {Akumina.Digispace.Language.TryGetText('common.save')}
                            </button>
                        }
                    </footer>
                </div>
                {this.state.ShowImageUploaderComponent ?
                    <React.Fragment>
                        <div className="akv-modal-overlay akv-level-1"></div>
                        <ImageUploaderComponent CloseModal={this.CloseImageModal} UpdateLinkUrl={this.UpdateLinkUrl} SelectedImageUrl={this.getSelectedLinkUrl()} RelativePathToImageLibrary={Akumina.Digispace.SiteContext.WebServerRelativeUrl} ImageLibraryName={"Images_AK"} IsRoot={false} />;
                    </React.Fragment>
                    : null}
            </React.Fragment>
        );
    }

    CloseImageModal = () => {
        this.setState({
            ShowImageUploaderComponent: false
        });
    }

    UpdateLinkUrl = (imageObj: any) => {
        const dialog = CKEDITOR.dialog.getCurrent();
        let imageUrl = imageObj.imageUrl;
        if (Akumina.Digispace.SiteContext.IsHeadlessMode) {
            let contextSiteUrl = Akumina.Digispace.ConfigurationContext.TenantUrl + Akumina.Digispace.SiteContext.WebServerRelativeUrl;
            imageUrl = Akumina.Digispace.ConfigurationContext.ServiceHubURL
                + "/api/sharepoint/spfile?siteurl=" + contextSiteUrl
                + "&relativeUrl=" + imageUrl.replace(Akumina.Digispace.ConfigurationContext.TenantUrl, "");
        }
        dialog.setValueOf(this.state.ckeditorTabName, 'txtUrl', imageUrl);
    }

    getSelectedLinkUrl = () => {
        const dialog = CKEDITOR.dialog.getCurrent();
        return dialog.getValueOf(this.state.ckeditorTabName, 'txtUrl');
    }

    ValidateNewCollectionName() {
        let newCollectionName = this.state.CollectionName;
        let isEmptyCollectionName = newCollectionName.trim().length == 0;
        if (isEmptyCollectionName) {
            this.setState({ InvalidCollectionName: isEmptyCollectionName, DuplicateCollectionName: false });
            return false;
        }

        let isDuplicateCollectionName = this.props.Collections.filter((Collection: ISLWCollection) => Collection.Name.trim().toLowerCase() == newCollectionName.trim().toLowerCase() && Collection.Id !== this.props.CollectionId).length > 0;
        if (isDuplicateCollectionName) {
            this.setState({ InvalidCollectionName: false, DuplicateCollectionName: isDuplicateCollectionName });
            return false;
        }
        return true;
    }

    AddCollection() {
        if (this.ValidateNewCollectionName()) {
            var _cur = this;

            var value = this.state.CollectionName.trim();
            var description = this.GetDescription();
            var newGuid = Akumina.Digispace.Utilities.GetGuid();

            var translateDefs: Array<JQueryDeferred<any>> = [];     //For translating text
            var addDefs: Array<JQueryDeferred<any>> = [];           //Add items in list
            var translateData: Array<any> = [];

            this.setState({ IsLoading: true });
            var interchange = new Akumina.Digispace.Data.Interchange();
            if (!this.personaTermsFromCache) {
                this.personaTermsFromCache = Akumina.AddIn.Cache.Get(SummaryLinksWidget.personaCacheKey);
            }
            let personaForAll = this.personaTermsFromCache.filter((term: any) => term.name.toLowerCase() == "all")[0];
            var model: ISLWListItem = {
                Title: value,
                Summary: description,
                NodeName: value,
                NodeType: "Root",
                DisplayOrder: 0,
                CollectionName: value,
                CollectionId: newGuid,
                ItemGuid: newGuid,
                AkLanguageCode: '',
                AkLanguageId: '',
                //Persona_0 is the hidden note field for Persona tax field
                //Updating it in this format is undocumented
                //Format: Value1|TermId1;Value2|TermId2
                Persona_0: personaForAll.name + "|" + personaForAll.guid
            } as any;

            var def: JQueryDeferred<any>;
            let isAutoTranslateEnabled = Akumina.Digispace.SiteContext.LicensingInformation && Akumina.Digispace.SiteContext.LicensingInformation.AutoTranslateEnabled
            Akumina.Digispace.ConfigurationContext.ActiveLanguages.forEach(function (languageObject: ILanguageObject) {
                var Item = { ...model };
                Item.AkLanguageCode = languageObject.languageCode;
                Item.AkLanguageId = languageObject.languageId;
                //@ts-ignore
                let isNonDefaultLang = Akumina.Digispace.ConfigurationContext.DefaultLanguage.languageId !== languageObject.LanguageId;
                let title = isNonDefaultLang ? (languageObject.Code + " " + model.Title) : model.Title;
                Item.Title = title;
                Item.NodeName = title;

                var queryParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, Item);
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                def = dataFactory.AddListItem(_cur.props.ListName, queryParams, _cur.props.UseRoot);
                addDefs.push(def);
            });
            //Create list item for each language version
            $.when.apply($, addDefs).then(function () {
                let defaultLanguageItem = Array.from(arguments).filter(x => x.AkLanguageId == Akumina.Digispace.UserContext.LanguageId)[0];
                translateData.push({
                    id: defaultLanguageItem.Id,
                    text: defaultLanguageItem.NodeName,
                    langCode: defaultLanguageItem.AkLanguageCode,
                    AkLanguageId: defaultLanguageItem.AkLanguageId,
                    isNonDefaultLang: false
                });
                for (var i = 0; i < arguments.length; ++i) {
                    //@ts-ignore                     
                    if (Akumina.Digispace.ConfigurationContext.DefaultLanguage.languageId !== arguments[i].AkLanguageId) {
                        if (isAutoTranslateEnabled) {
                            //@ts-ignore AutoTranslateText is new method in 5.5
                            var def = interchange.AutoTranslateText(model.NodeName, arguments[i].AkLanguageCode);
                            translateDefs.push(def);
                        }
                        translateData.push({
                            id: arguments[i].Id,
                            text: model.NodeName,
                            langCode: arguments[i].AkLanguageCode,
                            AkLanguageId: arguments[i].AkLanguageId,
                            isNonDefaultLang: true
                        });
                    }
                }
                //keep reference to added collection for later use
                (_cur as any).addedCollectionItems = arguments;
                if (isAutoTranslateEnabled) {
                    $.when.apply($, translateDefs).then(function () {
                        //Update list item with Translated text, AkId and Persona
                        _cur.UpdateListItems(translateData, arguments);
                    }, function (error: any) {
                        //Update list item with AkId and Persona even if translation fails
                        _cur.UpdateListItems(translateData);
                        (Akumina as any).Digispace.Logger.WriteErrorLog(error);
                        _cur.setState({ IsLoading: false });
                        _cur.props.ShowMessage("Error in adding new item in SummaryLinks_AK", IMessageType.Error);
                        _cur.props.CloseModal(true);
                    });
                }
                else {
                    //Update list item with AkId and Persona
                    _cur.UpdateListItems(translateData);
                }
            });
        }
    }

    UpdateListItems = (translateData: Array<any>, args?: any) => {
        var _cur = this;
        var updateDefs: Array<JQueryDeferred<any>> = []; //Update AkId
        let defaultLanguageItem = Array.from(translateData).filter(x => x.AkLanguageId == Akumina.Digispace.UserContext.LanguageId)[0];
        var languageModel = {
            AkId: defaultLanguageItem.id
        }
        var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, languageModel);
        var updateDef: JQueryDeferred<any>;
        var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
        dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
        updateDef = dataFactory.UpdateListItem(_cur.props.ListName, defaultLanguageItem.id, queryLangParams, _cur.props.UseRoot);
        updateDefs.push(updateDef);

        if (args) {
            for (var i = 0; i < args.length; ++i) {
                var translatedText = args[i].Data;
                translatedText = translatedText == translateData[i + 1].text ? (translateData[i + 1].langCode + " " + translatedText) : translatedText;

                let model = {
                    Title: translatedText,
                    NodeName: translatedText,
                    AkId: defaultLanguageItem.id,
                    CollectionName: translatedText
                }

                var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, model);
                var updateDef: JQueryDeferred<any>;
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                updateDef = dataFactory.UpdateListItem(_cur.props.ListName, translateData[i + 1].id, queryLangParams, _cur.props.UseRoot);
                updateDefs.push(updateDef);
            }
        }
        else {
            for (var i = 1; i < translateData.length; ++i) {
                let model = {
                    AkId: defaultLanguageItem.id,
                }

                var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, model);
                var updateDef: JQueryDeferred<any>;
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                updateDef = dataFactory.UpdateListItem(_cur.props.ListName, translateData[i].id, queryLangParams, _cur.props.UseRoot);
                updateDefs.push(updateDef);
            }
        }
        $.when.apply($, updateDefs).then(function (result: any) {
            _cur.setState({ IsLoading: false });
            _cur.props.ShowMessage(Akumina.Digispace.Language.TryGetText('summarylink.settings.collectioncreated'), IMessageType.Success);

            //send reference to added collection for caller to take any action if required -- e.g. show collection as selected
            var addedCollections = (_cur as any).addedCollectionItems;
            var actionResult = { addedCollections: addedCollections.length > 0 ? addedCollections[0] : null };

            _cur.props.CloseModal(true, actionResult);
        }, function (error: any) {
            (Akumina as any).Digispace.Logger.WriteErrorLog(error);
            _cur.setState({ IsLoading: false });
            _cur.props.ShowMessage("Error in updating language for new item in SummaryLinks_AK", IMessageType.Error);
            _cur.props.CloseModal(true);
        });
    }

    UpdateCollection() {
        if (this.ValidateNewCollectionName()) {
            var _cur = this;
            var name = this.state.CollectionName.trim();
            var desc = this.GetDescription();
            if (!this.personaTermsFromCache) {
                this.personaTermsFromCache = Akumina.AddIn.Cache.Get(SummaryLinksWidget.personaCacheKey);
            }
            let personaForAll = this.personaTermsFromCache.filter((term: any) => term.name.toLowerCase() == "all")[0];
            var def: JQueryDeferred<any>;
            var model = {
                Title: name,
                NodeName: name,
                NodeType: "Root",
                DisplayOrder: 0,
                CollectionName: name,
                Summary: desc,
                CollectionId: this.props.CollectionId,
                ItemGuid: this.props.CollectionId,
                //Persona_0 is the hidden note field for Persona tax field
                //Updating it in this format is undocumented
                //Format: Value1|TermId1;Value2|TermId2
                Persona_0: personaForAll.name + "|" + personaForAll.guid
            }

            this.setState({ IsLoading: true });

            var def: JQueryDeferred<any>;
            var queryParams = (Akumina.Digispace.Utilities as any).CreateListItemModelForHeadless(this.props.ListName, model);
            var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
            let updateDefs: Array<JQueryDeferred<any>> = [];
            dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
            def = dataFactory.UpdateListItem(this.props.ListName, this.state.EditingCollectionObj?.IntId, queryParams, _cur.props.UseRoot);
            updateDefs.push(def);

            $.when.apply($, updateDefs).then(function (result: any) {
                _cur.setState({ IsLoading: false });
                _cur.props.CloseModal(true);
            }, function (error: any) {
                _cur.setState({ IsLoading: false });
                (Akumina as any).Digispace.Logger.WriteErrorLog(error);
            });
        }
    }
}