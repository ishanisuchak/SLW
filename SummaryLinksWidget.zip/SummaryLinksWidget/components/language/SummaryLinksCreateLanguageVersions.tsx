import Akumina = require("akumina-core");
import React = require("react");
import { ISummaryLinksDataItem } from "../../js/widgets/SummaryLinksWidget";
import { IMessageType } from "../MessageComponent";
import { ISLWListItem } from "../SummaryLinksEditComponent";

interface ISummaryLinksCreateLangVersionsProps {
    CloseModal: any;
    SenderId: string;
    CollectionID: string;
    ShowMessage: (Message: string, MessageType: IMessageType) => void;
    ListName: string;
    UseRoot: boolean;
    DisplayCollectionName: boolean;
}
interface ISummaryLinksCreateLangVersionsState {
    AllItems: Array<ISummaryLinksDataItem> | null;
    TranslatedLanguages: Array<ILanguageObject>;
    LanguagesToCreateVariation: Array<any>;
    IsAutoTranslate: boolean;
    IsAllVariationTranslated: boolean;
    IsLoading: boolean;
}

export interface ILanguageObject {
    Code: string;
    Direction: string;
    FallBack: string;
    Icon: null | string;
    Id: number;
    IsActive: boolean;
    IsDefault: boolean;
    IsSiteVisible: boolean;
    LanguageId: number;
    Name: string;
    direction: string;
    fallbackLanguageId: string;
    isActive: boolean;
    isDefault: boolean;
    isSiteVisible: boolean;
    languageCode: string;
    languageId: number;
    localetitle: string;
    title: string;
}

export class SummaryLinksCreateLangVersions extends React.Component<ISummaryLinksCreateLangVersionsProps, ISummaryLinksCreateLangVersionsState>{
    constructor(props: ISummaryLinksCreateLangVersionsProps) {
        super(props);
        this.state = {
            AllItems: null,
            TranslatedLanguages: [],
            LanguagesToCreateVariation: [],
            IsAutoTranslate: false,
            IsAllVariationTranslated: false,
            IsLoading: true
        }
        this.GetLanguageVariations = this.GetLanguageVariations.bind(this);
        this.GetCollectionItems = this.GetCollectionItems.bind(this);
        this.CreateLanguageVersion = this.CreateLanguageVersion.bind(this);
        this.OnCheckboxClick = this.OnCheckboxClick.bind(this);
        this.ToggleAutoTranslate = this.ToggleAutoTranslate.bind(this);
    }

    componentDidMount() {
        this.GetCollectionItems();
        this.GetLanguageVariations();
    }

    CreateLanguageVersion() {
        var _cur = this;
        if (_cur.state.IsAutoTranslate) {
            _cur.CreateAutoTranslatedLanguageVersion();
        }
        else {
            _cur.CreateNonTranslatedLanguageVersions();
        }
    }

    CreateAutoTranslatedLanguageVersion = () => {
        this.setState({ IsLoading: true });

        var _cur = this;
        var addItemDefs: Array<JQueryDeferred<any>> = _cur.CreateLanguageVersionsInList();
        var translateDefs: Array<JQueryDeferred<any>> = [];
        var translateData: Array<any> = [];
        var interchange = new (Akumina as any).Digispace.Data.Interchange();

        /**
         * Step 1 : Create list items for each language version
         */
        $.when.apply($, addItemDefs).then(function () {
            var def: JQueryDeferred<any>;
            for (var i = 0; i < arguments.length; ++i) {
                //@ts-ignore                     
                if (Akumina.Digispace.ConfigurationContext.DefaultLanguage.languageId !== arguments[i].AkLanguageId) {
                    let akId = arguments[i].AkId;
                    let defaultItem = _cur.state.AllItems!.filter(item => item.IntId == akId)[0];
                    var textToTranslate = arguments[i].NodeType == "Root" ? arguments[i].CollectionName : arguments[i].NodeName;
                    if (defaultItem) {
                        textToTranslate = arguments[i].NodeType == "Root" ? defaultItem.CollectionName : defaultItem.Title;
                    }
                    else if (textToTranslate.indexOf(arguments[i].AkLanguageCode) > -1) {
                        textToTranslate = textToTranslate.substring(arguments[i].AkLanguageCode.length + 3);
                    }
                    //@ts-ignore AutoTranslateText is new method in 5.5
                    def = interchange.AutoTranslateText(textToTranslate, arguments[i].AkLanguageCode);
                    translateDefs.push(def);
                    translateData.push({
                        id: arguments[i].Id,
                        text: textToTranslate,
                        langCode: arguments[i].AkLanguageCode,
                        NodeType: arguments[i].NodeType
                    });
                }
            }
            /**
            * Step 2 : Translate only one field
            * To translate more fields, optimized api will be required
            */
            $.when.apply($, translateDefs).then(function () {
                /*
                * Step 3 : Update the translated field and Persona for the list item
                */
                _cur.UpdateListItems(translateData, arguments);
            }, function (error: any) {
                /*
                * Step 3 : Update Persona for the list item if translation fails
                */
                _cur.UpdateListItems(translateData);
                (Akumina as any).AddIn.Logger.WriteErrorLog(error);
                _cur.props.ShowMessage(Akumina.Digispace.Language.TryGetText("summarylink.error.errorintranslating"), IMessageType.Error);
            });
        }, function (error: any) {
            (Akumina as any).AddIn.Logger.WriteErrorLog(error);
            _cur.props.ShowMessage(Akumina.Digispace.Language.TryGetText("summarylink.error.errorincreatinglanguageversions"), IMessageType.Error);
        });
    }

    UpdateListItems = (translateData: Array<any>, args?: any) => {
        var _cur = this;
        var updateDefs: Array<JQueryDeferred<any>> = [];
        if (args) {
            for (var i = 0; i < args.length; ++i) {
                var translatedText = args[i].Data;
                translatedText = translatedText == translateData[i].text ? (translateData[i].langCode + " " + translatedText) : translatedText;

                let model: any = {
                    Title: translatedText,
                    NodeName: translatedText
                };

                if (translateData[i].NodeType == "Root")
                    model.CollectionName = translatedText;

                var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, model);
                var updateDef: JQueryDeferred<any>;
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                updateDef = dataFactory.UpdateListItem(_cur.props.ListName, translateData[i].id, queryLangParams, _cur.props.UseRoot);
                updateDefs.push(updateDef);
            }
        }
        else {
            for (var i = 0; i < translateData.length; ++i) {
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
            }
        }
        $.when.apply($, updateDefs).then(function () {
            _cur.props.ShowMessage(Akumina.Digispace.Language.TryGetText("summarylink.success.createdlanguageversion"), IMessageType.Success);
            _cur.props.CloseModal();
        }, function (error: any) {
            (Akumina as any).AddIn.Logger.WriteErrorLog(error);
            _cur.props.ShowMessage(Akumina.Digispace.Language.TryGetText("summarylink.error.errorinupdatingitems"), IMessageType.Error);
        });
    }

    CreateNonTranslatedLanguageVersions = () => {
        this.setState({ IsLoading: true });

        var _cur = this;
        var addItemDefs = _cur.CreateLanguageVersionsInList();
        var allItems: Array<any> = [];
        /**
         * Step 1 : Create list items for each language version
         */
        $.when.apply($, addItemDefs).then(function () {
            for (var i = 0; i < arguments.length; ++i) {
                //@ts-ignore                     
                if (Akumina.Digispace.ConfigurationContext.DefaultLanguage.languageId !== arguments[i].AkLanguageId) {
                    allItems.push({
                        id: arguments[i].Id
                    });
                }
            }
            /*
            * Step 2 : Update Persona for the list item
            */
            _cur.UpdateListItems(allItems);
        }, function (error: any) {
            (Akumina as any).AddIn.Logger.WriteErrorLog(error);
            _cur.setState({ IsLoading: false });
            _cur.props.ShowMessage(Akumina.Digispace.Language.TryGetText("summarylink.error.errorincreatinglanguageversions"), IMessageType.Error);
        });
    }

    CreateLanguageVersionsInList = () => {
        var _cur = this;
        var addItemDefs: Array<JQueryDeferred<any>> = [];
        var allItems: Array<ISLWListItem> = [];

        for (var i = 0; i < this.state.LanguagesToCreateVariation.length; ++i) {
            var langObj: ILanguageObject = Akumina.Digispace.ConfigurationContext.ActiveLanguages.filter(function (languageObject: ILanguageObject) {
                return languageObject.LanguageId == _cur.state.LanguagesToCreateVariation[i];
            })[0];

            this.state.AllItems && this.state.AllItems.forEach(function (element: ISummaryLinksDataItem) {
                var newItem: ISLWListItem = {
                    CollectionId: element.CollectionId,
                    CollectionName: element.NodeType == "Root" ? langObj.languageCode + " - " + element.CollectionName : element.CollectionName,
                    DisplayOrder: element.DisplayOrder,
                    NodeName: langObj.languageCode + " - " + element.Title,
                    NodeType: element.NodeType,
                    ParentNode: element.ParentNode,
                    Link: { Url: element.Link, Description: "" },
                    LinkTarget: element.LinkTargetValue,
                    Title: langObj.languageCode + " - " + element.Title,
                    Image: { Url: element.ImageUrl, Description: element.ImageAlternativeText },
                    Summary: element.Summary,
                    Tooltip: element.Tooltip,
                    ItemGuid: element.Id,
                    AkId: element.IntId,
                    AkLanguageCode: langObj.languageCode,
                    AkLanguageId: langObj.languageId,
                    //Persona_0 is the hidden note field for Persona tax field
                    //Updating it in this format is undocumented
                    //Format: Value1|TermId1;Value2|TermId2
                    Persona_0: element.Persona_0
                };
                allItems.push(newItem);

                var def: JQueryDeferred<any>;
                var queryParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, newItem);
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                def = dataFactory.AddListItem(_cur.props.ListName, queryParams, _cur.props.UseRoot);
                addItemDefs.push(def);
            });
        }
        return addItemDefs;
    }

    GetCollectionItems() {
        var _cur = this;
        var request: any = {};
        request.listName = this.props.ListName;
        request.selectFields = ["ID", "ItemGuid", "CollectionId", "CollectionName", "NodeName", "NodeType", "ParentNode", "DisplayOrder", "Summary", "Link", "LinkTarget", "Image", "Tooltip", "Persona_0"].join(",");
        request.isRoot = _cur.props.UseRoot;
        request.queryFilter = new Akumina.PropertyExpression("CollectionId").EqualTo(this.props.CollectionID);

        var df = new Akumina.Digispace.Data.DataFactory();
        df.GetList(request).then((res: { response: any; }) => {
            var responseData = res.response;
            var listItems = responseData.listItems;
            var listEnumerator = listItems.getEnumerator();
            var data: any = {};
            data.Items = [] as Array<ISummaryLinksDataItem>;

            while (listEnumerator.moveNext()) {
                var listItem = listEnumerator.get_current();
                var CollectionId = listItem.get_item("CollectionId");
                var CollectionName = listItem.get_item("CollectionName");
                var Title = listItem.get_item("NodeName");
                var NodeType = listItem.get_item("NodeType");
                var ParentNode = listItem.get_item("ParentNode");
                var DisplayOrder = listItem.get_item("DisplayOrder");
                var Summary = listItem.get_item("Summary");
                var Link = listItem.get_item("Link") == null ? "" : listItem.get_item("Link").get_url();
                var LinkTargetValue = listItem.get_item("LinkTarget");
                var LinkTarget = listItem.get_item("LinkTarget") == "Same Window" ? "_self" : "_blank";

                var Image = listItem.get_item("Image");
                var ImageUrl = Image ? Image.get_url() : "";
                var ImageAlternativeText = Image ? Image.get_description() : "";

                var Tooltip = listItem.get_item("Tooltip");
                var ItemGuid = listItem.get_item('ItemGuid');

                var Id = listItem.get_item('ID');
                var spaLink = Link ? Akumina.Digispace.Utilities.CreatePageLink(Link) : Link;
                //Get terms from Persona_0 hidden field associated with Persona taxonomy field
                var persona = listItem.get_item('Persona_0');

                var summaryLinkItem: ISummaryLinksDataItem = {
                    CollectionId: CollectionId,
                    CollectionName: CollectionName != null ? CollectionName.toString() : "",
                    DisplayCollectionName: this.props.DisplayCollectionName,
                    Title: Title ? Title : "",
                    NodeType: NodeType,
                    ParentNode: ParentNode ? ParentNode.toString() : "",
                    DisplayOrder: DisplayOrder,
                    Summary: Summary ? Summary : "",
                    Link: spaLink ? spaLink : "",
                    LinkTarget: LinkTarget ? LinkTarget : "",
                    LinkTargetValue: LinkTargetValue,
                    Id: ItemGuid.toString(),
                    IntId: Id,
                    ImageUrl: ImageUrl ? ImageUrl : "",
                    ImageAlternativeText: ImageAlternativeText ? ImageAlternativeText : "",
                    Tooltip: Tooltip ? Tooltip : "",
                    senderid: _cur.props.SenderId,
                    Persona_0: persona
                }
                data.Items.push(summaryLinkItem);
            }
            _cur.setState({ AllItems: data.Items });
        }, function (error: any) {
        });
    }

    GetLanguageVariations() {
        var _cur = this;
        var request: any = {};
        request.listName = this.props.ListName;
        request.selectFields = ["ID", "ItemGuid", "CollectionId", "NodeName", "NodeType", "AkLanguageId"].join(",");
        request.isRoot = _cur.props.UseRoot;
        request.queryFilter = new Akumina.PropertyExpression("CollectionId").EqualTo(this.props.CollectionID).And(new Akumina.PropertyExpression("NodeType").EqualTo("Root"));
        request.languageCheckRequired = false;

        this.setState({ IsLoading: true });
        var df = new Akumina.Digispace.Data.DataFactory();
        df.GetList(request).then(function (res: { response: any; }) {
            var responseData = res.response;
            var listItems = responseData.listItems;
            var listEnumerator = listItems.getEnumerator();
            var data: any = {};
            data.Items = [] as Array<string>;

            while (listEnumerator.moveNext()) {
                var listItem = listEnumerator.get_current();
                var AkLanguageId = listItem.get_item("AkLanguageId");
                var LanguageObj = Akumina.Digispace.ConfigurationContext.ActiveLanguages.filter(function (languageObject: ILanguageObject) {
                    return languageObject.LanguageId == AkLanguageId;
                })
                if (LanguageObj.length > 0) {
                    //Language object array can be empty when language of created variant is not found in Active languages. [Bug #33252]  
                    data.Items.push(LanguageObj[0]);
                }
            }

            var IsAllVariationTranslated = data.Items.length == Akumina.Digispace.ConfigurationContext.ActiveLanguages.length;
            _cur.setState({ TranslatedLanguages: data.Items, IsAllVariationTranslated: IsAllVariationTranslated, IsLoading: false });

        }, function (error: any) {
        });
    }

    OnCheckboxClick(evt: React.SyntheticEvent) {
        var checkbox = evt.currentTarget as HTMLInputElement;
        var languageId = parseInt(checkbox.value);
        var SelectedLanguages = this.state.LanguagesToCreateVariation.slice();
        var index = SelectedLanguages.indexOf(languageId);
        if (index == -1) {
            SelectedLanguages.push(languageId);
        } else {
            SelectedLanguages.splice(index, 1);
        }
        this.setState({ LanguagesToCreateVariation: SelectedLanguages });
    }

    ToggleAutoTranslate() {
        if (this.state.IsAllVariationTranslated) {
            return null
        }
        var isChecked = !this.state.IsAutoTranslate;
        this.setState({ IsAutoTranslate: isChecked });
    }

    render() {
        var _cur = this;
        let showAutoTranslateToggle = Akumina.Digispace.SiteContext.LicensingInformation && Akumina.Digispace.SiteContext.LicensingInformation.AutoTranslateEnabled;
        return (
            <React.Fragment>
                <div className="akv-modal-overlay akv-level-1"></div>
                <div id="ak-translate-modal" className="akv-modal">
                    <header className="akv-modal-header">
                        <h2>{Akumina.Digispace.Language.TryGetText("summarylink.settings.translate")}</h2>
                        <a href="#0" className="akv-modal-close" onClick={e => (e.preventDefault(), this.props.CloseModal())}>
                            <i className="fa-regular fa-xmark" title={Akumina.Digispace.Language.TryGetText("common.close")} aria-label={Akumina.Digispace.Language.TryGetText("common.close")}></i>
                        </a>
                    </header>
                    <section className="akv-modal-content">
                        {this.state.IsLoading ? <div className="ia-widget-loader"></div> : null}
                        {this.state.IsAllVariationTranslated ? <p><strong>{Akumina.Digispace.Language.TryGetText("summarylink.settings.versionexistsall")}</strong></p> :
                            <React.Fragment>
                                <p>{Akumina.Digispace.Language.TryGetText("summarylink.settings.selectlanguages")}</p>
                                {Akumina.Digispace.ConfigurationContext.ActiveLanguages.map(function (ActiveLanguage: ILanguageObject) {
                                    var isTranslated = _cur.state.TranslatedLanguages.filter(function (TranslatedLanguage: ILanguageObject) {
                                        return TranslatedLanguage.languageId == ActiveLanguage.languageId;
                                    }).length > 0;

                                    if (isTranslated) {
                                        return null;
                                    }

                                    return (
                                        <div key={ActiveLanguage.Id} className="akv-form-row">
                                            <label className="akv-checkbox-wrapper">
                                                <input type="checkbox" value={ActiveLanguage.languageId} data-code={ActiveLanguage.languageCode}
                                                    checked={_cur.state.LanguagesToCreateVariation.indexOf(ActiveLanguage.languageId) != -1} onClick={_cur.OnCheckboxClick} />
                                                <span className="akv-checkbox"></span>
                                                <span className="akv-checkbox-label">{ActiveLanguage.title}</span>
                                            </label>
                                        </div>
                                    )
                                })}
                                {showAutoTranslateToggle &&
                                    <label className="akv-switch">
                                        <input type="checkbox" checked={this.state.IsAutoTranslate} disabled={this.state.IsAllVariationTranslated} />
                                        <span className="ak-slider" onClick={this.ToggleAutoTranslate}></span>
                                        <span className="ak-slider-label">{Akumina.Digispace.Language.TryGetText("summarylink.settings.autotranslate")}</span>
                                    </label>}
                                <p><strong>{Akumina.Digispace.Language.TryGetText("summarylink.settings.versionexists")}</strong></p>
                            </React.Fragment>
                        }
                        <ul className="akv-existing-languages">
                            {this.state.TranslatedLanguages.map(function (languageObject: ILanguageObject) {
                                return <li >{languageObject.title}</li>
                            })}
                        </ul>
                    </section>
                    <footer className="akv-modal-footer">
                        <button className="akv-btn akv-btn-text btn-close-popup" onClick={e => this.props.CloseModal()}> {Akumina.Digispace.Language.TryGetText('common.cancel')}</button>
                        <button className="akv-btn akv-primary" onClick={this.CreateLanguageVersion} disabled={this.state.IsAllVariationTranslated} >{Akumina.Digispace.Language.TryGetText('summarylink.settings.createlangver')}</button>
                    </footer>
                </div>
            </React.Fragment>
        )
    }
}