import Akumina = require("akumina-core");
import React = require("react");
import { ILanguageObject } from "./language/SummaryLinksCreateLanguageVersions";
import { ISLWListItem } from "./SummaryLinksEditComponent";
import { IPersona, SummaryLinksWidget } from "../js/widgets/SummaryLinksWidget";
import { Persona } from "./Persona";

interface ISummaryLinksAddEditGroupProps {
    CollectionId: string;
    CloseModal: any;
    GroupItem: any;
    GroupList: Array<any>;
    RootNodeGuid: string;
    ListName: string;
    UseRoot: boolean;
}
interface ISummaryLinksAddEditGroupState {
    IsGroupNameError: boolean;
    GroupNameErrorText: string;
    IsLoading: boolean;
    CollectionExistInLangs: Array<ISLWExistingLang>;
    SelectedPersonas: string;
    SelectedTab: string;
}

export interface ISLWExistingLang {
    LangId: number;
    LangCode: string;
}

export class SummaryLinksAddEditGroup extends React.Component<ISummaryLinksAddEditGroupProps, ISummaryLinksAddEditGroupState>{
    private inputRef: React.RefObject<HTMLInputElement>;
    private personaTermsFromCache: any;
    constructor(props: ISummaryLinksAddEditGroupProps) {
        super(props);
        this.state = {
            IsGroupNameError: false, GroupNameErrorText: "",
            IsLoading: false, CollectionExistInLangs: [],
            SelectedPersonas: this.props.GroupItem ? this.CreatePersonaModelForGroups(this.props.GroupItem.Persona) : "",
            SelectedTab: "addnewgroup",
        }
        this.inputRef = React.createRef();
        this.SaveGroupName = this.SaveGroupName.bind(this);
        this.AutoTranslateText = this.AutoTranslateText.bind(this);
        this.UpdateSelectedPersona = this.UpdateSelectedPersona.bind(this);
    }

    componentDidMount() {
        this.GetLanguageVariations();
        this.personaTermsFromCache = Akumina.AddIn.Cache.Get(SummaryLinksWidget.personaCacheKey);
        if (!this.personaTermsFromCache) {
            SummaryLinksWidget.getPersonaTerms();
        }
    }

    CreatePersonaModelForGroups(personaData: IPersona[]) {
        let personaStr = "";
        if (personaData && personaData.length > 0) {
            personaData.forEach((element, index) => {
                personaStr += index == 0 ? element.label + "|" + element.guId : ";" + element.label + "|" + element.guId
            });
        }
        return personaStr;
    }

    SaveGroupName() {
        var _cur = this;
        var value = this.inputRef.current ? this.inputRef.current.value : "";
        var MaxRootDisplayOrder = this.props.GroupList.length == 0 ? 1 : this.props.GroupList[0].MaxRootDisplayOrder + 1;
        if (!this.personaTermsFromCache) {
            this.personaTermsFromCache = Akumina.AddIn.Cache.Get(SummaryLinksWidget.personaCacheKey);
        }
        let personaForAll = this.personaTermsFromCache.filter((term: any) => term.name.toLowerCase() == "all")[0];
        let selectedPersonas = this.state.SelectedPersonas != "" ? this.state.SelectedPersonas : personaForAll.name + "|" + personaForAll.guid;
        var model: ISLWListItem = {
            Title: value,
            NodeName: value,
            NodeType: "Category",
            ParentNode: this.props.RootNodeGuid,
            DisplayOrder: MaxRootDisplayOrder,
            CollectionId: this.props.CollectionId,
            //Persona_0 is the hidden note field for Persona tax field
            //Updating it in this format is undocumented
            //Format: Value1|TermId1;Value2|TermId2
            Persona_0: selectedPersonas
        }
        let isAutoTranslateEnabled = Akumina.Digispace.SiteContext.LicensingInformation && Akumina.Digispace.SiteContext.LicensingInformation.AutoTranslateEnabled

        if (this.ValidateGroups(value as string)) {
            this.setState({
                IsLoading: true
            });
            if (this.props.GroupItem) {
                var def: JQueryDeferred<any>;
                var queryParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, model);
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                let personaDef: JQueryDeferred<any>;
                let updateDefs: Array<JQueryDeferred<any>> = [];
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                def = dataFactory.UpdateListItem(_cur.props.ListName, this.props.GroupItem.IntId, queryParams, _cur.props.UseRoot);
                updateDefs.push(def);

                $.when.apply($, updateDefs).then(function (result: any) {
                    _cur.props.CloseModal(true);
                }, function (error: any) {
                    (Akumina as any).AddIn.Logger.WriteErrorLog(error);
                    _cur.setState({
                        IsLoading: false
                    });
                });
            } else {
                model.ItemGuid = Akumina.Digispace.Utilities.GetGuid();

                var translateDefs: Array<JQueryDeferred<any>> = [];     //For translating text
                var addDefs: Array<JQueryDeferred<any>> = [];           //Add items in list
                var translateData: Array<any> = [];

                var interchange = new Akumina.Digispace.Data.Interchange();
                var ExistingLanguageForCollection = Akumina.Digispace.ConfigurationContext.ActiveLanguages.filter(function (languageObject: ILanguageObject) {
                    return _cur.state.CollectionExistInLangs.findIndex(function (ExistingLang) {
                        return languageObject.LanguageId == ExistingLang.LangId;
                    }) !== -1;
                });
                ExistingLanguageForCollection.forEach(function (languageObject: ILanguageObject) {
                    var def: JQueryDeferred<any>;
                    var Item = { ...model };
                    Item.AkLanguageId = languageObject.languageId;
                    Item.AkLanguageCode = languageObject.Code;
                    //@ts-ignore
                    let isNonDefaultLang = Akumina.Digispace.ConfigurationContext.DefaultLanguage.languageId !== languageObject.LanguageId;
                    let title = isNonDefaultLang ? (languageObject.Code + " " + Item.Title) : Item.Title;
                    Item.Title = title;
                    Item.NodeName = title;

                    var def: JQueryDeferred<any>;
                    var queryParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, Item);
                    var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                    dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);

                    def = dataFactory.AddListItem(_cur.props.ListName, queryParams, _cur.props.UseRoot);
                    addDefs.push(def);
                });
                //Create list item for each language version
                $.when.apply($, addDefs).then(function () {
                    let defaultLanguageItem = Array.from(arguments).filter(x => x.AkLanguageId == Akumina.Digispace.UserContext.LanguageId)[0];
                    translateData.push({
                        id: defaultLanguageItem.Id,
                        text: value,
                        langCode: defaultLanguageItem.AkLanguageCode,
                        AkLanguageId: defaultLanguageItem.AkLanguageId,
                        isNonDefaultLang: false
                    });
                    for (var i = 0; i < arguments.length; ++i) {
                        //@ts-ignore
                        if (Akumina.Digispace.ConfigurationContext.DefaultLanguage.languageId !== arguments[i].AkLanguageId) {
                            if (isAutoTranslateEnabled) {
                                //@ts-ignore AutoTranslateText is new method in 5.5
                                def = interchange.AutoTranslateText(value, arguments[i].AkLanguageCode);
                                translateDefs.push(def);
                            }
                            translateData.push({
                                id: arguments[i].Id,
                                text: value,
                                langCode: arguments[i].AkLanguageCode,
                                AkLanguageId: arguments[i].AkLanguageId,
                                isNonDefaultLang: true
                            });
                        }
                    }
                    if (isAutoTranslateEnabled) {
                        $.when.apply($, translateDefs).then(function () {
                            //Update list item with Translated text, AkId and Persona
                            _cur.UpdateListItems(translateData, arguments);
                        }, function (error: any) {
                            //Update list item with AkId and Persona even if translation fails
                            _cur.UpdateListItems(translateData);
                            (Akumina as any).Digispace.Logger.WriteErrorLog(error);
                            _cur.setState({
                                IsLoading: false
                            });
                            _cur.props.CloseModal(true);

                        });
                    }
                    else {
                        //Update list item with AkId and Persona
                        _cur.UpdateListItems(translateData);
                    }
                }, function (error: any) {
                    (Akumina as any).Digispace.Logger.WriteErrorLog(error);
                    _cur.setState({
                        IsLoading: false
                    });
                    _cur.props.CloseModal(true);

                });
            }
        }
    }

    UpdateListItems = (translateData: Array<any>, args?: any) => {
        var _cur = this;
        var updateDefs: Array<JQueryDeferred<any>> = []; //Update AkId
        let defaultLanguageItem = Array.from(translateData).filter(x => x.AkLanguageId == Akumina.Digispace.UserContext.LanguageId)[0];
        var languageModel = {
            AkId: defaultLanguageItem.id
        }
        var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, languageModel);
        var updateDef: JQueryDeferred<any>;
        var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
        dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
        updateDef = dataFactory.UpdateListItem(_cur.props.ListName, defaultLanguageItem.id, queryLangParams, _cur.props.UseRoot);
        updateDefs.push(updateDef);

        if (args) {
            for (var i = 0; i < args.length; ++i) {
                var translatedText = args[i].Data;
                translatedText = translatedText == translateData[i + 1].text ? (translateData[i + 1].langCode + " " + translatedText) : translatedText;

                let model = {
                    Title: translatedText,
                    NodeName: translatedText,
                    AkId: defaultLanguageItem.id
                }
                var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, model);
                var updateDef: JQueryDeferred<any>;
                let personaDef: JQueryDeferred<any>;
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                updateDef = dataFactory.UpdateListItem(_cur.props.ListName, translateData[i + 1].id, queryLangParams, _cur.props.UseRoot);
                updateDefs.push(updateDef);
            }
        }
        else {
            for (var i = 1; i < translateData.length; ++i) {
                let model = {
                    AkId: defaultLanguageItem.id
                }
                var queryLangParams = (Akumina as any).Digispace.Utilities.CreateListItemModelForHeadless(_cur.props.ListName, model);
                var updateDef: JQueryDeferred<any>;
                let personaDef: JQueryDeferred<any>;
                var dataFactory = new (Akumina as any).Digispace.Data.DataFactory();
                dataFactory.SetContextUrl(_cur.props.UseRoot ? Akumina.Digispace.SiteContext.SiteAbsoluteUrl : Akumina.Digispace.SiteContext.WebAbsoluteUrl);
                updateDef = dataFactory.UpdateListItem(_cur.props.ListName, translateData[i].id, queryLangParams, _cur.props.UseRoot);
                updateDefs.push(updateDef);
            }
        }
        $.when.apply($, updateDefs).then(function (result: any) {
            _cur.setState({
                IsLoading: false
            });
            _cur.props.CloseModal(true);
        }, function (error: any) {
            (Akumina as any).Digispace.Logger.WriteErrorLog(error);
            _cur.setState({
                IsLoading: false
            });
            _cur.props.CloseModal(true);
        });
    }

    ValidateGroups(value: string) {
        if (!Akumina.AddIn.Utilities.IsNullOrEmpty(value)) {
            var groupExist = [];
            if (groupExist.length === 0) {
                this.setState({
                    GroupNameErrorText: "",
                    IsGroupNameError: false
                })
                return true
            } else {
                this.setState({
                    GroupNameErrorText: Akumina.Digispace.Language.TryGetText('summarylink.error.duplicategroup'),
                    IsGroupNameError: true,
                    SelectedTab: 'addnewgroup'
                })
                return false;
            }
        } else {
            this.setState({
                GroupNameErrorText: Akumina.Digispace.Language.TryGetText('summarylink.error.emptygroupname'),
                IsGroupNameError: true,
                SelectedTab: 'addnewgroup'
            })
            return false;
        }
    }

    AutoTranslateText() {
        var _cur = this;
        var value = this.inputRef.current ? this.inputRef.current.value : "";
        var AkLanguageCode = Akumina.Digispace.ConfigurationContext.ActiveLanguages.filter(x => x.LanguageId == Akumina.Digispace.UserContext.LanguageId)[0].Code;
        var interchange = new (Akumina as any).Digispace.Data.Interchange();
        interchange.AutoTranslateText(value, AkLanguageCode).then(function (repsonse: any) {
            if (repsonse && _cur.inputRef.current !== null) {
                _cur.inputRef.current.value = repsonse.Data;
            }
        }, function (error: any) {
            (Akumina as any).AddIn.Logger.WriteErrorLog(error);
        });
    }

    handleTabChange(selectedTab: string) {
        var _cur = this;
        _cur.setState({
            SelectedTab: selectedTab
        });
    }

    UpdateSelectedPersona(persona: Array<any>) {
        var _cur = this;
        var personaStr = "";
        persona.forEach((element, index) => {
            personaStr += index == 0 ? element.personaName + "|" + element.termId : ";" + element.personaName + "|" + element.termId
        });
        _cur.setState({
            SelectedPersonas: personaStr,
        });
    }

    render() {
        var isNonDefaultLanguage = (Akumina.Digispace.ConfigurationContext.DefaultLanguage as any).languageId !== Akumina.Digispace.UserContext.LanguageId;
        let showAutoTranslateButton = Akumina.Digispace.SiteContext.LicensingInformation && Akumina.Digispace.SiteContext.LicensingInformation.AutoTranslateEnabled;
        return (
            <div className="akv-modal akv-modal-medium akv-slw-manage-group">
                <header className="akv-modal-header">
                    <h2>{this.props.GroupItem ? Akumina.Digispace.Language.TryGetText('summarylink.edit.label_editgroup') : Akumina.Digispace.Language.TryGetText('summarylink.edit.label_addgroup')}</h2>
                    <a href="#0" className="ak-modal-close akv-modal-close" onClick={e => (e.preventDefault(), this.props.CloseModal())}>
                        <i className="fa-regular fa-xmark" title={Akumina.Digispace.Language.TryGetText("common.close")} aria-label={Akumina.Digispace.Language.TryGetText("common.close")}></i>
                    </a>
                </header>
                <section className="akv-modal-content akv-padding-0 akv-modal-with-tabs">
                    {this.state.IsLoading ? <div className="ia-widget-loader"></div> : null}
                    <ul className="akv-tabs akv-padding-t-12">
                        <li className={(this.state.SelectedTab === "addnewgroup" ? "akv-active" : "")} onClick={(e) => this.handleTabChange("addnewgroup")}><a>{Akumina.Digispace.Language.TryGetText("addpagetab.details")}</a></li>
                        <li className={(this.state.SelectedTab === "personatab" ? "akv-active" : "")} onClick={(e) => this.handleTabChange("personatab")}><a>{Akumina.Digispace.Language.TryGetText("addpagetab.personas")}</a></li>
                    </ul>
                    <section className="akv-tab-content akv-padding-x-24" style={{ display: "block" }}>
                        <div className={(this.state.SelectedTab === "addnewgroup" ? "ak-active" : "mfp-hide")}>
                            <div className={"akv-form-row " + (this.state.IsGroupNameError ? "ak-has-error" : "")}>
                                <label>{Akumina.Digispace.Language.TryGetText('summarylink.groupname')}</label>
                                <div className={"akv-value " + (isNonDefaultLanguage ? "ak-icon-value" : "")}>
                                    <input data-field="GroupName" ref={this.inputRef} defaultValue={this.props.GroupItem.Title} className="ak-field-half-width" type="text" maxLength={255} />
                                    {isNonDefaultLanguage && showAutoTranslateButton &&
                                        <div className="ak-icon-btn">
                                            <a href="javascript:void(0)" onClick={this.AutoTranslateText}>
                                                <i className="fas fa-globe"></i>
                                            </a>
                                        </div>
                                    }
                                    {this.state.IsGroupNameError ? <div className="akv-error-message">{this.state.GroupNameErrorText}</div> : null}
                                </div>
                            </div>
                        </div>
                        <div className={(this.state.SelectedTab === "personatab" ? "akv-active" : "mfp-hide")}>
                            <Persona handlePersonaUpdate={this.UpdateSelectedPersona} selectedPersona={this.props.GroupItem ? this.props.GroupItem.Persona : []} />
                        </div>
                    </section>
                </section>
                <footer className="akv-modal-footer">
                    <button className="btn-form btn-close-popup akv-btn akv-btn-text" onClick={e => this.props.CloseModal()}>{Akumina.Digispace.Language.TryGetText('common.cancel')}</button>
                    <button className="btn-form akv-btn akv-primary" onClick={this.SaveGroupName} disabled={this.state.IsLoading}>{Akumina.Digispace.Language.TryGetText('common.save')}</button>
                </footer>
            </div>
        )
    }

    private GetLanguageVariations() {
        if (Akumina.Digispace.ConfigurationContext.IsMultiLingualEnabled && Akumina.Digispace.ConfigurationContext.AreMultipleLanguagesVisible) {
            var _cur = this;
            var request: any = {};
            request.listName = _cur.props.ListName;
            request.selectFields = ["AkLanguageCode", "AkLanguageId"].join(",");
            request.isRoot = _cur.props.UseRoot;
            request.languageCheckRequired = false;
            request.queryFilter = new Akumina.PropertyExpression("CollectionId").EqualTo(this.props.CollectionId);

            this.setState({
                IsLoading: true
            });
            var df = new Akumina.Digispace.Data.DataFactory();
            df.GetList(request).then(function (data: { response: any; }) {
                var items = data.response.listItems;
                var existingLanguages = items.map((item: any) => { return { LangId: item.AkLanguageId, LangCode: item.AkLanguageCode } })
                _cur.setState({
                    IsLoading: false, CollectionExistInLangs: existingLanguages
                });
            });
        } else {
            var existingLanguages = Akumina.Digispace.ConfigurationContext.ActiveLanguages.map(function (item: any) {
                return { LangId: item.languageId, LangCode: item.languageCode }
            });
            this.setState({
                IsLoading: false, CollectionExistInLangs: existingLanguages
            });
        }
    }
}